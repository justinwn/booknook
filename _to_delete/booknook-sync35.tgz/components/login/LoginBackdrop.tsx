import { BookNote } from "@/components/book/BookNote";
import { SCATTERED_NOTES } from "@/lib/mock/sample-books";
import type { PaperTreatment } from "@/lib/theme/themes";

/**
 * Sky behind the book, with other people's reading notes pinned across it —
 * a different book on every card. Positions are fixed percentages rather than
 * random, so the wall is the same composition every time and nothing lands
 * behind the book in the middle.
 */
const SPOTS = [
  { top: "-4%", left: "-3%", tilt: -8, scale: 0.92 },
  { top: "2%", left: "68%", tilt: 6, scale: 0.86 },
  { top: "26%", left: "-6%", tilt: 5, scale: 1 },
  { top: "22%", left: "78%", tilt: -4, scale: 0.96 },
  { top: "62%", left: "-2%", tilt: -6, scale: 0.9 },
  { top: "66%", left: "72%", tilt: 9, scale: 0.94 },
  { top: "84%", left: "22%", tilt: 4, scale: 0.82 },
  { top: "-8%", left: "34%", tilt: -5, scale: 0.8 },
];

/** the notes are scenery: one stock for all of them, so the sky stays calm */
const SCRAP: PaperTreatment = {
  background: "#fbf3d4",
  ink: "#3a3220",
  pattern: "lines",
  patternColor: "rgba(80, 68, 40, 0.14)",
  fontDisplay: "var(--font-playfair)",
  fontBody: "var(--font-eb-garamond)",
};

export function LoginBackdrop() {
  return (
    <div className="absolute inset-0 overflow-hidden bg-[#bfe1f6]" aria-hidden>
      {SPOTS.map((spot, i) => {
        const note = SCATTERED_NOTES[i % SCATTERED_NOTES.length];
        return (
          <div
            key={note.id}
            className="absolute hidden sm:block"
            style={{
              top: spot.top,
              left: spot.left,
              transform: `rotate(${spot.tilt}deg) scale(${spot.scale})`,
            }}
          >
            <BookNote
              title={note.title}
              author={note.author}
              rating={note.rating}
              note={note.note}
              finishedAt={note.finishedAt}
              paper={SCRAP}
              className="w-[15.5rem] rounded-[2px] shadow-[0_16px_34px_-18px_rgba(20,40,70,0.55)]"
            />
          </div>
        );
      })}

      {/* the sky reads through toward the middle, so the book has somewhere
          quiet to sit and the notes stay in the periphery */}
      <div
        className="absolute inset-0"
        style={{
          background:
            "radial-gradient(46% 52% at 50% 50%, rgba(191,225,246,0.94) 42%, rgba(191,225,246,0) 78%)",
        }}
      />
    </div>
  );
}
