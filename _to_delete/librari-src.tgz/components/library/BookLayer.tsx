"use client";

import type { Book, DecorPlacement, Slot } from "@/lib/types";
import { BookSpine } from "@/components/book/BookSpine";
import { DecorPlaceholder } from "@/components/decor/DecorPlaceholder";
import { Plus } from "lucide-react";

interface BookLayerProps {
  slots: Slot[];
  books: Book[];
  decorPlacements: DecorPlacement[];
  recentlyAddedBookId?: string | null;
  onEmptySlotClick?: (slotId: string) => void;
}

/**
 * Renders everything that lives IN the room — books, decor, empty-slot
 * affordances — positioned purely from slot data. Add a row to the slot map
 * and it appears here; this component knows nothing about the photograph.
 */
export function BookLayer({
  slots,
  books,
  decorPlacements,
  recentlyAddedBookId,
  onEmptySlotClick,
}: BookLayerProps) {
  const bookBySlot = new Map(books.map((b) => [b.slotId, b]));
  const decorBySlot = new Map(decorPlacements.map((d) => [d.slotId, d]));

  return (
    <div className="absolute inset-0">
      {slots.map((slot) => {
        const book = bookBySlot.get(slot.id);
        const decor = decorBySlot.get(slot.id);

        return (
          <div
            key={slot.id}
            className="absolute"
            style={{
              left: `${slot.x}%`,
              top: `${slot.y}%`,
              width: `${slot.width}%`,
              height: `${slot.height}%`,
            }}
          >
            {book && (
              <BookSpine book={book} scale={slot.scale} animateIn={book.id === recentlyAddedBookId} />
            )}

            {decor && <DecorPlaceholder decorType={decor.decorType} />}

            {!book && !decor && slot.kind === "book" && (
              <button
                type="button"
                onClick={() => onEmptySlotClick?.(slot.id)}
                aria-label="Add a book to this spot"
                className="group flex h-full w-full items-end justify-center pb-[6%]"
              >
                <span className="flex h-6 w-6 items-center justify-center rounded-full border border-dashed border-white/0 text-white/0 backdrop-blur-[1px] transition-all duration-200 group-hover:border-white/50 group-hover:bg-black/25 group-hover:text-white/80 group-focus-visible:border-white/50 group-focus-visible:text-white/80">
                  <Plus className="h-3.5 w-3.5" strokeWidth={1.75} />
                </span>
              </button>
            )}
          </div>
        );
      })}
    </div>
  );
}
