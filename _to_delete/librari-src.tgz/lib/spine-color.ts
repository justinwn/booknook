// Deterministic placeholder spine coloring, derived from the book's title,
// so the same book always gets the same color without needing real cover
// art. Replace with cover-driven or user-chosen coloring once real covers
// are wired up — nothing else depends on how this color is produced.
export function spineColor(seed: string): { bg: string; band: string } {
  let hash = 0;
  for (let i = 0; i < seed.length; i++) {
    hash = (hash << 5) - hash + seed.charCodeAt(i);
    hash |= 0;
  }
  const hue = Math.abs(hash) % 360;
  return {
    bg: `hsl(${hue} 32% 34%)`,
    band: `hsl(${hue} 40% 22%)`,
  };
}
