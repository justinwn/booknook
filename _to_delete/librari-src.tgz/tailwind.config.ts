import type { Config } from "tailwindcss";

// Design tokens are centralized as CSS custom properties (see app/globals.css),
// grouped per theme under [data-theme="..."]. Tailwind utilities below just
// point at those variables so no component ever hardcodes a color, radius,
// or shadow value directly — swap a theme's variables and every component
// that uses these tokens updates automatically.
const config: Config = {
  content: ["./app/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}", "./lib/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        bg: "var(--color-bg)",
        surface: "var(--color-surface)",
        "surface-raised": "var(--color-surface-raised)",
        ink: "var(--color-ink)",
        "ink-muted": "var(--color-ink-muted)",
        "ink-soft": "var(--color-ink-soft)",
        accent: "var(--color-accent)",
        "accent-soft": "var(--color-accent-soft)",
        border: "var(--color-border)",
        paper: "var(--color-paper)",
        // brand chrome (login + onboarding), independent of library mood
        blush: "var(--brand-blush)",
        "blush-ink": "var(--brand-blush-ink)",
        gallery: "var(--brand-gallery)",
        "gallery-ink": "var(--brand-gallery-ink)",
        selected: "var(--brand-selected)",
      },
      fontFamily: {
        display: ["var(--font-display)"],
        body: ["var(--font-body)"],
      },
      borderRadius: {
        token: "var(--radius-md)",
        "token-sm": "var(--radius-sm)",
        "token-lg": "var(--radius-lg)",
      },
      boxShadow: {
        token: "var(--shadow-md)",
        "token-lg": "var(--shadow-lg)",
        "token-inset": "var(--shadow-inset)",
      },
      transitionTimingFunction: {
        settle: "var(--ease-settle)",
        gentle: "var(--ease-gentle)",
      },
      transitionDuration: {
        token: "var(--motion-md)",
      },
      backgroundImage: {
        grain: "url('/assets/texture-grain.svg')",
      },
    },
  },
  plugins: [],
};
export default config;
