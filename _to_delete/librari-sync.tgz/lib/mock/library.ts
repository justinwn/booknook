import type { Book, DecorPlacement, Slot } from "@/lib/types";

/**
 * Bibliographic placeholder data — real titles/authors (metadata, not
 * reproduced cover art). Books are assigned to slots by index at load, so the
 * same collection lays out correctly in any room whose slot map differs.
 */
const CATALOG: Array<Omit<Book, "id" | "order" | "slotId" | "addedAt">> = [
  { title: "The Odyssey", author: "Homer", coverUrl: "", dimensions: { heightMm: 198, widthMm: 129, thicknessMm: 22 }, owned: true, status: "Done", rating: 5, tags: ["classic"] },
  { title: "Braiding Sweetgrass", author: "Robin Wall Kimmerer", coverUrl: "", dimensions: { heightMm: 210, widthMm: 140, thicknessMm: 28 }, owned: true, status: "Ongoing", rating: 5, tags: ["nature"] },
  { title: "Norwegian Wood", author: "Haruki Murakami", coverUrl: "", dimensions: { heightMm: 197, widthMm: 128, thicknessMm: 18 }, owned: true, status: "Done", rating: 4, tags: ["fiction"] },
  { title: "Silent Spring", author: "Rachel Carson", coverUrl: "", dimensions: { heightMm: 203, widthMm: 133, thicknessMm: 16 }, owned: true, status: "New", tags: ["nonfiction"] },
  { title: "Pride and Prejudice", author: "Jane Austen", coverUrl: "", dimensions: { heightMm: 196, widthMm: 128, thicknessMm: 24 }, owned: true, status: "Done", rating: 4, tags: ["classic"] },
  { title: "The Hobbit", author: "J.R.R. Tolkien", coverUrl: "", dimensions: { heightMm: 200, widthMm: 135, thicknessMm: 26 }, owned: true, status: "Ongoing", rating: 5, tags: ["fantasy"] },
  { title: "The Overstory", author: "Richard Powers", coverUrl: "", dimensions: { heightMm: 210, widthMm: 138, thicknessMm: 34 }, owned: true, status: "Dropped", tags: ["fiction"] },
  { title: "Klara and the Sun", author: "Kazuo Ishiguro", coverUrl: "", dimensions: { heightMm: 205, widthMm: 133, thicknessMm: 19 }, owned: true, status: "Done", rating: 4, tags: ["fiction"] },
  { title: "Sapiens", author: "Yuval Noah Harari", coverUrl: "", dimensions: { heightMm: 210, widthMm: 140, thicknessMm: 30 }, owned: true, status: "Ongoing", rating: 4, tags: ["history"] },
  { title: "The Little Prince", author: "Antoine de Saint-Exupéry", coverUrl: "", dimensions: { heightMm: 190, widthMm: 125, thicknessMm: 12 }, owned: true, status: "Done", rating: 5, tags: ["classic"] },
  { title: "A Room of One's Own", author: "Virginia Woolf", coverUrl: "", dimensions: { heightMm: 198, widthMm: 129, thicknessMm: 14 }, owned: true, status: "Done", rating: 5, tags: ["essays"] },
  { title: "The Dispossessed", author: "Ursula K. Le Guin", coverUrl: "", dimensions: { heightMm: 200, widthMm: 130, thicknessMm: 25 }, owned: true, status: "New", tags: ["sci-fi"] },
  { title: "Bluets", author: "Maggie Nelson", coverUrl: "", dimensions: { heightMm: 178, widthMm: 114, thicknessMm: 11 }, owned: true, status: "Done", rating: 4, tags: ["poetry"] },
  { title: "Kitchen", author: "Banana Yoshimoto", coverUrl: "", dimensions: { heightMm: 195, widthMm: 127, thicknessMm: 13 }, owned: true, status: "Done", rating: 4, tags: ["fiction"] },
];

/** Lays the catalog onto whichever room's book slots are available. */
export function placeInitialBooks(slots: Slot[]): Book[] {
  const bookSlots = slots.filter((s) => s.kind === "book");
  return CATALOG.slice(0, bookSlots.length).map((book, i) => ({
    ...book,
    id: `book-${i}`,
    order: i,
    slotId: bookSlots[i].id,
    addedAt: new Date(2026, 0, i + 1).toISOString(),
  }));
}

/**
 * Books waiting to be shelved. Stands in for the real capture flow so the
 * placement + entrance animation can be exercised end to end.
 */
export const INBOX_BOOKS: Array<Omit<Book, "id" | "order" | "slotId" | "addedAt">> = [
  { title: "Wintering", author: "Katherine May", coverUrl: "", dimensions: { heightMm: 198, widthMm: 129, thicknessMm: 20 }, owned: true, status: "New", tags: ["nonfiction"] },
  { title: "Piranesi", author: "Susanna Clarke", coverUrl: "", dimensions: { heightMm: 200, widthMm: 130, thicknessMm: 21 }, owned: true, status: "New", tags: ["fiction"] },
  { title: "The Book of Tea", author: "Okakura Kakuzō", coverUrl: "", dimensions: { heightMm: 180, widthMm: 115, thicknessMm: 10 }, owned: true, status: "New", tags: ["nonfiction"] },
  { title: "Convenience Store Woman", author: "Sayaka Murata", coverUrl: "", dimensions: { heightMm: 190, widthMm: 122, thicknessMm: 14 }, owned: true, status: "New", tags: ["fiction"] },
];

export function initialDecor(slots: Slot[]): DecorPlacement[] {
  const decorSlots = slots.filter((s) => s.kind === "decor");
  const types = ["lamp", "cactus"] as const;
  return decorSlots.slice(0, types.length).map((slot, i) => ({
    id: `decor-${i}`,
    decorType: types[i],
    slotId: slot.id,
    scope: "universal" as const,
  }));
}
