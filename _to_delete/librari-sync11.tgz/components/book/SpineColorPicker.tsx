"use client";

import { useEffect, useRef, useState } from "react";
import { Pipette, Check } from "lucide-react";
import { bandFor } from "@/lib/books/dominant-color";

interface SpineColorPickerProps {
  /** current spine colour */
  value: string;
  /** colours sampled from the cover, offered as one-click choices */
  palette: string[];
  onChange: (bg: string, band: string) => void;
}

/** The EyeDropper API is Chromium-only; everywhere else the button is hidden. */
type EyeDropperCtor = new () => { open: () => Promise<{ sRGBHex: string }> };
function getEyeDropper(): EyeDropperCtor | null {
  if (typeof window === "undefined") return null;
  return (window as unknown as { EyeDropper?: EyeDropperCtor }).EyeDropper ?? null;
}

/**
 * Sets the colour of the book's spine. Three ways in, in the order people
 * reach for them: a swatch pulled straight off the cover, the eyedropper for
 * picking a colour off the preview itself, and a full picker for anything else.
 */
export function SpineColorPicker({ value, palette, onChange }: SpineColorPickerProps) {
  const [open, setOpen] = useState(false);
  const [supportsEyeDropper, setSupportsEyeDropper] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => setSupportsEyeDropper(Boolean(getEyeDropper())), []);

  useEffect(() => {
    if (!open) return;
    const onDown = (e: MouseEvent) => {
      if (!ref.current?.contains(e.target as Node)) setOpen(false);
    };
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && setOpen(false);
    window.addEventListener("mousedown", onDown);
    window.addEventListener("keydown", onKey);
    return () => {
      window.removeEventListener("mousedown", onDown);
      window.removeEventListener("keydown", onKey);
    };
  }, [open]);

  function pick(color: string) {
    onChange(color, bandFor(color));
  }

  async function eyedrop() {
    const EyeDropper = getEyeDropper();
    if (!EyeDropper) return;
    try {
      const { sRGBHex } = await new EyeDropper().open();
      pick(sRGBHex);
      setOpen(false);
    } catch {
      // the picker was dismissed — nothing to do
    }
  }

  return (
    <div ref={ref} className="relative">
      <button
        type="button"
        onClick={() => setOpen((o) => !o)}
        aria-label="Spine colour"
        aria-expanded={open}
        title="Spine colour"
        className="h-10 w-10 rounded-full border-2 border-white/35 shadow-token transition-transform hover:scale-105"
        style={{ background: value }}
      />

      {open && (
        <div className="glass-strong absolute left-0 top-12 z-50 w-56 rounded-token-lg p-3">
          <p className="text-[10px] font-semibold uppercase tracking-[0.14em] text-ink-muted">
            From the cover
          </p>
          <div className="mt-2 flex flex-wrap gap-2">
            {palette.length > 0 ? (
              palette.map((color) => (
                <button
                  key={color}
                  type="button"
                  onClick={() => pick(color)}
                  aria-label={`Use ${color}`}
                  className="flex h-7 w-7 items-center justify-center rounded-full border border-white/25 transition-transform hover:scale-110"
                  style={{ background: color }}
                >
                  {color === value && <Check className="h-3.5 w-3.5 text-white drop-shadow" />}
                </button>
              ))
            ) : (
              <p className="text-[11px] leading-relaxed text-ink-soft">
                No colours to sample yet — search a book first.
              </p>
            )}
          </div>

          <div className="mt-3 flex items-center gap-2 border-t border-border pt-3">
            {supportsEyeDropper && (
              <button
                type="button"
                onClick={eyedrop}
                className="flex items-center gap-1.5 rounded-token border border-border px-2.5 py-1.5 text-[11px] text-ink transition-colors hover:bg-surface-raised"
              >
                <Pipette className="h-3.5 w-3.5" strokeWidth={1.75} />
                Pick from cover
              </button>
            )}

            <label className="flex cursor-pointer items-center gap-1.5 rounded-token border border-border px-2.5 py-1.5 text-[11px] text-ink transition-colors hover:bg-surface-raised">
              Custom
              <input
                type="color"
                onChange={(e) => pick(e.target.value)}
                className="h-4 w-4 cursor-pointer border-0 bg-transparent p-0"
                aria-label="Choose a custom spine colour"
              />
            </label>
          </div>

          {!supportsEyeDropper && (
            <p className="mt-2 text-[10px] leading-relaxed text-ink-soft">
              The eyedropper needs a Chromium browser.
            </p>
          )}
        </div>
      )}
    </div>
  );
}
