"use client";

import { useEffect, useState } from "react";
import { Trash2, GripVertical, ChevronUp, ChevronDown } from "lucide-react";
import { ScenePanel } from "./ScenePanel";
import { loadReminders, saveReminders, type Reminder } from "@/lib/profile/reminders-store";

/**
 * A short list of things to come back to — finish a chapter, return a
 * borrowed book. Deliberately plain: it lives in the corner of a room, so it
 * shouldn't behave like a task manager.
 */
export function RemindersPanel({ onClose }: { onClose: () => void }) {
  const [reminders, setReminders] = useState<Reminder[]>([]);
  const [draft, setDraft] = useState("");
  const [dragId, setDragId] = useState<string | null>(null);
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    setReminders(loadReminders());
    setLoaded(true);
  }, []);

  useEffect(() => {
    if (loaded) saveReminders(reminders);
  }, [reminders, loaded]);

  const done = reminders.filter((r) => r.done).length;

  function add() {
    const text = draft.trim();
    if (!text) return;
    setReminders((prev) => [...prev, { id: `r-${Date.now()}`, text, done: false }]);
    setDraft("");
  }

  /** Moves one reminder to another's position, keeping the rest in order. */
  function reorder(fromId: string, toId: string) {
    if (fromId === toId) return;
    setReminders((prev) => {
      const from = prev.findIndex((r) => r.id === fromId);
      const to = prev.findIndex((r) => r.id === toId);
      if (from < 0 || to < 0) return prev;
      const next = [...prev];
      const [moved] = next.splice(from, 1);
      next.splice(to, 0, moved);
      return next;
    });
  }

  /** Keyboard equivalent of the drag handle — dragging alone isn't reachable. */
  function nudge(id: string, delta: number) {
    setReminders((prev) => {
      const index = prev.findIndex((r) => r.id === id);
      const target = index + delta;
      if (index < 0 || target < 0 || target >= prev.length) return prev;
      const next = [...prev];
      [next[index], next[target]] = [next[target], next[index]];
      return next;
    });
  }

  return (
    <ScenePanel title="Reminders" onClose={onClose}>
      <p className="font-body text-xs text-ink-muted">
        {reminders.length === 0
          ? "Nothing to remember yet."
          : `${done} of ${reminders.length} done`}
      </p>

      <ul className="mt-3 flex flex-col divide-y divide-border/60">
        {reminders.map((reminder, index) => (
          <li
            key={reminder.id}
            draggable
            onDragStart={() => setDragId(reminder.id)}
            onDragEnd={() => setDragId(null)}
            onDragOver={(e) => e.preventDefault()}
            onDrop={() => {
              if (dragId) reorder(dragId, reminder.id);
              setDragId(null);
            }}
            className={`flex items-center gap-2 py-2.5 transition-opacity ${
              dragId === reminder.id ? "opacity-40" : "opacity-100"
            }`}
          >
            <span className="flex shrink-0 flex-col text-ink-soft">
              <button
                type="button"
                onClick={() => nudge(reminder.id, -1)}
                disabled={index === 0}
                aria-label={`Move "${reminder.text}" up`}
                className="transition-colors hover:text-ink disabled:opacity-25"
              >
                <ChevronUp className="h-3 w-3" strokeWidth={2} />
              </button>
              <button
                type="button"
                onClick={() => nudge(reminder.id, 1)}
                disabled={index === reminders.length - 1}
                aria-label={`Move "${reminder.text}" down`}
                className="transition-colors hover:text-ink disabled:opacity-25"
              >
                <ChevronDown className="h-3 w-3" strokeWidth={2} />
              </button>
            </span>

            <GripVertical
              className="h-3.5 w-3.5 shrink-0 cursor-grab text-ink-soft active:cursor-grabbing"
              strokeWidth={1.75}
              aria-hidden
            />
            <input
              type="checkbox"
              checked={reminder.done}
              onChange={() =>
                setReminders((prev) =>
                  prev.map((r) => (r.id === reminder.id ? { ...r, done: !r.done } : r))
                )
              }
              aria-label={`Mark "${reminder.text}" ${reminder.done ? "not done" : "done"}`}
              className="h-4 w-4 shrink-0 accent-[var(--color-accent)]"
            />
            <span
              className={`min-w-0 flex-1 break-words font-body text-sm [overflow-wrap:anywhere] ${
                reminder.done ? "text-ink-soft line-through" : "text-ink"
              }`}
            >
              {reminder.text}
            </span>
            <button
              type="button"
              onClick={() => setReminders((prev) => prev.filter((r) => r.id !== reminder.id))}
              aria-label={`Delete "${reminder.text}"`}
              className="shrink-0 rounded-token p-1.5 text-ink-soft transition-colors hover:text-ink"
            >
              <Trash2 className="h-3.5 w-3.5" strokeWidth={1.75} />
            </button>
          </li>
        ))}
      </ul>

      <div className="mt-3 flex items-center gap-2">
        <input
          value={draft}
          onChange={(e) => setDraft(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && (e.preventDefault(), add())}
          placeholder="What needs doing?"
          aria-label="New reminder"
          className="min-w-0 flex-1 rounded-token-lg border border-border bg-surface-raised/70 px-3.5 py-2 font-body text-sm text-ink placeholder:text-ink-soft focus:border-accent focus:outline-none"
        />
        <button
          type="button"
          onClick={add}
          disabled={!draft.trim()}
          className="shrink-0 rounded-token-lg bg-accent px-3.5 py-2 font-body text-xs font-medium text-bg disabled:opacity-40"
        >
          Add
        </button>
      </div>
    </ScenePanel>
  );
}
