"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import type { ThemeId } from "@/lib/types";
import type { PaperTreatment } from "@/lib/theme/themes";
import {
  dueNudge,
  loadFired,
  loadWellness,
  markFired,
  NUDGES,
  type NudgeKind,
} from "@/lib/profile/wellness-store";

/**
 * SPRITES
 *
 * One entry per theme. Each strip is a horizontal row of equal cells with a
 * transparent background; `frames` says how many. Drop a new PNG into
 * public/assets/sprites and add a line here — nothing else needs to change.
 * Themes with no sprite of their own borrow the default.
 */
interface SpriteSet {
  idle: string;
  walk: string;
  frames: number;
  /** rendered size of one frame */
  width: number;
  height: number;
}

const DEFAULT_SPRITE: SpriteSet = {
  idle: "/assets/sprites/minecraft-idle.png",
  walk: "/assets/sprites/minecraft-walk.png",
  frames: 12,
  width: 64,
  height: 88,
};

const SPRITES: Partial<Record<ThemeId, SpriteSet>> = {
  minecraft: DEFAULT_SPRITE,
};

export function WellnessSprite({
  themeId,
  paper,
  onOpenSettings,
}: {
  themeId: ThemeId;
  paper: PaperTreatment;
  onOpenSettings: () => void;
}) {
  const sprite = SPRITES[themeId] ?? DEFAULT_SPRITE;
  const [nudge, setNudge] = useState<NudgeKind | null>(null);
  const openedAt = useRef(Date.now());

  useEffect(() => {
    const check = () => {
      setNudge((current) =>
        current ?? dueNudge(loadWellness(), loadFired(), openedAt.current, Date.now())
      );
    };
    check();
    const id = window.setInterval(check, 30_000);
    return () => window.clearInterval(id);
  }, []);

  const message = useMemo(
    () => NUDGES.find((n) => n.kind === nudge)?.message ?? "",
    [nudge]
  );

  function dismiss() {
    if (nudge) markFired(nudge);
    setNudge(null);
  }

  const strip = nudge ? sprite.idle : sprite.walk;

  return (
    <div className="pointer-events-none relative h-[88px] w-full max-w-sm select-none">
      {nudge && (
        <button
          type="button"
          onClick={dismiss}
          className="pointer-events-auto absolute -top-2 left-24 z-10 max-w-[15rem] rounded-token-lg px-3.5 py-2 text-left shadow-token-lg"
          style={{ background: paper.background, color: paper.ink, fontFamily: paper.fontBody }}
        >
          <span className="block text-xs leading-snug">{message}</span>
          <span className="mt-0.5 block text-[10px] opacity-60">Click to dismiss</span>
        </button>
      )}

      <button
        type="button"
        onClick={nudge ? dismiss : onOpenSettings}
        aria-label={nudge ? message : "Reminder settings"}
        title={nudge ? message : "Reminder settings"}
        className={`pointer-events-auto absolute bottom-0 left-0 ${nudge ? "" : "animate-sprite-stroll"}`}
        style={{
          width: sprite.width,
          height: sprite.height,
          backgroundImage: `url(${strip})`,
          backgroundSize: `${sprite.frames * 100}% 100%`,
          imageRendering: "pixelated",
          animationName: nudge ? "sprite-step" : undefined,
          // the step animation runs on both states; strolling adds the travel
          animation: nudge
            ? `sprite-step 1.1s steps(${sprite.frames}) infinite`
            : `sprite-step 0.9s steps(${sprite.frames}) infinite, sprite-stroll 26s ease-in-out infinite`,
        }}
      />
    </div>
  );
}
