"use client";

import { useEffect, useLayoutEffect, useMemo, useRef, useState } from "react";
import type { ThemeId } from "@/lib/types";
import type { PaperTreatment } from "@/lib/theme/themes";
import {
  dueNudge,
  loadFired,
  loadWellness,
  markFired,
  NUDGES,
  type NudgeKind,
} from "@/lib/profile/wellness-store";

/**
 * SPRITES
 *
 * One entry per theme. Each strip is a horizontal row of equal, transparent
 * cells; `frames` says how many. Drop new PNGs into public/assets/sprites and
 * add a line here — nothing else changes. Themes without their own sprite
 * borrow the default.
 */
interface SpriteSet {
  idle: string;
  walk: string;
  jump: string;
  fist: string;
  potion: string;
  frames: number;
  width: number;
  height: number;
}

const DEFAULT_SPRITE: SpriteSet = {
  idle: "/assets/sprites/minecraft-idle.png",
  walk: "/assets/sprites/minecraft-walk.png",
  jump: "/assets/sprites/minecraft-jump.png",
  fist: "/assets/sprites/minecraft-fist.png",
  potion: "/assets/sprites/minecraft-potion.png",
  frames: 12,
  width: 64,
  height: 88,
};

const SPRITES: Partial<Record<ThemeId, SpriteSet>> = {
  minecraft: DEFAULT_SPRITE,
};

/** Each nudge is acted out rather than just announced. */
const ACTION: Record<NudgeKind, keyof Pick<SpriteSet, "potion" | "jump" | "fist">> = {
  water: "potion",
  stretch: "jump",
  break: "fist",
};

export function WellnessSprite({
  themeId,
  paper,
  onOpenSettings,
}: {
  themeId: ThemeId;
  paper: PaperTreatment;
  onOpenSettings: () => void;
}) {
  const sprite = SPRITES[themeId] ?? DEFAULT_SPRITE;
  const [nudge, setNudge] = useState<NudgeKind | null>(null);
  const [travel, setTravel] = useState(0);
  const [bubbleLeft, setBubbleLeft] = useState(0);
  const wrapRef = useRef<HTMLDivElement>(null);
  const spriteRef = useRef<HTMLButtonElement>(null);
  const openedAt = useRef(Date.now());

  /**
   * The stroll spans the whole clock below rather than a fixed distance, so
   * the character never turns around in the middle of nowhere.
   */
  useLayoutEffect(() => {
    const el = wrapRef.current;
    if (!el) return;
    const measure = () => setTravel(Math.max(0, el.offsetWidth - sprite.width));
    measure();
    const observer = new ResizeObserver(measure);
    observer.observe(el);
    return () => observer.disconnect();
  }, [sprite.width]);

  useEffect(() => {
    const check = () =>
      setNudge((current) =>
        current ?? dueNudge(loadWellness(), loadFired(), openedAt.current, Date.now())
      );
    check();
    const id = window.setInterval(check, 30_000);
    return () => window.clearInterval(id);
  }, []);

  // park the bubble beside wherever the character stopped
  useLayoutEffect(() => {
    if (!nudge || !spriteRef.current || !wrapRef.current) return;
    const s = spriteRef.current.getBoundingClientRect();
    const w = wrapRef.current.getBoundingClientRect();
    setBubbleLeft(Math.min(Math.max(0, s.left - w.left + sprite.width * 0.7), Math.max(0, w.width - 180)));
  }, [nudge, sprite.width]);

  const message = useMemo(() => NUDGES.find((n) => n.kind === nudge)?.message ?? "", [nudge]);

  function dismiss() {
    if (nudge) markFired(nudge);
    setNudge(null);
  }

  const strip = nudge ? sprite[ACTION[nudge]] : sprite.walk;

  return (
    <div
      ref={wrapRef}
      className="pointer-events-none relative w-full select-none"
      style={{ height: sprite.height, ["--stroll-x" as string]: `${travel}px` }}
    >
      {nudge && (
        <button
          type="button"
          onClick={dismiss}
          style={{
            left: bubbleLeft,
            background: paper.background,
            color: paper.ink,
            fontFamily: paper.fontBody,
          }}
          className="pointer-events-auto absolute -top-3 z-10 max-w-[15rem] rounded-token-lg px-3.5 py-2 text-left shadow-token-lg"
        >
          <span className="block text-xs leading-snug">{message}</span>
          <span className="mt-0.5 block text-[10px] opacity-60">Click to dismiss</span>
        </button>
      )}

      <button
        ref={spriteRef}
        type="button"
        onClick={nudge ? dismiss : onOpenSettings}
        aria-label={nudge ? message : "Reminder settings"}
        title={nudge ? message : "Reminder settings"}
        className="pointer-events-auto absolute bottom-0 left-0"
        style={{
          width: sprite.width,
          height: sprite.height,
          backgroundImage: `url(${strip})`,
          // the strip drawn at its true size, so one cell is exactly one frame
          backgroundSize: `${sprite.frames * sprite.width}px ${sprite.height}px`,
          ["--sprite-strip" as string]: `${sprite.frames * sprite.width}px`,
          imageRendering: "pixelated",
          // both animations always run; pausing the stroll (rather than
          // removing it) keeps the character where it stopped
          animation: `sprite-step ${nudge ? "1.1s" : "0.9s"} steps(${sprite.frames}) infinite, sprite-stroll 26s ease-in-out infinite`,
          animationPlayState: nudge ? "running, paused" : "running, running",
        }}
      />
    </div>
  );
}
