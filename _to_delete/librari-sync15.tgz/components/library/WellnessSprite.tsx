"use client";

import { useEffect, useLayoutEffect, useMemo, useRef, useState } from "react";
import type { ThemeId } from "@/lib/types";
import type { PaperTreatment } from "@/lib/theme/themes";
import {
  dueNudge,
  loadFired,
  loadWellness,
  markFired,
  NUDGES,
  type NudgeKind,
} from "@/lib/profile/wellness-store";

/**
 * SPRITES
 *
 * One set per theme. Each clip is a horizontal strip of equal, transparent
 * cells — `frames` says how many, and sheets differ, so it is per clip rather
 * than per set. `actions` decides what the character does for each nudge, so
 * a sheet without a "drink" pose can act it out however suits it.
 *
 * To add a theme: drop the strips into public/assets/sprites and add a set.
 */
interface Clip {
  src: string;
  frames: number;
}

interface SpriteSet {
  /** rendered size of one cell */
  width: number;
  height: number;
  idle: Clip;
  walk: Clip;
  actions: Record<NudgeKind, Clip>;
}

const minecraft: SpriteSet = {
  width: 64,
  height: 88,
  idle: { src: "/assets/sprites/minecraft-idle.png", frames: 12 },
  walk: { src: "/assets/sprites/minecraft-walk.png", frames: 12 },
  actions: {
    water: { src: "/assets/sprites/minecraft-potion.png", frames: 12 },
    stretch: { src: "/assets/sprites/minecraft-jump.png", frames: 12 },
    break: { src: "/assets/sprites/minecraft-fist.png", frames: 12 },
  },
};

// the guinea pig sheet has no "drink" row, so eating stands in for it, and
// sitting still reads as taking a break
const cozyRoom: SpriteSet = {
  width: 92,
  height: 87,
  idle: { src: "/assets/sprites/cozy-room-idle.png", frames: 5 },
  walk: { src: "/assets/sprites/cozy-room-walk.png", frames: 4 },
  actions: {
    water: { src: "/assets/sprites/cozy-room-eat.png", frames: 5 },
    stretch: { src: "/assets/sprites/cozy-room-jump.png", frames: 5 },
    break: { src: "/assets/sprites/cozy-room-idle.png", frames: 5 },
  },
};

// the mage's rows are unlabelled; these are read off the poses — a spell
// being drawn up close for the drink, a leap, and a cast for the break
const magicalGarden: SpriteSet = {
  width: 92,
  height: 87,
  idle: { src: "/assets/sprites/magical-garden-idle.png", frames: 4 },
  walk: { src: "/assets/sprites/magical-garden-walk.png", frames: 5 },
  actions: {
    water: { src: "/assets/sprites/magical-garden-potion.png", frames: 5 },
    stretch: { src: "/assets/sprites/magical-garden-jump.png", frames: 5 },
    break: { src: "/assets/sprites/magical-garden-fist.png", frames: 4 },
  },
};

const SPRITES: Record<ThemeId, SpriteSet> = {
  minecraft,
  "cozy-room": cozyRoom,
  "magical-garden": magicalGarden,
  // no seaside sprite yet — the guinea pig stands in until one arrives
  "seaside-cafe": cozyRoom,
};

export function WellnessSprite({
  themeId,
  paper,
  onOpenSettings,
}: {
  themeId: ThemeId;
  paper: PaperTreatment;
  onOpenSettings: () => void;
}) {
  const sprite = SPRITES[themeId] ?? minecraft;
  const [nudge, setNudge] = useState<NudgeKind | null>(null);
  const [travel, setTravel] = useState(0);
  const [bubbleLeft, setBubbleLeft] = useState(0);
  const wrapRef = useRef<HTMLDivElement>(null);
  const spriteRef = useRef<HTMLButtonElement>(null);
  const openedAt = useRef(Date.now());

  /**
   * The stroll spans the whole clock below rather than a fixed distance, so
   * the character never turns around in the middle of nowhere.
   */
  useLayoutEffect(() => {
    const el = wrapRef.current;
    if (!el) return;
    const measure = () => setTravel(Math.max(0, el.offsetWidth - sprite.width));
    measure();
    const observer = new ResizeObserver(measure);
    observer.observe(el);
    return () => observer.disconnect();
  }, [sprite.width]);

  useEffect(() => {
    const check = () =>
      setNudge((current) =>
        current ?? dueNudge(loadWellness(), loadFired(), openedAt.current, Date.now())
      );
    check();
    const id = window.setInterval(check, 30_000);
    return () => window.clearInterval(id);
  }, []);

  // park the bubble beside wherever the character stopped
  useLayoutEffect(() => {
    if (!nudge || !spriteRef.current || !wrapRef.current) return;
    const s = spriteRef.current.getBoundingClientRect();
    const w = wrapRef.current.getBoundingClientRect();
    setBubbleLeft(Math.min(Math.max(0, s.left - w.left + sprite.width * 0.7), Math.max(0, w.width - 180)));
  }, [nudge, sprite.width]);

  const message = useMemo(() => NUDGES.find((n) => n.kind === nudge)?.message ?? "", [nudge]);

  function dismiss() {
    if (nudge) markFired(nudge);
    setNudge(null);
  }

  const clip = nudge ? sprite.actions[nudge] : sprite.walk;

  return (
    <div
      ref={wrapRef}
      className="pointer-events-none relative w-full select-none"
      style={{ height: sprite.height, ["--stroll-x" as string]: `${travel}px` }}
    >
      {nudge && (
        <button
          type="button"
          onClick={dismiss}
          style={{
            left: bubbleLeft,
            background: paper.background,
            color: paper.ink,
            fontFamily: paper.fontBody,
          }}
          className="pointer-events-auto absolute -top-3 z-10 max-w-[15rem] rounded-token-lg px-3.5 py-2 text-left shadow-token-lg"
        >
          <span className="block text-xs leading-snug">{message}</span>
          <span className="mt-0.5 block text-[10px] opacity-60">Click to dismiss</span>
        </button>
      )}

      <button
        ref={spriteRef}
        type="button"
        onClick={nudge ? dismiss : onOpenSettings}
        aria-label={nudge ? message : "Reminder settings"}
        title={nudge ? message : "Reminder settings"}
        className="pointer-events-auto absolute bottom-0 left-0"
        style={{
          width: sprite.width,
          height: sprite.height,
          backgroundImage: `url(${clip.src})`,
          // the strip drawn at its true size, so one cell is exactly one frame
          backgroundSize: `${clip.frames * sprite.width}px ${sprite.height}px`,
          ["--sprite-strip" as string]: `${clip.frames * sprite.width}px`,
          imageRendering: "pixelated",
          // both animations always run; pausing the stroll (rather than
          // removing it) keeps the character where it stopped
          animation: `sprite-step ${nudge ? "1.1s" : "0.9s"} steps(${clip.frames}) infinite, sprite-stroll 26s ease-in-out infinite`,
          animationPlayState: nudge ? "running, paused" : "running, running",
        }}
      />
    </div>
  );
}
