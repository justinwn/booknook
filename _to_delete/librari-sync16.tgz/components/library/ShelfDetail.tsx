"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { ChevronLeft, ChevronRight, Plus, X } from "lucide-react";
import type { Book } from "@/lib/types";
import type { PaperTreatment, Shelving } from "@/lib/theme/themes";
import { DEWEY_CLASSES, deweyClassFor } from "@/lib/library/dewey";
import { SORT_MODES, sortBooks, type SortMode } from "@/lib/library/sorting";
import { shelfSubtitle, type LibraryShelf } from "@/lib/library/shelves";
import { ShelfCompartment } from "./ShelfCompartment";
import { BookDetailCard } from "@/components/book/BookDetailCard";
import { Book3D } from "@/components/book/Book3D";

interface ShelfDetailProps {
  books: Book[];
  paper?: PaperTreatment;
  shelving: Shelving;
  /** the two bookshelves in this room, and which one is open */
  shelves: LibraryShelf[];
  activeShelfId: string;
  onShelfChange: (id: string) => void;
  /** the Dewey class to scroll to and briefly mark, from the shelf that was clicked */
  focusClass?: number | null;
  onEditBook: (book: Book) => void;
  onClose: () => void;
  onAddBook: () => void;
  /** a book still in flight toward its slot; its spine stays hidden until it lands */
  arrivingBookId?: string | null;
}

/**
 * The bookcase, seen close up. Compartments are Dewey classes — that's the
 * shelving system — and the sort control orders books along each shelf
 * without moving them between shelves.
 */
export function ShelfDetail({
  books,
  paper,
  shelving,
  shelves,
  activeShelfId,
  onShelfChange,
  focusClass,
  onEditBook,
  onClose,
  onAddBook,
  arrivingBookId,
}: ShelfDetailProps) {
  const [sort, setSort] = useState<SortMode>("recently-finished");
  const [activeBookId, setActiveBookId] = useState<string | null>(null);
  /** where on screen the active book stands, so the held-out book appears beside it */
  const [anchor, setAnchor] = useState<{ x: number; y: number } | null>(null);
  const focusRef = useRef<HTMLDivElement>(null);

  const activeIndex = Math.max(0, shelves.findIndex((s) => s.id === activeShelfId));
  const activeShelf = shelves[activeIndex];

  /** each bookshelf keeps its own records — you never see the other's books here */
  const shelfBooks = useMemo(
    () => books.filter((b) => b.owned === (activeShelf?.ownership === "owned")),
    [books, activeShelf]
  );

  const classes = useMemo(() => {
    return DEWEY_CLASSES.map((deweyClass) => ({
      deweyClass,
      books: sortBooks(
        shelfBooks.filter((b) => deweyClassFor(b.dewey).code === deweyClass.code),
        sort
      ),
    })).filter((shelf) => shelf.books.length > 0);
  }, [shelfBooks, sort]);

  const step = (delta: number) =>
    onShelfChange(shelves[(activeIndex + delta + shelves.length) % shelves.length].id);

  const activeBook = books.find((b) => b.id === activeBookId) ?? null;

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key !== "Escape") return;
      if (activeBookId) setActiveBookId(null);
      else onClose();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [activeBookId, onClose]);

  useEffect(() => {
    // scroll only as far as needed, so the header and sort control stay in view
    focusRef.current?.scrollIntoView({ behavior: "smooth", block: "nearest" });
  }, [focusClass]);

  return (
    <div className="animate-shelf-in absolute inset-0 z-40 overflow-y-auto bg-bg/75 backdrop-blur-lg">
      <div className="mx-auto min-h-full w-full max-w-5xl px-5 py-8 sm:px-8">
        <header className="glass sticky top-0 z-30 mb-10 -mx-2 flex flex-wrap items-center justify-between gap-4 rounded-token-lg px-5 py-4">
          <div className="flex items-center gap-3">
            {shelves.length > 1 && (
              <button
                type="button"
                onClick={() => step(-1)}
                aria-label="Previous shelf"
                className="rounded-token-lg border border-border p-2 text-ink-muted transition-colors hover:text-ink"
              >
                <ChevronLeft className="h-4 w-4" strokeWidth={1.75} />
              </button>
            )}

            <div>
              <h2 className="font-display text-2xl leading-tight text-ink">{activeShelf?.label}</h2>
              <p className="mt-0.5 font-body text-xs text-ink-muted">
                {activeShelf ? shelfSubtitle(activeShelf.ownership) : ""} · {shelfBooks.length}{" "}
                {shelfBooks.length === 1 ? "book" : "books"}
              </p>
            </div>

            {shelves.length > 1 && (
              <button
                type="button"
                onClick={() => step(1)}
                aria-label="Next shelf"
                className="rounded-token-lg border border-border p-2 text-ink-muted transition-colors hover:text-ink"
              >
                <ChevronRight className="h-4 w-4" strokeWidth={1.75} />
              </button>
            )}
          </div>

          <div className="flex items-center gap-3">
            <div className="flex items-center gap-1 rounded-token-lg border border-border bg-surface-raised/70 p-1">
              {SORT_MODES.map((mode) => (
                <button
                  key={mode.id}
                  type="button"
                  onClick={() => setSort(mode.id)}
                  aria-pressed={sort === mode.id}
                  className={`rounded-token px-3 py-1.5 font-body text-xs transition-colors ${
                    sort === mode.id ? "bg-accent text-bg" : "text-ink-muted hover:text-ink"
                  }`}
                >
                  {mode.label}
                </button>
              ))}
            </div>

            {/* adding from here puts the book on the shelf you are looking at */}
            <button
              type="button"
              onClick={onAddBook}
              className="flex items-center gap-1.5 rounded-token-lg bg-accent px-3.5 py-2 font-body text-xs font-medium text-bg transition-all hover:brightness-110"
            >
              <Plus className="h-3.5 w-3.5" strokeWidth={2} />
              Add book
            </button>

            <button
              type="button"
              onClick={onClose}
              aria-label="Back to the room"
              className="rounded-full border border-border bg-surface p-2 text-ink-muted transition-colors hover:text-ink"
            >
              <X className="h-4 w-4" strokeWidth={1.75} />
            </button>
          </div>
        </header>

        {classes.length === 0 ? (
          <div className="flex flex-col items-center justify-center gap-4 py-24 text-center">
            <div
              className="h-24 w-40"
              style={{
                background: shelving.frame,
                borderRadius: shelving.radius,
                boxShadow: "0 18px 40px -22px rgba(0,0,0,0.8)",
                opacity: 0.6,
              }}
              aria-hidden
            />
            <h3 className="font-display text-xl text-ink">
              {activeShelf?.ownership === "owned"
                ? "Nothing on these shelves yet"
                : "Nothing on your list yet"}
            </h3>
            <p className="max-w-sm font-body text-sm leading-relaxed text-ink-muted">
              {activeShelf?.ownership === "owned"
                ? "Books you add here get shelved by their Dewey class — a shelf appears once there is something to put on it."
                : "This shelf holds the books you don't own yet. Add one and it waits here until it's yours."}
            </p>
            <button
              type="button"
              onClick={onAddBook}
              className="mt-1 rounded-token-lg bg-accent px-6 py-3 font-body text-sm font-medium text-bg shadow-token-lg transition-all hover:brightness-110"
            >
              {activeShelf?.ownership === "owned" ? "Add your first book" : "Add a book to the list"}
            </button>
          </div>
        ) : (
        <div
          className={`grid grid-cols-1 gap-x-6 gap-y-12 ${
            shelving.columns === 3 ? "lg:grid-cols-3" : "lg:grid-cols-2"
          }`}
        >
          {classes.map((shelf) => (
            <div
              key={shelf.deweyClass.code}
              ref={shelf.deweyClass.code === focusClass ? focusRef : undefined}
            >
              <ShelfCompartment
                shelving={shelving}
                deweyClass={shelf.deweyClass}
                books={shelf.books}
                activeBookId={activeBookId}
                onActivate={(id, rect) => {
                  if (arrivingBookId) return; // let the arriving book land first
                  setActiveBookId(id);
                  setAnchor({ x: rect.left + rect.width / 2, y: rect.top + rect.height / 2 });
                }}
                highlighted={shelf.deweyClass.code === focusClass}
                arrivingBookId={arrivingBookId}
              />
            </div>
          ))}
        </div>
        )}
      </div>

      {/* The book, held out in front of the shelf, with its note beside it.
          Rendered here rather than inside the compartment because a
          horizontally scrolling shelf clips anything that overflows it. */}
      {activeBook && anchor && (
        <div className="pointer-events-none fixed inset-0 z-50" onMouseLeave={() => setActiveBookId(null)}>
          <div
            className="pointer-events-auto absolute flex items-start gap-3"
            style={{
              // clamped so the composition never runs off the edge
              left: Math.min(Math.max(anchor.x - 90, 16), window.innerWidth - 470),
              top: Math.min(Math.max(anchor.y - 150, 16), window.innerHeight - 380),
            }}
          >
            <Book3D book={activeBook} height={240} className="animate-book-settle" />
            <BookDetailCard
              book={activeBook}
              paper={paper}
              onEdit={() => onEditBook(activeBook)}
              onClose={() => setActiveBookId(null)}
            />
          </div>
        </div>
      )}

    </div>
  );
}
