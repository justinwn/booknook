"use client";

import { Suspense, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { Wallpaper } from "@/components/library/Wallpaper";
import { BookComposition } from "@/components/book/BookComposition";
import { Wordmark } from "@/components/brand/Wordmark";
import { TextField } from "@/components/ui/TextField";
import { Button } from "@/components/ui/Button";
import { GoogleButton } from "@/components/ui/GoogleButton";
import { signInWithEmail, signUpWithEmail, signInWithGoogle, isSupabaseConfigured } from "@/lib/auth/auth";
import { startEmptyLibrary } from "@/lib/profile/library-store";

type Mode = "sign-in" | "sign-up";
type Errors = { email?: string; password?: string; form?: string };

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

function validate(mode: Mode, email: string, password: string): Errors {
  const errors: Errors = {};
  if (!email.trim()) errors.email = "Enter your email address.";
  else if (!EMAIL_RE.test(email)) errors.email = "That doesn't look like an email address.";

  if (!password) errors.password = "Enter your password.";
  else if (mode === "sign-up" && password.length < 8)
    errors.password = "Use at least 8 characters.";

  return errors;
}

function LoginScreen() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const [mode, setMode] = useState<Mode>("sign-in");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [errors, setErrors] = useState<Errors>({});
  const [touched, setTouched] = useState<{ email?: boolean; password?: boolean }>({});
  const [submitting, setSubmitting] = useState(false);
  const [googleLoading, setGoogleLoading] = useState(false);

  const callbackError = searchParams.get("error");

  function revalidate(next: { email?: string; password?: string }) {
    const merged = { email, password, ...next };
    const found = validate(mode, merged.email, merged.password);
    setErrors((prev) => ({
      form: prev.form,
      email: touched.email ? found.email : prev.email,
      password: touched.password ? found.password : prev.password,
    }));
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    const found = validate(mode, email, password);
    setTouched({ email: true, password: true });
    if (found.email || found.password) {
      setErrors(found);
      return;
    }

    setErrors({});
    setSubmitting(true);
    const result =
      mode === "sign-up"
        ? await signUpWithEmail(email, password)
        : await signInWithEmail(email, password);
    setSubmitting(false);

    if (!result.ok) {
      setErrors({ form: result.message });
      return;
    }
    // A new account starts with empty shelves; signing in keeps whatever is
    // already stored for this browser.
    if (mode === "sign-up") startEmptyLibrary();
    router.push("/onboarding/theme");
  }

  async function handleGoogle() {
    setErrors({});
    setGoogleLoading(true);
    if (mode === "sign-up") startEmptyLibrary();
    const result = await signInWithGoogle("/onboarding/theme");
    if (!result.ok) {
      setGoogleLoading(false);
      // Demo mode (no Supabase project attached) still walks the flow.
      if (!isSupabaseConfigured) {
        router.push("/onboarding/theme");
        return;
      }
      setErrors({ form: result.message });
    }
  }

  return (
    <main data-theme="cozy-room" className="relative min-h-screen overflow-hidden">
      {/* the default mood, playing — the landing page is already inside the product */}
      <Wallpaper
        src="/assets/wallpapers/cozy-room.mp4"
        poster="/assets/wallpapers/cozy-room.jpg"
        scrim="heavy"
      />

      <div className="relative z-10 mx-auto grid min-h-screen w-full max-w-6xl grid-cols-1 items-center gap-20 px-6 py-20 lg:grid-cols-[1.05fr_1fr] lg:gap-8 lg:px-10">
        {/* LEFT — the book, sitting in the room */}
        <div className="flex justify-center lg:justify-start lg:pl-6">
          <BookComposition />
        </div>

        {/* RIGHT — brand, pitch, auth */}
        <div className="w-full max-w-md justify-self-center lg:justify-self-start">
          <Wordmark className="text-4xl text-white sm:text-5xl" />

          <h1 className="mt-6 font-display text-2xl font-normal leading-[1.25] text-white sm:text-[2rem]">
            Build your library, track your reads, and share it with friends
          </h1>

          <form onSubmit={handleSubmit} noValidate className="mt-9 flex flex-col gap-5">
            <TextField
              label="Email"
              type="email"
              name="email"
              autoComplete="email"
              value={email}
              onChange={(e) => {
                setEmail(e.target.value);
                revalidate({ email: e.target.value });
              }}
              onBlur={() => {
                setTouched((t) => ({ ...t, email: true }));
                setErrors((prev) => ({ ...prev, email: validate(mode, email, password).email }));
              }}
              error={errors.email}
            />
            <TextField
              label="Password"
              type="password"
              name="password"
              autoComplete={mode === "sign-up" ? "new-password" : "current-password"}
              value={password}
              onChange={(e) => {
                setPassword(e.target.value);
                revalidate({ password: e.target.value });
              }}
              onBlur={() => {
                setTouched((t) => ({ ...t, password: true }));
                setErrors((prev) => ({ ...prev, password: validate(mode, email, password).password }));
              }}
              error={errors.password}
            />

            {(errors.form || callbackError) && (
              <p role="alert" className="font-body text-sm text-[#e9a49d]">
                {errors.form ?? callbackError}
              </p>
            )}

            <Button type="submit" variant="pill-light" loading={submitting} className="mt-1 self-start">
              {mode === "sign-up" ? "Create your library" : "Enter your library"}
            </Button>
          </form>

          <div className="my-7 flex items-center gap-4 text-white/45">
            <span className="h-px flex-1 bg-white/20" />
            <span className="font-body text-[11px] uppercase tracking-[0.16em]">or</span>
            <span className="h-px flex-1 bg-white/20" />
          </div>

          <GoogleButton onClick={handleGoogle} loading={googleLoading}>
            {mode === "sign-up" ? "Sign up with Google" : "Login with Google"}
          </GoogleButton>

          <p className="mt-8 font-body text-sm text-white/65">
            {mode === "sign-up" ? "Already have a library?" : "New here?"}{" "}
            <button
              type="button"
              onClick={() => {
                setMode(mode === "sign-up" ? "sign-in" : "sign-up");
                setErrors({});
                setTouched({});
              }}
              className="font-medium text-blush underline-offset-4 hover:underline"
            >
              {mode === "sign-up" ? "Sign in" : "Create an account"}
            </button>
          </p>
        </div>
      </div>
    </main>
  );
}

export default function LoginPage() {
  return (
    <Suspense fallback={<div className="min-h-screen bg-bg" />}>
      <LoginScreen />
    </Suspense>
  );
}
