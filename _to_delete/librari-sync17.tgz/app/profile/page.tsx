"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { ArrowLeft, X } from "lucide-react";
import { useLibraryTheme } from "@/lib/theme/theme-context";
import { loadBooks } from "@/lib/profile/library-store";
import { loadFeatured, saveFeatured } from "@/lib/profile/featured-store";
import { FeaturedBookPicker } from "@/components/profile/FeaturedBookPicker";
import { ThemedFrame } from "@/components/theme/ThemedFrame";
import { Book3D } from "@/components/book/Book3D";
import type { Book } from "@/lib/types";

export default function ProfilePage() {
  const { theme, themeId } = useLibraryTheme();
  const [books, setBooks] = useState<Book[]>([]);
  const [featured, setFeatured] = useState<(string | null)[]>([null, null, null, null]);
  const [picking, setPicking] = useState<number | null>(null);
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    setBooks(loadBooks() ?? []);
    setFeatured(loadFeatured());
    setLoaded(true);
  }, []);

  useEffect(() => {
    if (loaded) saveFeatured(featured);
  }, [featured, loaded]);

  const bookFor = (id: string | null) => books.find((b) => b.id === id) ?? null;

  return (
    <main className="min-h-screen bg-gallery px-6 py-12 sm:px-10">
      <div className="mx-auto w-full max-w-3xl">
        <Link
          href="/library"
          className="inline-flex items-center gap-2 font-body text-sm text-gallery-ink/60 transition-colors hover:text-gallery-ink"
        >
          <ArrowLeft className="h-4 w-4" strokeWidth={1.75} />
          Back to your library
        </Link>

        <header className="mt-10 flex items-center gap-5">
          <div className="h-20 w-20 shrink-0 rounded-full bg-gallery-ink/10" aria-hidden />
          <div>
            <h1 className="font-display text-3xl text-gallery-ink">Your profile</h1>
            <p className="mt-1 font-body text-sm text-gallery-ink/60">
              Current mood: {theme.name} · {books.length} books
            </p>
          </div>
        </header>

        <section className="mt-12">
          <h2 className="font-body text-xs font-semibold uppercase tracking-[0.14em] text-gallery-ink/70">
            Featured books
          </h2>

          {/* the frame echoes the add-book card, so the two read as one product */}
          <ThemedFrame themeId={themeId} className="mt-4 p-5 shadow-token">
            <div className="grid grid-cols-2 gap-4 sm:grid-cols-4">
              {featured.map((id, slot) => {
                const book = bookFor(id);
                return (
                  <div key={slot} className="relative">
                    {book ? (
                      <>
                        <Book3D book={book} height={150} />
                        <button
                          type="button"
                          onClick={() =>
                            setFeatured((prev) => prev.map((v, i) => (i === slot ? null : v)))
                          }
                          aria-label={`Remove ${book.title} from featured`}
                          className="absolute -right-2 -top-2 rounded-full bg-white p-1.5 text-gallery-ink/60 shadow-token transition-colors hover:text-gallery-ink"
                        >
                          <X className="h-3 w-3" strokeWidth={2} />
                        </button>
                      </>
                    ) : (
                      <button
                        type="button"
                        onClick={() => setPicking(slot)}
                        className="flex aspect-[2/3] w-full items-center justify-center rounded-token border border-dashed border-ink/30 font-body text-xs text-ink/55 transition-colors hover:border-ink/60 hover:text-ink"
                      >
                        Empty
                      </button>
                    )}
                  </div>
                );
              })}
            </div>
          </ThemedFrame>
        </section>
      </div>

      {picking !== null && (
        <FeaturedBookPicker
          books={books}
          taken={featured}
          onPick={(book) => {
            setFeatured((prev) => prev.map((v, i) => (i === picking ? book.id : v)));
            setPicking(null);
          }}
          onClose={() => setPicking(null)}
        />
      )}
    </main>
  );
}
