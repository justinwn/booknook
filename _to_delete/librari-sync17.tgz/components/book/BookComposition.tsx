"use client";

import { useEffect, useState } from "react";
import { SAMPLE_BOOKS } from "@/lib/mock/sample-books";
import type { PaperTreatment } from "@/lib/theme/themes";
import { BookCoverImage } from "./BookCoverImage";
import { BookNote } from "./BookNote";

interface BookCompositionProps {
  /** ms between shuffles; 0 disables shuffling (single static book) */
  interval?: number;
  paper?: PaperTreatment;
}

/**
 * The hero object: a book standing in the room with its reading note tucked
 * against it. Cycles through the sample books so the login screen shows the
 * product's actual content shape rather than one fixed mock.
 */
export function BookComposition({ interval = 6000, paper }: BookCompositionProps) {
  const [index, setIndex] = useState(0);

  useEffect(() => {
    if (interval <= 0 || SAMPLE_BOOKS.length < 2) return;
    const prefersReduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (prefersReduced) return;

    const id = window.setInterval(() => {
      setIndex((i) => (i + 1) % SAMPLE_BOOKS.length);
    }, interval);
    return () => window.clearInterval(id);
  }, [interval]);

  const book = SAMPLE_BOOKS[index];

  return (
    <div className="relative" aria-live="polite">
      {/* key on the book id so each shuffle replays the settle animation */}
      <div key={book.id} className="animate-book-settle relative">
        <BookCoverImage
          src={book.coverUrl}
          alt={book.coverAlt}
          tilt={book.tilt}
          priority
          className="h-[26rem] w-[17rem] sm:h-[30rem] sm:w-[19.5rem]"
        />

        <BookNote
          title={book.title}
          author={book.author}
          rating={book.rating}
          note={book.note}
          finishedAt={book.finishedAt}
          paper={paper}
          className="absolute -bottom-4 -right-24 sm:-right-32"
          style={{ transform: "rotate(1.5deg)" }}
        />
      </div>

      {/* shuffle position dots — quiet, but they explain the motion */}
      {SAMPLE_BOOKS.length > 1 && (
        <div className="absolute -bottom-14 left-2 flex gap-1.5">
          {SAMPLE_BOOKS.map((b, i) => (
            <button
              key={b.id}
              type="button"
              onClick={() => setIndex(i)}
              aria-label={`Show ${b.title}`}
              aria-current={i === index}
              className={`h-1.5 rounded-full transition-all duration-token ease-gentle ${
                i === index ? "w-6 bg-white/80" : "w-1.5 bg-white/35 hover:bg-white/60"
              }`}
            />
          ))}
        </div>
      )}
    </div>
  );
}
