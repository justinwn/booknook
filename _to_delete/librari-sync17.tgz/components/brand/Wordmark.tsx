import clsx from "clsx";

/**
 * "Libra·ri" — the interpunct is part of the mark, so it lives here rather
 * than being retyped at call sites.
 */
export function Wordmark({ className }: { className?: string }) {
  return (
    <span className={clsx("font-display font-normal tracking-tight", className)}>
      Libra<span className="mx-[0.08em] align-middle opacity-70">·</span>ri
    </span>
  );
}
