"use client";

import { useEffect, useRef, useState } from "react";
import { QrCode, Loader2, BookOpen } from "lucide-react";
import type { Book, BookStatus } from "@/lib/types";
import type { PaperTreatment } from "@/lib/theme/themes";
import type { BookLookupResult } from "@/lib/books/providers";
import { BookNote } from "@/components/book/BookNote";
import { Book3D } from "@/components/book/Book3D";
import { deweyClassFor } from "@/lib/library/dewey";
import { extractSpineColor, extractPalette } from "@/lib/books/dominant-color";
import { SpineColorPicker } from "@/components/book/SpineColorPicker";
import { spineColorFor } from "@/lib/spine-color";
import { ThemedFrame } from "@/components/theme/ThemedFrame";
import type { ThemeId } from "@/lib/types";

export type BookDraft = Omit<Book, "id" | "order" | "slotId">;

interface BookEditorScreenProps {
  /** "add" collects a new book; "edit" revises one already on a shelf */
  mode: "add" | "edit";
  /** the book being revised — required in edit mode */
  book?: Book;
  /**
   * Ownership comes from the bookshelf this was opened from, not from a
   * field: the two shelves in a room hold separate collections, so the shelf
   * you are standing at already answers the question.
   */
  owned: boolean;
  /** which room this is being filled in, so the card can wear its materials */
  themeId: ThemeId;
  paper?: PaperTreatment;
  onCancel: () => void;
  /** the finished book, plus where its cover sat so it can fly to the shelf */
  onSubmit: (draft: BookDraft, coverRect: DOMRect | null) => void;
  onRemove?: () => void;
}

const STARS = [1, 2, 3, 4, 5];
const STATUSES: BookStatus[] = ["New", "Ongoing", "Done", "Dropped"];
/** long enough for a real thought, short enough to stay a note */
const NOTE_LIMIT = 1000;

/**
 * ONE editor for both adding and revising a book, so the two can't drift
 * apart on which fields they offer. Mode only changes the verbs (Add book vs
 * Save), whether Remove is present, and whether the fields start empty.
 *
 * Every field is editable in both modes — an ISBN search fills them in, but a
 * book with no barcode, or a bad catalogue record, can still be typed by hand.
 */
export function BookEditorScreen({ mode, book, owned, themeId, paper, onCancel, onSubmit, onRemove }: BookEditorScreenProps) {
  const [isbn, setIsbn] = useState(book?.isbn ?? "");
  const [title, setTitle] = useState(book?.title ?? "");
  const [author, setAuthor] = useState(book?.author ?? "");
  const [dewey, setDewey] = useState(book?.dewey ?? 800);
  const [startedAt, setStartedAt] = useState(book?.startedAt ?? "");
  const [finishedAt, setFinishedAt] = useState(book?.finishedAt ?? "");
  const [status, setStatus] = useState<BookStatus>(book?.status ?? "New");
  const [rating, setRating] = useState(book?.rating ?? 0);
  const [note, setNote] = useState((book?.note ?? "").slice(0, NOTE_LIMIT));
  const [coverUrl, setCoverUrl] = useState(book?.coverUrl ?? "");
  const [pageCount, setPageCount] = useState<number | null>(null);
  /** dominant cover colour, read once when the cover arrives and stored on the book */
  const [palette, setPalette] = useState<string[]>([]);
  const [spine, setSpine] = useState<{ bg: string; band: string } | null>(
    book?.spineBg && book?.spineBand ? { bg: book.spineBg, band: book.spineBand } : null
  );
  const [publishedYear, setPublishedYear] = useState<number | null>(null);

  const [searching, setSearching] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [confirmRemove, setConfirmRemove] = useState(false);
  const coverRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onCancel();
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onCancel]);

  const canSubmit = title.trim().length > 0;
  const datesApply = status !== "Dropped";
  /** a book still being read has no finish date to give, so the field goes away */
  const finishApplies = datesApply && status !== "Ongoing";
  const datesOutOfOrder = Boolean(
    finishApplies && startedAt && finishedAt && finishedAt < startedAt
  );

  const today = () => new Date().toISOString().slice(0, 10);

  /**
   * Reading dates follow the status rather than making the reader keep them
   * in sync by hand: starting a book stamps a start date, finishing one
   * stamps an end date, and dropping a book clears both — a book you
   * abandoned has no reading period to record.
   */
  function changeStatus(next: BookStatus) {
    setStatus(next);
    if (next === "Dropped") {
      setStartedAt("");
      setFinishedAt("");
      return;
    }
    if (next === "Ongoing") {
      if (!startedAt) setStartedAt(today());
      // still reading: the reading period is open-ended
      setFinishedAt("");
    }
    if (next === "Done") {
      if (!startedAt) setStartedAt(today());
      if (!finishedAt) setFinishedAt(today());
    }
    if (next === "New") setFinishedAt("");
  }

  async function search() {
    if (!isbn.trim() || searching) return;
    setSearching(true);
    setError(null);
    try {
      const res = await fetch(`/api/books/lookup?isbn=${encodeURIComponent(isbn)}`);
      const data = await res.json();
      if (!res.ok) {
        setError(data.error ?? "Couldn't find that book.");
        return;
      }
      const result = data as BookLookupResult;
      setTitle(result.title);
      setAuthor(result.author);
      setCoverUrl(result.coverUrl ?? "");
      // the spine takes its colour from the jacket
      if (result.coverUrl) {
        setSpine(await extractSpineColor(result.coverUrl));
        setPalette(await extractPalette(result.coverUrl));
      } else {
        setSpine(null);
        setPalette([]);
      }
      setPageCount(result.pageCount);
      setPublishedYear(result.publishedYear);
      // an unclassified book goes to 800s Literature, the likeliest home in a
      // personal collection — the field stays editable either way
      setDewey(result.dewey ?? 800);
    } catch {
      setError("Couldn't reach the book service. Check your connection.");
    } finally {
      setSearching(false);
    }
  }

  function submit() {
    if (!canSubmit || datesOutOfOrder) return;
    const thickness = pageCount
      ? Math.min(40, Math.max(12, Math.round(pageCount / 12)))
      : book?.dimensions.thicknessMm ?? 20;

    onSubmit(
      {
        ...(book ?? {}),
        isbn: isbn.trim() || undefined,
        title: title.trim(),
        author: author.trim(),
        coverUrl,
        spineBg: spine?.bg,
        spineBand: spine?.band,
        dewey,
        dimensions: book?.dimensions ?? { heightMm: 198, widthMm: 129, thicknessMm: thickness },
        rating: rating || undefined,
        note: note.trim() || undefined,
        tags: book?.tags ?? [],
        owned,
        // status only means something for a book you own
        status: owned ? status : undefined,
        startedAt: datesApply && startedAt ? startedAt : undefined,
        finishedAt: finishApplies && finishedAt ? finishedAt : undefined,
        addedAt: book?.addedAt ?? new Date().toISOString(),
      },
      coverRef.current?.getBoundingClientRect() ?? null
    );
  }

  const label = "text-[11px] font-semibold uppercase tracking-[0.16em] text-ink-muted";
  // the form is written in the room's own hand, same as its notes
  const themeType: React.CSSProperties = { fontFamily: paper?.fontBody };
  const textField =
    "w-full rounded-token-lg border border-border bg-surface-raised/70 px-5 py-2.5 text-sm text-ink placeholder:text-ink-soft focus:border-accent focus:outline-none";
  const pill = (active: boolean) =>
    `rounded-full border px-4 py-2 font-body text-xs transition-colors ${
      active ? "border-accent bg-accent/20 text-ink" : "border-border text-ink-muted hover:text-ink"
    }`;

  return (
    <div className="animate-shelf-in absolute inset-0 z-[60] overflow-y-auto bg-bg/70 backdrop-blur-xl">
      <div className="mx-auto grid min-h-full w-full max-w-5xl grid-cols-1 items-center gap-12 px-6 py-14 lg:grid-cols-[0.9fr_1fr] lg:gap-16 lg:px-10">
        {/* LEFT — the book as it will look on the shelf, filling in as you go */}
        <div className="relative mx-auto w-full max-w-sm lg:mx-0">
          <div
            className="pointer-events-none absolute -inset-16 -z-10"
            style={{
              background:
                "radial-gradient(60% 55% at 45% 40%, rgb(var(--color-accent-soft-rgb) / 0.20), transparent 70%)",
            }}
            aria-hidden
          />
          <div className="flex items-start gap-4">
            <SpineColorPicker
              value={spine?.bg ?? spineColorFor({ title: title || "Untitled" }).bg}
              palette={palette}
              onChange={(bg, band) => setSpine({ bg, band })}
            />

            <div ref={coverRef} className="flex-1">
            {title ? (
              <Book3D
                key={coverUrl || title}
                book={
                  {
                    title,
                    author,
                    coverUrl,
                    spineBg: spine?.bg,
                    spineBand: spine?.band,
                    dimensions: {
                      heightMm: 198,
                      widthMm: 129,
                      thicknessMm: pageCount ? Math.min(40, Math.max(12, Math.round(pageCount / 12))) : 22,
                    },
                  } as Book
                }
                height={330}
                className="animate-book-settle"
              />
            ) : (
              <div className="flex aspect-[2/3] w-full flex-col items-center justify-center gap-3 rounded-token border border-dashed border-border bg-surface/60">
                <BookOpen className="h-8 w-8 text-ink-soft" strokeWidth={1.25} />
                <p className="px-6 text-center text-[11px] leading-relaxed text-ink-soft">
                  Search an ISBN and the book appears here
                </p>
              </div>
              )}
            </div>
          </div>

          <div className="absolute -bottom-10 -right-2 w-[56%] min-w-[13rem]" style={{ transform: "rotate(2deg)" }}>
            {title || rating || note ? (
              <BookNote
                title={title || "Untitled"}
                author={author || "Unknown author"}
                rating={rating}
                note={note || "Add a note and it shows up here."}
                finishedAt={finishApplies ? finishedAt || undefined : undefined}
                startedAt={startedAt || undefined}
                ongoing={status === "Ongoing"}
                paper={paper}
                className="w-full rounded-[2px]"
              />
            ) : (
              // the same note stock, before anything has been written on it
              <BookNote
                title=""
                author=""
                rating={0}
                note=""
                paper={paper}
                className="w-full rounded-[2px] opacity-70"
              />
            )}
          </div>
        </div>

        {/* RIGHT — the form. Identical field set in both modes. */}
        <ThemedFrame themeId={themeId} className="w-full shadow-token-lg">
        <div className="w-full rounded-token-lg p-6 sm:p-8" style={themeType}>
          <h2
            className="text-[13px] font-semibold uppercase tracking-[0.16em] text-ink"
            style={{ fontFamily: paper?.fontDisplay, letterSpacing: paper?.displayTracking }}
          >
            {mode === "add" ? "Add new book" : "Edit book"}
          </h2>

          <div className="mt-6 flex flex-col gap-2">
            <label className={label} htmlFor="book-isbn">ISBN</label>
            <div className="flex items-center gap-2.5">
              <div className="relative flex-1">
                <input
                  id="book-isbn"
                  value={isbn}
                  onChange={(e) => {
                    setIsbn(e.target.value);
                    setError(null);
                  }}
                  onKeyDown={(e) => e.key === "Enter" && (e.preventDefault(), search())}
                  inputMode="numeric"
                  placeholder="978…"
                  aria-invalid={error ? true : undefined}
                  aria-describedby={error ? "book-isbn-error" : undefined}
                  className={`${textField} pr-11`}
                />
                <QrCode
                  className="pointer-events-none absolute right-4 top-1/2 h-4 w-4 -translate-y-1/2 text-ink-soft"
                  strokeWidth={1.5}
                  aria-hidden
                />
              </div>
              <button
                type="button"
                onClick={search}
                disabled={searching || !isbn.trim()}
                className="flex shrink-0 items-center gap-2 rounded-token-lg bg-paper px-5 py-2.5 font-body text-sm font-medium text-[#2b2419] transition-all hover:brightness-105 disabled:opacity-40"
              >
                {searching && <Loader2 className="h-3.5 w-3.5 animate-spin" />}
                {searching ? "Searching" : "Search"}
              </button>
            </div>
            {error && (
              <p id="book-isbn-error" role="alert" className="font-body text-xs text-[#e9a49d]">
                {error}
              </p>
            )}
          </div>

          {title && (
            <p className="mt-3 font-body text-xs text-ink-muted">
              <span className="text-ink">{title}</span> · {author} · shelves under{" "}
              {deweyClassFor(dewey).code.toString().padStart(3, "0")} {deweyClassFor(dewey).label}
            </p>
          )}

          <div className="mt-7 flex flex-col gap-2">
              <span className={label}>Status</span>
              <div className="flex flex-wrap gap-2">
                {STATUSES.map((s) => (
                  <button key={s} type="button" onClick={() => changeStatus(s)} aria-pressed={status === s} className={pill(status === s)}>
                    {s}
                  </button>
                ))}
            </div>
          </div>

          {datesApply && (
            <div className="mt-6 flex flex-wrap gap-4">
              <div className="flex flex-col gap-2">
                <label className={label} htmlFor="book-started">Started</label>
                <input
                  id="book-started"
                  type="date"
                  value={startedAt}
                  max={today()}
                  onChange={(e) => setStartedAt(e.target.value)}
                  className={`${textField} w-[10.5rem]`}
                />
              </div>
              {finishApplies ? (
                <div className="flex flex-col gap-2">
                  <label className={label} htmlFor="book-finished">Finished</label>
                  <input
                    id="book-finished"
                    type="date"
                    value={finishedAt}
                    max={today()}
                    onChange={(e) => setFinishedAt(e.target.value)}
                    aria-invalid={datesOutOfOrder}
                    aria-describedby={datesOutOfOrder ? "book-dates-error" : undefined}
                    className={`${textField} w-[10.5rem]`}
                  />
                </div>
              ) : (
                <div className="flex flex-col justify-end gap-2 pb-3">
                  <span className="font-body text-xs text-ink-soft">
                    Still reading, so the note reads {startedAt ? "from this date" : "from the start date"} to present.
                  </span>
                </div>
              )}
              {datesOutOfOrder && (
                <p id="book-dates-error" role="alert" className="w-full font-body text-[11px] text-[#e9a49d]">
                  The finish date is before the start date.
                </p>
              )}
            </div>
          )}

          <fieldset className="mt-7 flex flex-col gap-2">
            <legend className={label}>Rating</legend>
            <div className="flex gap-1.5">
              {STARS.map((n) => (
                <button
                  key={n}
                  type="button"
                  onClick={() => setRating(rating === n ? 0 : n)}
                  aria-label={`${n} star${n > 1 ? "s" : ""}`}
                  aria-pressed={rating === n}
                  className={`text-2xl leading-none transition-all duration-150 hover:scale-110 ${
                    n <= rating ? "text-[#e8a13a]" : "text-ink-soft opacity-35 hover:opacity-60"
                  }`}
                >
                  ★
                </button>
              ))}
            </div>
          </fieldset>

          <div className="mt-7 flex flex-col gap-2">
            <div className="flex items-baseline justify-between gap-3">
              <label className={label} htmlFor="book-note">Note</label>
              <span
                className={`text-[11px] tabular-nums ${
                  note.length >= NOTE_LIMIT ? "text-[#e9a49d]" : "text-ink-soft"
                }`}
              >
                {note.length}/{NOTE_LIMIT}
              </span>
            </div>
            <textarea
              id="book-note"
              value={note}
              onChange={(e) => setNote(e.target.value.slice(0, NOTE_LIMIT))}
              maxLength={NOTE_LIMIT}
              rows={5}
              placeholder="What did you think of it?"
              className="max-h-56 w-full resize-y overflow-y-auto rounded-token-lg border border-border bg-surface-raised/70 p-4 text-sm leading-relaxed text-ink placeholder:text-ink-soft focus:border-accent focus:outline-none [overflow-wrap:anywhere]"
            />
          </div>

          <div className="mt-8 flex items-center justify-between gap-4">
            {mode === "edit" && onRemove ? (
              confirmRemove ? (
                <span className="flex items-center gap-2">
                  <button type="button" onClick={onRemove} className="rounded-token-lg bg-[#8d3a32] px-4 py-2 font-body text-xs text-white">
                    Remove for good
                  </button>
                  <button type="button" onClick={() => setConfirmRemove(false)} className="font-body text-xs text-ink-muted hover:text-ink">
                    Keep
                  </button>
                </span>
              ) : (
                <button type="button" onClick={() => setConfirmRemove(true)} className="font-body text-sm text-[#c8776e] hover:underline">
                  Remove
                </button>
              )
            ) : (
              <span />
            )}

            <span className="flex items-center gap-4">
              <button type="button" onClick={onCancel} className="font-body text-sm text-ink-muted transition-colors hover:text-ink">
                Cancel
              </button>
              <button
                type="button"
                onClick={submit}
                disabled={!canSubmit || datesOutOfOrder}
                className="rounded-token-lg bg-accent px-7 py-3 font-body text-sm font-medium text-bg shadow-token-lg transition-all hover:brightness-110 disabled:cursor-not-allowed disabled:opacity-40"
              >
                {mode === "add" ? "Add book" : "Save"}
              </button>
            </span>
          </div>

          {!canSubmit && (
            <p className="mt-3 text-right font-body text-[11px] text-ink-soft">
              Search an ISBN to pull in the cover and details.
            </p>
          )}
        </div>
        </ThemedFrame>
      </div>
    </div>
  );
}
