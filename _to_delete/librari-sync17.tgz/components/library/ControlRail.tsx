"use client";

import { Plus, Waves, ListChecks, Palette, User, Share2 } from "lucide-react";
import clsx from "clsx";
import { SceneControl } from "./SceneControl";

export type ControlId = "add" | "ambient" | "reminders" | "theme" | "profile" | "share";

interface ControlRailProps {
  active: ControlId | null;
  onSelect: (id: ControlId) => void;
}

/**
 * The room's controls: a column of solid discs down the right-hand side —
 * objects in the environment, deliberately not a docked sidebar. On narrow
 * screens the column becomes a scrollable rail along the bottom so the room
 * stays whole rather than being squeezed.
 *
 * The lower-left corner is left clear for the playlist, which lands later.
 */
export function ControlRail({ active, onSelect }: ControlRailProps) {
  return (
    <div
      className={clsx(
        "pointer-events-none fixed z-30 flex gap-2.5",
        // mobile: scrollable rail along the bottom
        "bottom-0 left-0 right-0 flex-row items-end overflow-x-auto px-4 pb-4",
        // desktop: a column down the right-hand side
        "lg:bottom-auto lg:left-auto lg:right-6 lg:top-1/2 lg:w-auto lg:-translate-y-1/2",
        "lg:flex-col lg:items-end lg:overflow-visible lg:px-0 lg:pb-0"
      )}
    >
      <div className="pointer-events-auto contents">
        <SceneControl
          icon={<Plus className="h-5 w-5" strokeWidth={1.5} />}
          label="Add book"
          active={active === "add"}
          onClick={() => onSelect("add")}
        />
        <SceneControl
          icon={<Waves className="h-5 w-5" strokeWidth={1.5} />}
          label="Ambient"
          active={active === "ambient"}
          onClick={() => onSelect("ambient")}
        />
        <SceneControl
          icon={<ListChecks className="h-5 w-5" strokeWidth={1.5} />}
          label="Reminders"
          active={active === "reminders"}
          onClick={() => onSelect("reminders")}
        />
        <SceneControl
          icon={<Palette className="h-5 w-5" strokeWidth={1.5} />}
          label="Library"
          active={active === "theme"}
          onClick={() => onSelect("theme")}
        />
        <SceneControl
          icon={<User className="h-5 w-5" strokeWidth={1.5} />}
          label="Profile"
          active={active === "profile"}
          onClick={() => onSelect("profile")}
        />
        <SceneControl
          icon={<Share2 className="h-5 w-5" strokeWidth={1.5} />}
          label="Share"
          active={active === "share"}
          onClick={() => onSelect("share")}
        />
      </div>
    </div>
  );
}
