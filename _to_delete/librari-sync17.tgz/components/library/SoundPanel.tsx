"use client";

import { Pause, Play } from "lucide-react";
import { ScenePanel } from "./ScenePanel";

export type SoundMode = "playlist" | "ambient";

interface SoundPanelProps {
  mode: SoundMode;
  playing: boolean;
  onTogglePlay: () => void;
  onClose: () => void;
}

// Placeholder track lists — real playlist sources and ambient beds aren't
// specified yet, so these name the shape of the feature without inventing
// a music service integration.
const CONTENT: Record<SoundMode, { title: string; blurb: string; items: string[] }> = {
  playlist: {
    title: "Playlist",
    blurb: "Music to read to. Connect a source to bring in your own.",
    items: ["Morning pages", "Long chapters", "Rain on the window"],
  },
  ambient: {
    title: "Ambient sound",
    blurb: "The room's own noise, quietly underneath.",
    items: ["Fireplace", "Distant rain", "Library hum"],
  },
};

export function SoundPanel({ mode, playing, onTogglePlay, onClose }: SoundPanelProps) {
  const { title, blurb, items } = CONTENT[mode];

  return (
    <ScenePanel title={title} onClose={onClose}>
      <p className="font-body text-xs leading-relaxed text-ink-muted">{blurb}</p>

      <ul className="mt-3 flex flex-col divide-y divide-border/60">
        {items.map((item, i) => (
          <li key={item} className="flex items-center justify-between py-2.5">
            <span className="font-body text-sm text-ink">{item}</span>
            {i === 0 && (
              <button
                type="button"
                onClick={onTogglePlay}
                aria-label={playing ? `Pause ${item}` : `Play ${item}`}
                className="rounded-full bg-accent/15 p-1.5 text-accent transition-colors hover:bg-accent/25"
              >
                {playing ? <Pause className="h-3.5 w-3.5" /> : <Play className="h-3.5 w-3.5" />}
              </button>
            )}
          </li>
        ))}
      </ul>

      <p className="mt-3 font-body text-[11px] text-ink-soft">Audio playback isn&apos;t wired up yet.</p>
    </ScenePanel>
  );
}
