import type { ThemeDefinition } from "@/lib/theme/themes";
import { BookNote } from "@/components/book/BookNote";
import { SAMPLE_BOOKS } from "@/lib/mock/sample-books";
import { Book3D } from "@/components/book/Book3D";
import type { Book } from "@/lib/types";

/**
 * What a book looks like in this mood: a sample cover with its reading note
 * tucked against it. The wallpaper is already behind the whole page, so the
 * preview shows the thing that actually changes between themes — the note's
 * paper stock and its typography.
 */
export function ThemePreview({ theme }: { theme: ThemeDefinition }) {
  const sample = SAMPLE_BOOKS[0];

  return (
    <div className="relative w-full max-w-sm">
      <div
        className="pointer-events-none absolute -inset-20 -z-10"
        style={{
          background:
            "radial-gradient(58% 52% at 46% 42%, rgb(var(--color-accent-soft-rgb) / 0.22), transparent 72%)",
        }}
        aria-hidden
      />

      <Book3D
        key={`${theme.id}-cover`}
        book={
          {
            title: sample.title,
            author: sample.author,
            coverUrl: sample.coverUrl,
            dimensions: { heightMm: 198, widthMm: 129, thicknessMm: 22 },
          } as Book
        }
        height={300}
        className="animate-book-settle"
      />

      <BookNote
        key={`${theme.id}-note`}
        title={sample.title}
        author="Homer"
        rating={sample.rating}
        note={sample.note}
        finishedAt="2025-06-18"
        paper={theme.paper}
        className="animate-book-settle !absolute -bottom-10 -right-2 w-[58%] min-w-[13rem] rounded-[2px]"
      />
    </div>
  );
}
