"use client";

import type { ReactNode } from "react";
import type { ThemeId } from "@/lib/types";

/**
 * Dresses a card in its room's materials. The decoration is drawn as SVG
 * layered around the card rather than baked into an image, so it scales with
 * the card and recolours with the theme. Everything here is
 * `pointer-events-none` — it is scenery, and must never eat a click meant for
 * the form underneath.
 */

function CozyClouds() {
  return (
    <svg
      className="pointer-events-none absolute -inset-6 h-[calc(100%+3rem)] w-[calc(100%+3rem)]"
      viewBox="0 0 400 500"
      preserveAspectRatio="none"
      aria-hidden
    >
      <g fill="rgba(206, 208, 245, 0.20)">
        {/* clouds gathering at the upper corners, thinning toward the middle */}
        <ellipse cx="46" cy="34" rx="42" ry="20" />
        <ellipse cx="84" cy="24" rx="30" ry="15" />
        <ellipse cx="18" cy="52" rx="26" ry="13" />
        <ellipse cx="352" cy="30" rx="40" ry="19" />
        <ellipse cx="316" cy="20" rx="26" ry="13" />
        <ellipse cx="382" cy="50" rx="24" ry="12" />
      </g>
      <g fill="rgba(206, 208, 245, 0.12)">
        <ellipse cx="30" cy="470" rx="38" ry="17" />
        <ellipse cx="368" cy="480" rx="34" ry="15" />
      </g>
    </svg>
  );
}

function GardenVines() {
  return (
    <svg
      className="pointer-events-none absolute -inset-5 h-[calc(100%+2.5rem)] w-[calc(100%+2.5rem)]"
      viewBox="0 0 400 500"
      preserveAspectRatio="none"
      aria-hidden
    >
      <g fill="none" stroke="#6f8f52" strokeWidth="3" strokeLinecap="round">
        <path d="M14 60 C 30 130, 4 200, 22 268 C 36 322, 10 380, 24 440" />
        <path d="M386 40 C 368 96, 392 150, 374 206" />
      </g>
      <g fill="#7ea45e">
        {[90, 150, 214, 290, 360, 420].map((y, i) => (
          <ellipse key={y} cx={i % 2 ? 30 : 8} cy={y} rx="13" ry="7" transform={`rotate(${i % 2 ? 24 : -24} ${i % 2 ? 30 : 8} ${y})`} />
        ))}
        <ellipse cx="392" cy="78" rx="12" ry="6" transform="rotate(28 392 78)" />
        <ellipse cx="368" cy="140" rx="12" ry="6" transform="rotate(-28 368 140)" />
      </g>
      {/* flowers in the mood's yellows, oranges and pinks */}
      {[
        { x: 18, y: 118, c: "#e8a13a" },
        { x: 26, y: 250, c: "#df6ba0" },
        { x: 16, y: 392, c: "#e2762f" },
        { x: 384, y: 106, c: "#df6ba0" },
        { x: 376, y: 186, c: "#e8a13a" },
      ].map((f) => (
        <g key={`${f.x}-${f.y}`}>
          {[0, 72, 144, 216, 288].map((angle) => (
            <ellipse
              key={angle}
              cx={f.x}
              cy={f.y - 7}
              rx="4"
              ry="7"
              fill={f.c}
              transform={`rotate(${angle} ${f.x} ${f.y})`}
            />
          ))}
          <circle cx={f.x} cy={f.y} r="3" fill="#f6e3a8" />
        </g>
      ))}
    </svg>
  );
}

function SeasideWave() {
  return (
    <svg
      className="pointer-events-none absolute -bottom-4 -left-4 h-40 w-64"
      viewBox="0 0 260 160"
      aria-hidden
    >
      <g fill="none" strokeLinecap="round">
        <path d="M-10 118 C 24 96, 58 140, 96 116 C 130 94, 160 132, 200 110" stroke="#3aa3a0" strokeWidth="5" opacity="0.75" />
        <path d="M-10 138 C 28 118, 62 158, 104 134 C 138 114, 168 148, 210 128" stroke="#7fc9c2" strokeWidth="4" opacity="0.6" />
        <path d="M-6 98 C 18 84, 44 108, 70 92" stroke="#bfe6df" strokeWidth="3" opacity="0.5" />
      </g>
    </svg>
  );
}

function MinecraftPixels({ radiusless = true }: { radiusless?: boolean }) {
  // a stepped outline: squares stacked outward at each corner read as pixels
  const steps = [
    { x: 0, y: 0 },
    { x: 12, y: 0 },
    { x: 0, y: 12 },
  ];
  return (
    <div className="pointer-events-none absolute inset-0" aria-hidden>
      <div
        className="absolute inset-0 border-[6px]"
        style={{ borderColor: "#7a5a34", borderRadius: radiusless ? 0 : 4 }}
      />
      <div className="absolute inset-[6px] border-[3px]" style={{ borderColor: "#a67c46" }} />
      {[
        { top: -12, left: -12 },
        { top: -12, right: -12 },
        { bottom: -12, left: -12 },
        { bottom: -12, right: -12 },
      ].map((pos, i) => (
        <div key={i} className="absolute h-6 w-6" style={pos}>
          {steps.map((s, j) => (
            <span
              key={j}
              className="absolute h-3 w-3"
              style={{
                background: j === 0 ? "#7a5a34" : "#a67c46",
                left: s.x,
                top: s.y,
              }}
            />
          ))}
        </div>
      ))}
    </div>
  );
}

const BACKGROUNDS: Partial<Record<ThemeId, string>> = {
  "cozy-room":
    "linear-gradient(155deg, rgba(72,64,116,0.92), rgba(38,34,60,0.94) 55%, rgba(26,24,42,0.96))",
  "magical-garden":
    "linear-gradient(155deg, rgba(58,42,92,0.92), rgba(30,22,52,0.95))",
  "seaside-cafe":
    "linear-gradient(155deg, rgba(255,255,255,0.94), rgba(226,240,238,0.96))",
  minecraft: "linear-gradient(180deg, rgba(52,42,30,0.96), rgba(34,27,18,0.97))",
};

export function ThemedFrame({
  themeId,
  className,
  children,
}: {
  themeId: ThemeId;
  className?: string;
  children: ReactNode;
}) {
  return (
    // the frame carries its own theme, so anything inside resolves against
    // the room's tokens rather than whatever page it happens to sit on
    <div
      data-theme={themeId}
      className={`relative ${className ?? ""}`}
      style={{ background: BACKGROUNDS[themeId], borderRadius: "var(--radius-lg)" }}
    >
      {themeId === "cozy-room" && <CozyClouds />}
      {themeId === "magical-garden" && <GardenVines />}
      {themeId === "seaside-cafe" && <SeasideWave />}
      {themeId === "minecraft" && <MinecraftPixels />}
      <div className="relative">{children}</div>
    </div>
  );
}
