import type { ButtonHTMLAttributes, ReactNode } from "react";
import clsx from "clsx";

interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: "primary" | "ghost" | "pill-dark" | "pill-light";
  icon?: ReactNode;
  loading?: boolean;
}

// A deliberately un-SaaS button: solid fill or plain-bordered ghost, plus
// two pill variants for the login/onboarding chrome. Tactile press-down on
// click rather than a flat color swap.
export function Button({
  variant = "primary",
  icon,
  loading,
  className,
  children,
  disabled,
  ...props
}: ButtonProps) {
  return (
    <button
      className={clsx(
        "inline-flex items-center justify-center gap-2",
        "font-body text-sm font-medium tracking-wide transition-all duration-token ease-gentle",
        "active:scale-[0.97] active:duration-75",
        "disabled:cursor-not-allowed disabled:opacity-50",
        variant === "primary" && "rounded-token bg-accent px-6 py-3 text-bg shadow-token hover:brightness-105",
        variant === "ghost" && "rounded-token border border-border bg-transparent px-6 py-3 text-ink hover:bg-surface",
        variant === "pill-dark" &&
          "rounded-full bg-[#14120f] px-8 py-3.5 text-white shadow-token-lg hover:bg-[#241f19]",
        variant === "pill-light" &&
          "rounded-full bg-blush px-8 py-3.5 text-blush-ink shadow-token-lg hover:brightness-[1.03]",
        className
      )}
      disabled={loading || disabled}
      {...props}
    >
      {icon}
      {loading ? "Just a moment…" : children}
    </button>
  );
}
