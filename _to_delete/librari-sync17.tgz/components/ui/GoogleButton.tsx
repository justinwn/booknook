"use client";

import clsx from "clsx";
import type { ButtonHTMLAttributes } from "react";

function GoogleMark() {
  return (
    <span className="flex h-7 w-7 items-center justify-center rounded-full bg-white">
      <svg viewBox="0 0 24 24" className="h-4 w-4" aria-hidden>
        <path fill="#4285F4" d="M23.5 12.3c0-.8-.1-1.6-.2-2.3H12v4.5h6.5a5.6 5.6 0 01-2.4 3.7v3h3.9c2.3-2.1 3.5-5.2 3.5-8.9z" />
        <path fill="#34A853" d="M12 24c3.2 0 5.9-1.1 7.9-2.9l-3.9-3c-1.1.7-2.4 1.2-4 1.2-3.1 0-5.7-2.1-6.6-4.9H1.4v3.1A12 12 0 0012 24z" />
        <path fill="#FBBC05" d="M5.4 14.4a7.2 7.2 0 010-4.6V6.7H1.4a12 12 0 000 10.8l4-3.1z" />
        <path fill="#EA4335" d="M12 4.8c1.8 0 3.3.6 4.6 1.8l3.4-3.4A12 12 0 001.4 6.7l4 3.1C6.3 6.9 8.9 4.8 12 4.8z" />
      </svg>
    </span>
  );
}

interface GoogleButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  loading?: boolean;
}

export function GoogleButton({ loading, className, children, ...props }: GoogleButtonProps) {
  return (
    <button
      type="button"
      className={clsx(
        "inline-flex items-center gap-3 rounded-full bg-blush py-2 pl-2 pr-7",
        "font-body text-sm font-medium text-blush-ink shadow-token-lg",
        "transition-all duration-token ease-gentle hover:brightness-[1.03] hover:shadow-token-lg",
        "active:scale-[0.98] disabled:cursor-not-allowed disabled:opacity-60",
        className
      )}
      disabled={loading || props.disabled}
      {...props}
    >
      <GoogleMark />
      {loading ? "Opening Google…" : children ?? "Login with Google"}
    </button>
  );
}
