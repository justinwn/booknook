"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { useLibraryTheme } from "@/lib/theme/theme-context";
import { ROOM_SLOT_MAPS, getRoomSlots } from "@/lib/library/slot-maps";
import { placeInitialBooks, initialDecor, INBOX_BOOKS } from "@/lib/mock/library";
import type { Book } from "@/lib/types";
import { RoomScene } from "@/components/library/RoomScene";
import { BookLayer } from "@/components/library/BookLayer";
import { ControlRail, type ControlId } from "@/components/library/ControlRail";
import { AddBookPanel, type AddBookMethod } from "@/components/library/AddBookPanel";
import { SharePanel } from "@/components/library/SharePanel";
import { SoundPanel } from "@/components/library/SoundPanel";
import { Wordmark } from "@/components/brand/Wordmark";
import { ShelfDetail } from "@/components/library/ShelfDetail";
import { deweyClassFor } from "@/lib/library/dewey";

export default function LibraryPage() {
  const router = useRouter();
  const { themeId, theme } = useLibraryTheme();

  const slots = useMemo(() => getRoomSlots(themeId), [themeId]);
  const room = ROOM_SLOT_MAPS[themeId];

  const [books, setBooks] = useState<Book[]>(() => placeInitialBooks(slots));

  /**
   * The collection belongs to the reader; slot assignment belongs to the
   * room. Rooms have different shelf geometry, so when the mood changes the
   * books are re-seated in `order` sequence onto the new room's slots rather
   * than keeping ids that don't exist there.
   */
  useEffect(() => {
    const bookSlots = slots.filter((s) => s.kind === "book");
    setBooks((prev) =>
      [...prev]
        .sort((a, b) => a.order - b.order)
        .map((book, i) => (bookSlots[i] ? { ...book, slotId: bookSlots[i].id } : book))
        .filter((book, i) => Boolean(bookSlots[i]))
    );
  }, [slots]);

  const decor = useMemo(() => initialDecor(slots), [slots]);
  const [recentlyAddedId, setRecentlyAddedId] = useState<string | null>(null);
  const [openPanel, setOpenPanel] = useState<ControlId | null>(null);
  const [soundPlaying, setSoundPlaying] = useState(false);

  /**
   * Room → shelf transition. `zoom` holds the origin point (in room
   * percentage coordinates) so the room scales *toward the shelf that was
   * clicked* rather than the centre of the screen — that's what makes it
   * read as moving closer to a specific shelf instead of a generic zoom.
   */
  const [zoom, setZoom] = useState<{ x: number; y: number } | null>(null);
  const [shelfOpen, setShelfOpen] = useState(false);
  const [focusClass, setFocusClass] = useState<number | null>(null);
  const inboxCursor = useRef(0);

  /**
   * Places the next queued book into a slot. This is the seam the real
   * capture flow plugs into: whatever the scan/ISBN/manual flows produce,
   * they hand a Book here and the entrance animation is already wired.
   */
  const placeBook = useCallback(
    (targetSlotId?: string) => {
      const occupied = new Set(books.map((b) => b.slotId));
      const slot = targetSlotId
        ? slots.find((s) => s.id === targetSlotId && s.kind === "book" && !occupied.has(s.id))
        : slots.find((s) => s.kind === "book" && !occupied.has(s.id));

      if (!slot || inboxCursor.current >= INBOX_BOOKS.length) return;

      const template = INBOX_BOOKS[inboxCursor.current];
      inboxCursor.current += 1;

      const book: Book = {
        ...template,
        id: `inbox-${inboxCursor.current}`,
        order: books.length,
        slotId: slot.id,
        addedAt: new Date().toISOString(),
      };

      setBooks((prev) => [...prev, book]);
      setRecentlyAddedId(book.id);
      window.setTimeout(() => setRecentlyAddedId((id) => (id === book.id ? null : id)), 1000);
    },
    [books, slots]
  );

  function openShelf(rowId: string, center: { x: number; y: number }) {
    const first = books.find((b) => slots.find((s) => s.id === b.slotId)?.rowId === rowId);
    setFocusClass(first ? deweyClassFor(first.dewey).code : null);
    setZoom(center);
    // let the room travel for a beat before the shelves take over
    window.setTimeout(() => setShelfOpen(true), 520);
  }

  function closeShelf() {
    setShelfOpen(false);
    window.setTimeout(() => setZoom(null), 60);
  }

  function handleControl(id: ControlId) {
    if (id === "theme") {
      router.push("/onboarding/theme");
      return;
    }
    if (id === "profile") {
      router.push("/profile");
      return;
    }
    setOpenPanel((current) => (current === id ? null : id));
  }

  // The chosen method is where each capture flow will mount. Until those
  // exist, choosing one shelves the next queued book so the placement and
  // entrance animation stay exercised.
  function handleAddMethod(_method: AddBookMethod) {
    setOpenPanel(null);
    placeBook();
  }

  return (
    <div data-theme={themeId} className="relative min-h-screen overflow-hidden bg-bg">
      <div
        className="absolute inset-0 transition-transform duration-[900ms] ease-gentle motion-reduce:transition-none"
        style={{
          transform: zoom ? "scale(2.1)" : "scale(1)",
          transformOrigin: zoom ? `${zoom.x}% ${zoom.y}%` : "50% 50%",
        }}
      >
        <RoomScene src={theme.previewImage} aspectRatio={room.aspectRatio} alt={`${theme.name} library`}>
          <BookLayer
            slots={slots}
            books={books}
            decorPlacements={decor}
            recentlyAddedBookId={recentlyAddedId}
            onEmptySlotClick={(slotId) => placeBook(slotId)}
            lighting={room.lighting}
            rows={room.rows}
            onShelfClick={openShelf}
          />
        </RoomScene>
      </div>

      {/* a light wash only where the wordmark sits, so the room stays undimmed */}
      <div className="pointer-events-none absolute inset-x-0 top-0 h-28 bg-gradient-to-b from-black/45 to-transparent" />

      <header className="relative z-20 px-6 pt-6 sm:px-10">
        <Wordmark className="text-xl text-white drop-shadow-[0_2px_8px_rgba(0,0,0,0.7)]" />
      </header>

      {shelfOpen && (
        <ShelfDetail
          books={books}
          paper={theme.paper}
          focusClass={focusClass}
          onUpdateBook={(id, changes) =>
            setBooks((prev) => prev.map((b) => (b.id === id ? { ...b, ...changes } : b)))
          }
          onRemoveBook={(id) => setBooks((prev) => prev.filter((b) => b.id !== id))}
          onClose={closeShelf}
        />
      )}

      <ControlRail
        active={openPanel}
        onSelect={handleControl}
        playlistName="Reading"
      />

      {openPanel && openPanel !== "profile" && openPanel !== "theme" && (
        <div className="fixed inset-x-0 bottom-[7.5rem] z-40 flex justify-center px-4 lg:inset-x-auto lg:bottom-auto lg:right-[8.5rem] lg:top-1/2 lg:-translate-y-1/2 lg:justify-end lg:px-0">
          {openPanel === "add" && (
            <AddBookPanel onClose={() => setOpenPanel(null)} onChoose={handleAddMethod} />
          )}
          {openPanel === "share" && (
            <SharePanel slug="justine" onClose={() => setOpenPanel(null)} />
          )}
          {(openPanel === "playlist" || openPanel === "ambient") && (
            <SoundPanel
              mode={openPanel === "playlist" ? "playlist" : "ambient"}
              playing={soundPlaying}
              onTogglePlay={() => setSoundPlaying((p) => !p)}
              onClose={() => setOpenPanel(null)}
            />
          )}
        </div>
      )}
    </div>
  );
}
