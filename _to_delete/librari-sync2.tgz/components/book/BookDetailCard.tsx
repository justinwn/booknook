"use client";

import { useState } from "react";
import type { Book } from "@/lib/types";
import type { PaperTreatment } from "@/lib/theme/themes";
import { BookNote } from "./BookNote";
import { BookEditForm } from "./BookEditForm";
import { BookShareQR } from "./BookShareQR";
import { formatCallNumber } from "@/lib/library/dewey";

type Mode = "note" | "edit" | "share";

interface BookDetailCardProps {
  book: Book;
  paper?: PaperTreatment;
  onUpdate: (changes: Partial<Book>) => void;
  onRemove: () => void;
  onClose: () => void;
}

/**
 * What a pulled-out book shows: its reading note on the room's paper stock,
 * with the two things you'd actually want to do from there — edit the record
 * (including removing it) or hand someone the book by ISBN.
 */
export function BookDetailCard({ book, paper, onUpdate, onRemove, onClose }: BookDetailCardProps) {
  const [mode, setMode] = useState<Mode>("note");

  return (
    <div className="grain-overlay w-[17rem] rounded-token border border-border bg-surface p-3 shadow-token-lg">
      {mode === "note" && (
        <div className="relative z-10 flex flex-col gap-3">
          <BookNote
            title={book.title}
            rating={book.rating ?? 0}
            note={book.note ?? "No note yet."}
            dateRange={book.finishedAt ? `Finished ${book.finishedAt}` : (book.status ?? "Unread")}
            paper={paper}
            className="w-full rounded-[2px]"
          />

          <div className="flex items-center justify-between gap-2">
            <span className="font-body text-[10px] uppercase tracking-[0.14em] text-ink-soft">
              {formatCallNumber(book.dewey)}
            </span>
            <span className="flex gap-2">
              <button
                type="button"
                onClick={() => setMode("edit")}
                className="rounded-full border border-border px-3.5 py-1.5 font-body text-xs text-ink transition-colors hover:bg-surface-raised"
              >
                Edit
              </button>
              <button
                type="button"
                onClick={() => setMode("share")}
                className="rounded-full bg-accent px-3.5 py-1.5 font-body text-xs font-medium text-bg transition-all hover:brightness-105"
              >
                Share book
              </button>
            </span>
          </div>
        </div>
      )}

      {mode === "edit" && (
        <div className="relative z-10">
          <BookEditForm
            book={book}
            onSave={(changes) => {
              onUpdate(changes);
              setMode("note");
            }}
            onRemove={() => {
              onRemove();
              onClose();
            }}
            onCancel={() => setMode("note")}
          />
        </div>
      )}

      {mode === "share" && (
        <div className="relative z-10">
          <BookShareQR book={book} onBack={() => setMode("note")} />
        </div>
      )}
    </div>
  );
}
