"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { X } from "lucide-react";
import type { Book } from "@/lib/types";
import type { PaperTreatment } from "@/lib/theme/themes";
import { DEWEY_CLASSES, deweyClassFor } from "@/lib/library/dewey";
import { SORT_MODES, sortBooks, type SortMode } from "@/lib/library/sorting";
import { ShelfCompartment } from "./ShelfCompartment";
import { BookDetailCard } from "@/components/book/BookDetailCard";
import { BookCoverPlate } from "@/components/book/BookCoverPlate";

interface ShelfDetailProps {
  books: Book[];
  paper?: PaperTreatment;
  /** the Dewey class to scroll to and briefly mark, from the shelf that was clicked */
  focusClass?: number | null;
  onUpdateBook: (id: string, changes: Partial<Book>) => void;
  onRemoveBook: (id: string) => void;
  onClose: () => void;
}

/**
 * The bookcase, seen close up. Compartments are Dewey classes — that's the
 * shelving system — and the sort control orders books along each shelf
 * without moving them between shelves.
 */
export function ShelfDetail({
  books,
  paper,
  focusClass,
  onUpdateBook,
  onRemoveBook,
  onClose,
}: ShelfDetailProps) {
  const [sort, setSort] = useState<SortMode>("recently-finished");
  const [activeBookId, setActiveBookId] = useState<string | null>(null);
  /** where on screen the active book stands, so the held-out book appears beside it */
  const [anchor, setAnchor] = useState<{ x: number; y: number } | null>(null);
  const focusRef = useRef<HTMLDivElement>(null);

  const shelves = useMemo(() => {
    return DEWEY_CLASSES.map((deweyClass) => ({
      deweyClass,
      books: sortBooks(
        books.filter((b) => deweyClassFor(b.dewey).code === deweyClass.code),
        sort
      ),
    })).filter((shelf) => shelf.books.length > 0);
  }, [books, sort]);

  const activeBook = books.find((b) => b.id === activeBookId) ?? null;

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key !== "Escape") return;
      if (activeBookId) setActiveBookId(null);
      else onClose();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [activeBookId, onClose]);

  useEffect(() => {
    // scroll only as far as needed, so the header and sort control stay in view
    focusRef.current?.scrollIntoView({ behavior: "smooth", block: "nearest" });
  }, [focusClass]);

  return (
    <div className="animate-shelf-in absolute inset-0 z-40 overflow-y-auto bg-bg/80 backdrop-blur-sm">
      <div className="mx-auto min-h-full w-full max-w-5xl px-5 py-8 sm:px-8">
        <header className="mb-8 flex flex-wrap items-center justify-between gap-4">
          <div>
            <h2 className="font-display text-2xl text-ink">Your shelves</h2>
            <p className="mt-0.5 font-body text-xs text-ink-muted">
              Shelved by Dewey Decimal class · {books.length} books
            </p>
          </div>

          <div className="flex items-center gap-3">
            <div className="flex items-center gap-1 rounded-full border border-border bg-surface p-1">
              {SORT_MODES.map((mode) => (
                <button
                  key={mode.id}
                  type="button"
                  onClick={() => setSort(mode.id)}
                  aria-pressed={sort === mode.id}
                  className={`rounded-full px-3 py-1.5 font-body text-xs transition-colors ${
                    sort === mode.id ? "bg-accent text-bg" : "text-ink-muted hover:text-ink"
                  }`}
                >
                  {mode.label}
                </button>
              ))}
            </div>

            <button
              type="button"
              onClick={onClose}
              aria-label="Back to the room"
              className="rounded-full border border-border bg-surface p-2 text-ink-muted transition-colors hover:text-ink"
            >
              <X className="h-4 w-4" strokeWidth={1.75} />
            </button>
          </div>
        </header>

        <div className="grid grid-cols-1 gap-x-5 gap-y-10 lg:grid-cols-2">
          {shelves.map((shelf) => (
            <div
              key={shelf.deweyClass.code}
              ref={shelf.deweyClass.code === focusClass ? focusRef : undefined}
            >
              <ShelfCompartment
                deweyClass={shelf.deweyClass}
                books={shelf.books}
                activeBookId={activeBookId}
                onActivate={(id, rect) => {
                  setActiveBookId(id);
                  setAnchor({ x: rect.left + rect.width / 2, y: rect.top + rect.height / 2 });
                }}
                highlighted={shelf.deweyClass.code === focusClass}
              />
            </div>
          ))}
        </div>
      </div>

      {/* The book, held out in front of the shelf, with its note beside it.
          Rendered here rather than inside the compartment because a
          horizontally scrolling shelf clips anything that overflows it. */}
      {activeBook && anchor && (
        <div className="pointer-events-none fixed inset-0 z-50" onMouseLeave={() => setActiveBookId(null)}>
          <div
            className="pointer-events-auto absolute flex items-start gap-3"
            style={{
              // clamped so the composition never runs off the edge
              left: Math.min(Math.max(anchor.x - 90, 16), window.innerWidth - 470),
              top: Math.min(Math.max(anchor.y - 150, 16), window.innerHeight - 380),
            }}
          >
            <BookCoverPlate
              book={activeBook}
              className="animate-book-settle h-[15rem] w-[10rem] shadow-[0_22px_44px_-14px_rgba(0,0,0,0.8)]"
            />
            <BookDetailCard
              book={activeBook}
              paper={paper}
              onUpdate={(changes) => onUpdateBook(activeBook.id, changes)}
              onRemove={() => onRemoveBook(activeBook.id)}
              onClose={() => setActiveBookId(null)}
            />
          </div>
        </div>
      )}

    </div>
  );
}
