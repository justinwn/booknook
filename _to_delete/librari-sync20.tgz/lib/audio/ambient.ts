export type AmbientTrackId = "fireplace" | "rain" | "ocean" | "birdsong" | "library-hum";

export interface AmbientTrack {
  id: AmbientTrackId;
  label: string;
  /** what it actually sounds like, so the list reads as a room rather than filenames */
  blurb: string;
  src: string;
}

/**
 * The ambient beds. These are layers, not a playlist: rain and a fireplace
 * together is a legitimate room, so every track has its own switch and its own
 * level rather than one being "playing".
 */
export const AMBIENT_TRACKS: AmbientTrack[] = [
  { id: "fireplace", label: "Fireplace", blurb: "Wood burning, close by", src: "/assets/audio/fireplace.mp3" },
  { id: "rain", label: "Rain", blurb: "Monsoon rain on leaves", src: "/assets/audio/rain.mp3" },
  { id: "ocean", label: "Ocean", blurb: "Surf and the odd gull", src: "/assets/audio/ocean.mp3" },
  { id: "birdsong", label: "Birdsong", blurb: "Rainforest at dawn", src: "/assets/audio/birdsong.mp3" },
  { id: "library-hum", label: "Library hum", blurb: "A public room, air moving", src: "/assets/audio/library-hum.mp3" },
];

export interface AmbientTrackSetting {
  on: boolean;
  /** 0 to 1, straight onto the audio element */
  volume: number;
}

export type AmbientSettings = Record<AmbientTrackId, AmbientTrackSetting>;

export const DEFAULT_AMBIENT: AmbientSettings = AMBIENT_TRACKS.reduce((acc, track) => {
  acc[track.id] = { on: false, volume: 0.5 };
  return acc;
}, {} as AmbientSettings);

const KEY = "librari:ambient";

function clamp(value: unknown, fallback: number): number {
  const n = Number(value);
  return Number.isFinite(n) ? Math.min(1, Math.max(0, n)) : fallback;
}

export function loadAmbient(): AmbientSettings {
  if (typeof window === "undefined") return DEFAULT_AMBIENT;
  try {
    const raw = window.localStorage.getItem(KEY);
    if (!raw) return DEFAULT_AMBIENT;
    const parsed = JSON.parse(raw) as Partial<Record<AmbientTrackId, Partial<AmbientTrackSetting>>>;
    // merged per track, so adding a bed later doesn't invalidate saved levels
    return AMBIENT_TRACKS.reduce((acc, track) => {
      const saved = parsed[track.id];
      acc[track.id] = {
        on: Boolean(saved?.on),
        volume: clamp(saved?.volume, DEFAULT_AMBIENT[track.id].volume),
      };
      return acc;
    }, {} as AmbientSettings);
  } catch {
    return DEFAULT_AMBIENT;
  }
}

export function saveAmbient(settings: AmbientSettings): void {
  try {
    window.localStorage.setItem(KEY, JSON.stringify(settings));
  } catch {
    // storage blocked — the mix applies for this session only
  }
}

/** Volume for the nudge chime. Low: it interrupts, so it shouldn't startle. */
export const REMINDER_VOLUME = 0.5;
export const REMINDER_SRC = "/assets/audio/reminder.mp3";
