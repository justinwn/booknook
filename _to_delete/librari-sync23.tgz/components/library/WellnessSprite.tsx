"use client";

import { useEffect, useLayoutEffect, useMemo, useRef, useState } from "react";
import type { ThemeId } from "@/lib/types";
import type { PaperTreatment } from "@/lib/theme/themes";
import {
  dueNudge,
  loadFired,
  loadSnoozed,
  loadWellness,
  markFired,
  NUDGES,
  snoozeNudge,
  type NudgeKind,
} from "@/lib/profile/wellness-store";
import { REMINDER_SRC, REMINDER_VOLUME } from "@/lib/audio/ambient";

/**
 * SPRITES
 *
 * One set per theme. Each clip is a horizontal strip of equal, transparent
 * cells — `frames` says how many, and sheets differ, so it is per clip rather
 * than per set. `actions` decides what the character does for each nudge, so
 * a sheet without a "drink" pose can act it out however suits it.
 *
 * To add a theme: drop the strips into public/assets/sprites and add a set.
 */
interface Clip {
  src: string;
  frames: number;
}

interface SpriteSet {
  /** rendered size of one cell */
  width: number;
  height: number;
  idle: Clip;
  walk: Clip;
  actions: Record<NudgeKind, Clip>;
  /** what this character says — written in its own voice, not a generic string */
  lines: Record<NudgeKind, string>;
}

const minecraft: SpriteSet = {
  width: 64,
  height: 88,
  idle: { src: "/assets/sprites/minecraft-idle.png", frames: 12 },
  walk: { src: "/assets/sprites/minecraft-walk.png", frames: 12 },
  actions: {
    water: { src: "/assets/sprites/minecraft-potion.png", frames: 12 },
    stretch: { src: "/assets/sprites/minecraft-jump.png", frames: 12 },
    break: { src: "/assets/sprites/minecraft-fist.png", frames: 12 },
  },
  lines: {
    water: "Hydration potion! Drink up before your hearts run low.",
    stretch: "*jumps in place* Come on, stretch those legs with me.",
    break: "Put the pickaxe down. Take a break before you hit bedrock.",
  },
};

// the guinea pig sheet has no "drink" row, so eating stands in for it, and
// sitting still reads as taking a break
const cozyRoom: SpriteSet = {
  width: 92,
  height: 87,
  idle: { src: "/assets/sprites/cozy-room-idle.png", frames: 5 },
  walk: { src: "/assets/sprites/cozy-room-walk.png", frames: 4 },
  actions: {
    water: { src: "/assets/sprites/cozy-room-eat.png", frames: 5 },
    stretch: { src: "/assets/sprites/cozy-room-jump.png", frames: 5 },
    break: { src: "/assets/sprites/cozy-room-idle.png", frames: 5 },
  },
  lines: {
    water: "*nom nom nom* ...oh! Your water bowl looks empty too.",
    stretch: "*wheek!* Zoomies time. Up you get, have a stretch.",
    break: "*burrows into the hay* Come rest with me for a minute.",
  },
};

// the mage's rows are unlabelled; these are read off the poses — a spell
// being drawn up close for the drink, a leap, and a cast for the break
const magicalGarden: SpriteSet = {
  width: 92,
  height: 87,
  idle: { src: "/assets/sprites/magical-garden-idle.png", frames: 4 },
  walk: { src: "/assets/sprites/magical-garden-walk.png", frames: 5 },
  actions: {
    water: { src: "/assets/sprites/magical-garden-potion.png", frames: 5 },
    stretch: { src: "/assets/sprites/magical-garden-jump.png", frames: 5 },
    break: { src: "/assets/sprites/magical-garden-fist.png", frames: 4 },
  },
  lines: {
    water: "Your elixir has run dry. Refill it. Water will do.",
    stretch: "Rise and stretch. No spell holds from a slouched stance.",
    break: "Even the studious must rest. Step away from the page.",
  },
};

const SPRITES: Record<ThemeId, SpriteSet> = {
  minecraft,
  "cozy-room": cozyRoom,
  "magical-garden": magicalGarden,
  // no seaside sprite yet — the guinea pig stands in until one arrives
  "seaside-cafe": cozyRoom,
};

/** kept in step with the bubble-out keyframes in globals.css */
const BUBBLE_OUT_MS = 320;

export function WellnessSprite({
  themeId,
  paper,
  onOpenSettings,
  previewNudge = null,
  onPreviewEnd,
}: {
  themeId: ThemeId;
  paper: PaperTreatment;
  onOpenSettings: () => void;
  /** a nudge fired from the settings Test button, shown without arming anything */
  previewNudge?: NudgeKind | null;
  onPreviewEnd?: () => void;
}) {
  const sprite = SPRITES[themeId] ?? minecraft;
  const [nudge, setNudge] = useState<NudgeKind | null>(null);
  /**
   * A previewed nudge takes the stage over a real one. It behaves identically
   * on screen, but Done and Snooze only clear it: a test must not reset a
   * timer or write a snooze, or testing would quietly move the real schedule.
   */
  const active = previewNudge ?? nudge;
  const [travel, setTravel] = useState(0);
  /** true while the bubble plays its exit; the nudge clears when it finishes */
  const [exiting, setExiting] = useState(false);
  const wrapRef = useRef<HTMLDivElement>(null);
  const openedAt = useRef(Date.now());

  /**
   * The stroll spans the whole clock below rather than a fixed distance, so
   * the character never turns around in the middle of nowhere.
   */
  useLayoutEffect(() => {
    const el = wrapRef.current;
    if (!el) return;
    const measure = () => setTravel(Math.max(0, el.offsetWidth - sprite.width));
    measure();
    const observer = new ResizeObserver(measure);
    observer.observe(el);
    return () => observer.disconnect();
  }, [sprite.width]);

  useEffect(() => {
    const check = () =>
      setNudge((current) =>
        current ??
          dueNudge(
            loadWellness(),
            loadFired(),
            openedAt.current,
            Date.now(),
            loadSnoozed()
          )
      );
    check();
    // 30s so a snooze comes back close to its five minutes, not a minute late
    const id = window.setInterval(check, 30_000);
    return () => window.clearInterval(id);
  }, []);

  /**
   * The nudge announces itself. One element, reused, so a nudge arriving
   * while the last chime is still ringing restarts it rather than stacking.
   * A browser that has had no interaction on this page yet will refuse to
   * play at all; the bubble still appears, so the reminder isn't lost.
   */
  const chime = useRef<HTMLAudioElement | null>(null);
  useEffect(() => {
    if (!active) return;
    if (!chime.current) {
      chime.current = new Audio(REMINDER_SRC);
      chime.current.volume = REMINDER_VOLUME;
    }
    chime.current.currentTime = 0;
    void chime.current.play().catch(() => {});
  }, [active]);

  // a new nudge always starts from a clean state, never mid-exit
  useEffect(() => {
    if (active) setExiting(false);
  }, [active]);

  // the character speaks in its own voice; NUDGES holds the plain-text
  // fallback for a sprite set that hasn't been given lines
  const message = useMemo(
    () =>
      active
        ? sprite.lines[active] ?? NUDGES.find((n) => n.kind === active)?.message ?? ""
        : "",
    [active, sprite]
  );

  /**
   * Both answers dismiss the same way: play the bubble out, then commit. The
   * commit is deferred rather than run first so the message is still on screen
   * while it leaves, and a test only ever clears itself.
   */
  function dismiss(commit: () => void) {
    if (exiting) return;
    setExiting(true);
    window.setTimeout(() => {
      setExiting(false);
      commit();
    }, BUBBLE_OUT_MS);
  }

  /** done with it: the full interval restarts from now */
  function done() {
    dismiss(() => {
      if (previewNudge) {
        onPreviewEnd?.();
        return;
      }
      if (nudge) markFired(nudge);
      setNudge(null);
    });
  }

  /** not now: it comes back in five minutes, timer untouched */
  function snooze() {
    dismiss(() => {
      if (previewNudge) {
        onPreviewEnd?.();
        return;
      }
      if (nudge) snoozeNudge(nudge);
      setNudge(null);
    });
  }

  const clip = active ? sprite.actions[active] : sprite.walk;

  return (
    <div
      ref={wrapRef}
      className="pointer-events-none relative w-full select-none"
      style={{ height: sprite.height, ["--stroll-x" as string]: `${travel}px` }}
    >
      {active && (
        <div
          role="status"
          style={{
            // flush left with the clock underneath rather than chasing the
            // character along its stroll, and anchored by its bottom edge so
            // it clears the sprite however tall the message makes it. Sprite
            // cells differ in how much headroom they leave (Steve fills his
            // to the top), so the offset is the full cell height plus a gap
            // rather than a fraction of it — anything less covers the head.
            left: 0,
            bottom: sprite.height + 10,
            background: paper.background,
            color: paper.ink,
            fontFamily: paper.fontBody,
            ["--bubble-out-ms" as string]: `${BUBBLE_OUT_MS}ms`,
          }}
          className={`pointer-events-auto absolute z-10 w-[19rem] rounded-token-lg px-5 py-4 text-left shadow-token-lg ${
            exiting ? "animate-bubble-out" : ""
          }`}
        >
          <span className="block text-[13px] leading-relaxed">{message}</span>
          <div className="mt-3.5 flex items-center gap-2">
            <button
              type="button"
              onClick={done}
              className="rounded-token-sm border border-current px-3 py-1.5 text-[10px] font-semibold uppercase tracking-wide transition-transform hover:-translate-y-px"
            >
              Done
            </button>
            <button
              type="button"
              onClick={snooze}
              className="rounded-token-sm border border-current px-3 py-1.5 text-[10px] uppercase tracking-wide opacity-60 transition hover:opacity-100"
            >
              Snooze 5m
            </button>
          </div>
        </div>
      )}

      <button
        type="button"
        onClick={active ? done : onOpenSettings}
        aria-label={active ? message : "Reminder settings"}
        title={active ? message : "Reminder settings"}
        className="pointer-events-auto absolute bottom-0 left-0"
        style={{
          width: sprite.width,
          height: sprite.height,
          backgroundImage: `url(${clip.src})`,
          // the strip drawn at its true size, so one cell is exactly one frame
          backgroundSize: `${clip.frames * sprite.width}px ${sprite.height}px`,
          ["--sprite-strip" as string]: `${clip.frames * sprite.width}px`,
          imageRendering: "pixelated",
          // both animations always run; pausing the stroll (rather than
          // removing it) keeps the character where it stopped
          animation: `sprite-step ${active ? "1.1s" : "0.9s"} steps(${clip.frames}) infinite, sprite-stroll 26s ease-in-out infinite`,
          animationPlayState: active ? "running, paused" : "running, running",
        }}
      />
    </div>
  );
}
