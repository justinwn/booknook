"use client";

import { Suspense, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { Wallpaper } from "@/components/library/Wallpaper";
import { BookComposition } from "@/components/book/BookComposition";
import { Wordmark } from "@/components/brand/Wordmark";
import { TextField } from "@/components/ui/TextField";
import { Button } from "@/components/ui/Button";
import { GoogleButton } from "@/components/ui/GoogleButton";
import { signInWithEmail, signUpWithEmail, signInWithGoogle, isSupabaseConfigured } from "@/lib/auth/auth";
import { startEmptyLibrary } from "@/lib/profile/library-store";
import { getTheme } from "@/lib/theme/themes";
import { MadeBy } from "@/components/brand/MadeBy";

type Mode = "sign-in" | "sign-up";
type Errors = { email?: string; password?: string; form?: string };

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

function validate(mode: Mode, email: string, password: string): Errors {
  const errors: Errors = {};
  if (!email.trim()) errors.email = "Enter your email address.";
  else if (!EMAIL_RE.test(email)) errors.email = "That doesn't look like an email address.";

  if (!password) errors.password = "Enter your password.";
  else if (mode === "sign-up" && password.length < 8)
    errors.password = "Use at least 8 characters.";

  return errors;
}

function LoginScreen() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const [mode, setMode] = useState<Mode>("sign-in");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [errors, setErrors] = useState<Errors>({});
  const [touched, setTouched] = useState<{ email?: boolean; password?: boolean }>({});
  const [submitting, setSubmitting] = useState(false);
  const [googleLoading, setGoogleLoading] = useState(false);

  const callbackError = searchParams.get("error");

  function revalidate(next: { email?: string; password?: string }) {
    const merged = { email, password, ...next };
    const found = validate(mode, merged.email, merged.password);
    setErrors((prev) => ({
      form: prev.form,
      email: touched.email ? found.email : prev.email,
      password: touched.password ? found.password : prev.password,
    }));
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    const found = validate(mode, email, password);
    setTouched({ email: true, password: true });
    if (found.email || found.password) {
      setErrors(found);
      return;
    }

    setErrors({});
    setSubmitting(true);
    const result =
      mode === "sign-up"
        ? await signUpWithEmail(email, password)
        : await signInWithEmail(email, password);
    setSubmitting(false);

    if (!result.ok) {
      setErrors({ form: result.message });
      return;
    }
    // A new account starts with empty shelves; signing in keeps whatever is
    // already stored for this browser.
    if (mode === "sign-up") startEmptyLibrary();
    router.push("/onboarding/theme");
  }

  async function handleGoogle() {
    setErrors({});
    setGoogleLoading(true);
    if (mode === "sign-up") startEmptyLibrary();
    const result = await signInWithGoogle("/onboarding/theme");
    if (!result.ok) {
      setGoogleLoading(false);
      // Demo mode (no Supabase project attached) still walks the flow.
      if (!isSupabaseConfigured) {
        router.push("/onboarding/theme");
        return;
      }
      setErrors({ form: result.message });
    }
  }

  return (
    <main data-theme="cozy-room" className="relative min-h-screen overflow-hidden">
      {/* the default mood, playing — the landing page is already inside the product */}
      <Wallpaper
        src="/assets/wallpapers/cozy-room.mp4"
        poster="/assets/wallpapers/cozy-room.jpg"
        scrim="heavy"
      />

      {/* the credit sits under the fold otherwise: the grid takes the viewport
          minus the footer's own height rather than all of it */}
      <div className="relative z-10 mx-auto grid min-h-[calc(100vh-3.5rem)] w-full max-w-6xl grid-cols-1 items-center gap-20 px-6 py-16 lg:grid-cols-[1.05fr_1fr] lg:gap-8 lg:px-10">
        {/* LEFT — the book, sitting in the room */}
        <div className="flex justify-center lg:justify-start lg:pl-6">
          {/* the landing page is already inside the cozy room, so the note
              wears that room's stock — the same object the mood picker shows */}
          <BookComposition paper={getTheme("cozy-room").paper} />
        </div>

        {/* RIGHT — the whole sign-in on one card: name, pitch and form
            together, so the page has a single centre of gravity */}
        <div className="w-full max-w-sm justify-self-center lg:justify-self-start">
          <div className="rounded-token-lg bg-white p-7 text-center shadow-[0_24px_60px_-24px_rgba(0,0,0,0.65)] sm:p-8">
            <Wordmark className="text-2xl text-gallery-ink" />

            <p className="mx-auto mt-3 max-w-[19rem] font-body text-[13px] leading-relaxed text-gallery-ink/60">
              Build a library you actually want to sit in. Track what you read, keep your
              reading list and reminders to hand, and let a small companion nudge you to
              drink water, stretch, and take a break.
            </p>

            <form onSubmit={handleSubmit} noValidate className="mt-7 flex flex-col items-center gap-4">
              <TextField
                label="Email"
                tone="on-light"
                align="center"
                type="email"
                name="email"
                autoComplete="email"
                value={email}
                onChange={(e) => {
                  setEmail(e.target.value);
                  revalidate({ email: e.target.value });
                }}
                onBlur={() => {
                  setTouched((t) => ({ ...t, email: true }));
                  setErrors((prev) => ({ ...prev, email: validate(mode, email, password).email }));
                }}
                error={errors.email}
                className="max-w-[16rem]"
              />
              <TextField
                label="Password"
                tone="on-light"
                align="center"
                type="password"
                name="password"
                autoComplete={mode === "sign-up" ? "new-password" : "current-password"}
                value={password}
                onChange={(e) => {
                  setPassword(e.target.value);
                  revalidate({ password: e.target.value });
                }}
                onBlur={() => {
                  setTouched((t) => ({ ...t, password: true }));
                  setErrors((prev) => ({ ...prev, password: validate(mode, email, password).password }));
                }}
                error={errors.password}
                className="max-w-[16rem]"
              />

              {(errors.form || callbackError) && (
                <p role="alert" className="font-body text-sm text-[#b4433a]">
                  {errors.form ?? callbackError}
                </p>
              )}

              <Button type="submit" variant="pill-light" loading={submitting} className="mt-1">
                {mode === "sign-up" ? "Create your library" : "Enter your library"}
              </Button>
            </form>

            <div className="my-5 flex items-center gap-4 text-gallery-ink/40">
              <span className="h-px flex-1 bg-gallery-ink/12" />
              <span className="font-body text-[11px] uppercase tracking-[0.16em]">or</span>
              <span className="h-px flex-1 bg-gallery-ink/12" />
            </div>

            <GoogleButton onClick={handleGoogle} loading={googleLoading}>
              {mode === "sign-up" ? "Sign up with Google" : "Login with Google"}
            </GoogleButton>

            <p className="mt-5 font-body text-sm text-gallery-ink/65">
              {mode === "sign-up" ? "Already have a library?" : "New here?"}{" "}
              <button
                type="button"
                onClick={() => {
                  setMode(mode === "sign-up" ? "sign-in" : "sign-up");
                  setErrors({});
                  setTouched({});
                }}
                className="font-medium text-gallery-ink underline-offset-4 hover:underline"
              >
                {mode === "sign-up" ? "Sign in" : "Create an account"}
              </button>
            </p>

            {/* say who is holding the account, and be honest when nothing is
                holding it yet */}
            <p className="mx-auto mt-2 max-w-[17rem] font-body text-[11px] leading-relaxed text-gallery-ink/45">
              {isSupabaseConfigured
                ? "Accounts are created and secured by Supabase."
                : "Supabase isn't connected yet, so accounts run in demo mode."}
            </p>
          </div>
        </div>
      </div>

      <footer className="relative z-10 pb-6 text-center">
        <MadeBy
          className="text-[11px] text-white/50 drop-shadow-[0_1px_6px_rgba(0,0,0,0.8)]"
          linkClassName="text-white/70"
        />
      </footer>
    </main>
  );
}

export default function LoginPage() {
  return (
    <Suspense fallback={<div className="min-h-screen bg-bg" />}>
      <LoginScreen />
    </Suspense>
  );
}
