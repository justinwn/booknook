import clsx from "clsx";

/**
 * The maker's credit. One component so the wording, the heart and the link
 * stay identical wherever it appears.
 */
export function MadeBy({ className, linkClassName }: { className?: string; linkClassName?: string }) {
  return (
    <p className={clsx("font-body", className)}>
      Made with ♥ by{" "}
      <a
        href="https://justinewin.com/"
        target="_blank"
        rel="noreferrer"
        className={clsx("underline-offset-4 hover:underline", linkClassName)}
      >
        Justine Win
      </a>
    </p>
  );
}
