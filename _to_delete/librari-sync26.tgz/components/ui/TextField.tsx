import { forwardRef, useId, type InputHTMLAttributes } from "react";
import clsx from "clsx";

interface TextFieldProps extends InputHTMLAttributes<HTMLInputElement> {
  label: string;
  error?: string;
  /** renders light-on-dark (over scene photography) instead of dark-on-light */
  tone?: "on-dark" | "on-light";
  /** centred fields sit in a centred card; the default reads as a form row */
  align?: "left" | "center";
}

/**
 * Underline-only field — reads like a line on a library card, not a boxed
 * SaaS input. Label is always visible (no placeholder-as-label), and the
 * error state is wired to aria-invalid + aria-describedby.
 */
export const TextField = forwardRef<HTMLInputElement, TextFieldProps>(
  ({ label, error, tone = "on-dark", align = "left", id, className, ...props }, ref) => {
    const generatedId = useId();
    const fieldId = id ?? generatedId;
    const errorId = `${fieldId}-error`;
    const onDark = tone === "on-dark";

    return (
      <div className={clsx("flex flex-col gap-1.5", align === "center" && "items-center text-center")}>
        <label
          htmlFor={fieldId}
          className={clsx(
            "font-body text-[11px] uppercase tracking-[0.16em]",
            onDark ? "text-white/60" : "text-gallery-ink/60"
          )}
        >
          {label}
        </label>
        <input
          ref={ref}
          id={fieldId}
          aria-invalid={error ? true : undefined}
          aria-describedby={error ? errorId : undefined}
          className={clsx(
            "w-full border-0 border-b bg-transparent px-0 py-2 font-body text-base",
            align === "center" && "text-center",
            "transition-colors duration-token focus:outline-none",
            onDark
              ? "text-white placeholder:text-white/35"
              : "text-gallery-ink placeholder:text-gallery-ink/35",
            error
              ? "border-[#e58b83] focus:border-[#e58b83]"
              : onDark
              ? "border-white/25 focus:border-blush"
              : "border-gallery-ink/20 focus:border-selected",
            className
          )}
          {...props}
        />
        {error && (
          <p id={errorId} role="alert" className="font-body text-xs text-[#e9a49d]">
            {error}
          </p>
        )}
      </div>
    );
  }
);
TextField.displayName = "TextField";
