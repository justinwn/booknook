"use client";

import { Suspense, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { Wallpaper } from "@/components/library/Wallpaper";
import { Wordmark } from "@/components/brand/Wordmark";
import { TextField } from "@/components/ui/TextField";
import { Button } from "@/components/ui/Button";
import { GoogleButton } from "@/components/ui/GoogleButton";
import { signInWithEmail, signUpWithEmail, signInWithGoogle, isSupabaseConfigured } from "@/lib/auth/auth";
import { startEmptyLibrary } from "@/lib/profile/library-store";
import { MadeBy } from "@/components/brand/MadeBy";
import { BookStamp } from "@/components/login/BookStamp";

type Mode = "sign-in" | "sign-up";
type Errors = { email?: string; password?: string; form?: string };

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

function validate(mode: Mode, email: string, password: string): Errors {
  const errors: Errors = {};
  if (!email.trim()) errors.email = "Enter your email address.";
  else if (!EMAIL_RE.test(email)) errors.email = "That doesn't look like an email address.";

  if (!password) errors.password = "Enter your password.";
  else if (mode === "sign-up" && password.length < 8)
    errors.password = "Use at least 8 characters.";

  return errors;
}

function LoginScreen() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const [mode, setMode] = useState<Mode>("sign-in");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [errors, setErrors] = useState<Errors>({});
  const [touched, setTouched] = useState<{ email?: boolean; password?: boolean }>({});
  const [submitting, setSubmitting] = useState(false);
  const [googleLoading, setGoogleLoading] = useState(false);

  const callbackError = searchParams.get("error");

  function revalidate(next: { email?: string; password?: string }) {
    const merged = { email, password, ...next };
    const found = validate(mode, merged.email, merged.password);
    setErrors((prev) => ({
      form: prev.form,
      email: touched.email ? found.email : prev.email,
      password: touched.password ? found.password : prev.password,
    }));
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    const found = validate(mode, email, password);
    setTouched({ email: true, password: true });
    if (found.email || found.password) {
      setErrors(found);
      return;
    }

    setErrors({});
    setSubmitting(true);
    const result =
      mode === "sign-up"
        ? await signUpWithEmail(email, password)
        : await signInWithEmail(email, password);
    setSubmitting(false);

    if (!result.ok) {
      setErrors({ form: result.message });
      return;
    }
    // A new account starts with empty shelves; signing in keeps whatever is
    // already stored for this browser.
    if (mode === "sign-up") startEmptyLibrary();
    router.push("/onboarding/theme");
  }

  async function handleGoogle() {
    setErrors({});
    setGoogleLoading(true);
    if (mode === "sign-up") startEmptyLibrary();
    const result = await signInWithGoogle("/onboarding/theme");
    if (!result.ok) {
      setGoogleLoading(false);
      // Demo mode (no Supabase project attached) still walks the flow.
      if (!isSupabaseConfigured) {
        router.push("/onboarding/theme");
        return;
      }
      setErrors({ form: result.message });
    }
  }

  return (
    <main data-theme="cozy-room" className="relative min-h-screen overflow-hidden">
      {/* the default mood, playing — the landing page is already inside the product */}
      <Wallpaper
        src="/assets/wallpapers/cozy-room.mp4"
        poster="/assets/wallpapers/cozy-room.jpg"
        scrim="heavy"
      />

      {/* THE BOOK
          It arrives closed and tilted, straightens, and its cover swings open
          to the left. Left page holds the form, right page the name and the
          pitch. Below `lg` there is no room for a spread, so the two pages
          stack as one card and nothing rotates. */}
      <div className="relative z-10 mx-auto flex min-h-[calc(100vh-3.5rem)] w-full max-w-5xl items-center justify-center px-5 py-14">
        <div className="w-full" style={{ perspective: "2200px" }}>
          <div
            className="animate-book-straighten mx-auto w-full max-w-[46rem] lg:max-w-[52rem]"
            style={{ transformStyle: "preserve-3d" }}
          >
            <div className="relative flex flex-col overflow-hidden rounded-token-lg shadow-[0_40px_90px_-30px_rgba(0,0,0,0.75)] lg:flex-row">
              {/* LEFT PAGE — the leaf that opens. Its outer face is the front
                  cover, its inner face is the form. */}
              <div
                // z-10 so the folded leaf paints over the right page rather
                // than behind it: the flex row is a flat context, where
                // painting order is DOM order
                className="animate-book-leaf-open relative z-10 w-full bg-white px-7 py-9 sm:px-9 lg:w-1/2"
                // no backface-visibility on the leaf itself: hiding the leaf's
                // own back face would take both of its faces with it
                style={{ transformOrigin: "right center", transformStyle: "preserve-3d" }}
              >
                <div style={{ backfaceVisibility: "hidden" }}>
                <form onSubmit={handleSubmit} noValidate className="animate-book-content-in flex flex-col items-center gap-4">
                  <TextField
                    label="Email"
                    tone="on-light"
                    align="center"
                    type="email"
                    name="email"
                    autoComplete="email"
                    value={email}
                    onChange={(e) => {
                      setEmail(e.target.value);
                      revalidate({ email: e.target.value });
                    }}
                    onBlur={() => {
                      setTouched((t) => ({ ...t, email: true }));
                      setErrors((prev) => ({ ...prev, email: validate(mode, email, password).email }));
                    }}
                    error={errors.email}
                    className="max-w-[16rem]"
                  />
                  <TextField
                    label="Password"
                    tone="on-light"
                    align="center"
                    type="password"
                    name="password"
                    autoComplete={mode === "sign-up" ? "new-password" : "current-password"}
                    value={password}
                    onChange={(e) => {
                      setPassword(e.target.value);
                      revalidate({ password: e.target.value });
                    }}
                    onBlur={() => {
                      setTouched((t) => ({ ...t, password: true }));
                      setErrors((prev) => ({ ...prev, password: validate(mode, email, password).password }));
                    }}
                    error={errors.password}
                    className="max-w-[16rem]"
                  />

                  {(errors.form || callbackError) && (
                    <p role="alert" className="font-body text-sm text-[#b4433a]">
                      {errors.form ?? callbackError}
                    </p>
                  )}

                  <Button type="submit" variant="pill-light" loading={submitting} className="mt-1">
                    {mode === "sign-up" ? "Create your library" : "Enter your library"}
                  </Button>
                </form>

                <div className="animate-book-content-in my-5 flex items-center gap-4 text-gallery-ink/40">
                  <span className="h-px flex-1 bg-gallery-ink/12" />
                  <span className="font-body text-[11px] uppercase tracking-[0.16em]">or</span>
                  <span className="h-px flex-1 bg-gallery-ink/12" />
                </div>

                <div className="animate-book-content-in flex flex-col items-center text-center">
                  <GoogleButton onClick={handleGoogle} loading={googleLoading}>
                    {mode === "sign-up" ? "Sign up with Google" : "Login with Google"}
                  </GoogleButton>

                  <p className="mt-5 font-body text-sm text-gallery-ink/65">
                    {mode === "sign-up" ? "Already have a library?" : "New here?"}{" "}
                    <button
                      type="button"
                      onClick={() => {
                        setMode(mode === "sign-up" ? "sign-in" : "sign-up");
                        setErrors({});
                        setTouched({});
                      }}
                      className="font-medium text-gallery-ink underline-offset-4 hover:underline"
                    >
                      {mode === "sign-up" ? "Sign in" : "Create an account"}
                    </button>
                  </p>

                  {/* say who is holding the account, and be honest when nothing
                      is holding it yet */}
                  <p className="mx-auto mt-2 max-w-[17rem] font-body text-[11px] leading-relaxed text-gallery-ink/45">
                    {isSupabaseConfigured
                      ? "Accounts are created and secured by Supabase."
                      : "Supabase isn't connected yet, so accounts run in demo mode."}
                  </p>
                </div>
                </div>

                {/* the outside of the same leaf: what a closed book shows */}
                <div
                  className="absolute inset-0 hidden flex-col items-center justify-center gap-3 lg:flex"
                  style={{
                    transform: "rotateY(180deg)",
                    backfaceVisibility: "hidden",
                    background: "linear-gradient(150deg, #4a3c63, #2a2340)",
                    boxShadow: "inset -14px 0 26px -18px rgba(0,0,0,0.85)",
                  }}
                  aria-hidden
                >
                  <Wordmark className="text-2xl text-white/90" />
                  <span className="h-px w-16 bg-white/25" />
                  <span className="font-body text-[10px] uppercase tracking-[0.22em] text-white/45">
                    Your library
                  </span>
                </div>
              </div>

              {/* THE GUTTER — where the two pages meet */}
              <div
                className="hidden w-px shrink-0 lg:block"
                style={{
                  background:
                    "linear-gradient(to right, rgba(0,0,0,0.16), rgba(0,0,0,0.05) 45%, rgba(255,255,255,0.6))",
                }}
                aria-hidden
              />

              {/* RIGHT PAGE — the name, the pitch, the stamp */}
              <div
                className="relative flex w-full flex-col items-center justify-center gap-5 px-7 py-10 text-center sm:px-9 lg:w-1/2"
                style={{ background: "linear-gradient(120deg, #fdfaf3, #f3ece0)" }}
              >
                <Wordmark className="text-3xl text-gallery-ink" />

                <p className="max-w-[20rem] font-body text-[13px] leading-relaxed text-gallery-ink/60">
                  Build a library you actually want to sit in. Track what you read, keep your
                  reading list and reminders to hand, and let a small companion nudge you to
                  drink water, stretch, and take a break.
                </p>

                <BookStamp className="mt-1" />
              </div>

            </div>
          </div>
        </div>
      </div>

      <footer className="relative z-10 pb-6 text-center">
        <MadeBy
          className="text-[11px] text-white/50 drop-shadow-[0_1px_6px_rgba(0,0,0,0.8)]"
          linkClassName="text-white/70"
        />
      </footer>
    </main>
  );
}

export default function LoginPage() {
  return (
    <Suspense fallback={<div className="min-h-screen bg-bg" />}>
      <LoginScreen />
    </Suspense>
  );
}
