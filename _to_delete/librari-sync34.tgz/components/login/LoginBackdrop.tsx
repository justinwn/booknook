/**
 * The page the book sits on: note paper, all three rulings at once. A dotted
 * field across the whole sheet, a band of feint lines through the middle, and
 * a grid patch in the corner, each faded with its own mask so they read as
 * one sheet rather than three swatches.
 */
const INK = "rgba(60, 54, 78, 0.20)";
const RULE = "rgba(60, 54, 78, 0.16)";
const INK_SOFT = "rgba(60, 54, 78, 0.14)";

export function LoginBackdrop() {
  return (
    <div className="absolute inset-0 overflow-hidden bg-[#f2eee6]" aria-hidden>
      {/* dotted, everywhere */}
      <div
        className="absolute inset-0"
        style={{
          backgroundImage: `radial-gradient(${INK} 1.1px, transparent 1.1px)`,
          backgroundSize: "22px 22px",
        }}
      />

      {/* ruled, through the middle third */}
      <div
        className="absolute inset-0"
        style={{
          backgroundImage: `repeating-linear-gradient(180deg, ${RULE} 0 1px, transparent 1px 28px)`,
          maskImage: "radial-gradient(140% 58% at 50% 50%, #000 42%, transparent 82%)",
        }}
      />

      {/* squared, top left and bottom right, where a notebook's grid page
          would show through a stack */}
      <div
        className="absolute inset-0"
        style={{
          backgroundImage: `linear-gradient(90deg, ${INK_SOFT} 0 1px, transparent 1px 26px), linear-gradient(180deg, ${INK_SOFT} 0 1px, transparent 1px 26px)`,
          maskImage:
            "radial-gradient(58% 64% at 2% 0%, #000 26%, transparent 76%), radial-gradient(62% 66% at 100% 100%, #000 26%, transparent 76%)",
        }}
      />

      {/* a warm centre and darker edges, so the sheet has some depth to it */}
      <div
        className="absolute inset-0"
        style={{
          background:
            "radial-gradient(70% 60% at 50% 42%, rgba(255,252,244,0.75), transparent 70%), radial-gradient(120% 100% at 50% 100%, rgba(74,64,92,0.16), transparent 60%)",
        }}
      />
    </div>
  );
}
