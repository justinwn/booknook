"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { THEMES, DEFAULT_THEME_ID, getTheme } from "@/lib/theme/themes";
import { useLibraryTheme } from "@/lib/theme/theme-context";
import { loadThemePreference } from "@/lib/profile/theme-preference";
import { ThemeCard } from "@/components/theme/ThemeCard";
import { ThemePreview } from "@/components/theme/ThemePreview";
import { Button } from "@/components/ui/Button";
import type { ThemeId } from "@/lib/types";

export default function ThemeSelectionPage() {
  const router = useRouter();
  const { setThemeId } = useLibraryTheme();
  const [selected, setSelected] = useState<ThemeId>(DEFAULT_THEME_ID);
  const [saving, setSaving] = useState(false);

  // Pre-select whatever the profile already holds, so re-entering this
  // screen from the library shows the current mood rather than resetting.
  useEffect(() => {
    let active = true;
    loadThemePreference().then((themeId) => {
      if (active) setSelected(themeId);
    });
    return () => {
      active = false;
    };
  }, []);

  async function handleDone() {
    setSaving(true);
    await setThemeId(selected); // persists to profile, falls back to localStorage
    router.push("/library");
  }

  return (
    <main className="min-h-screen bg-gallery">
      <div className="mx-auto grid min-h-screen w-full max-w-6xl grid-cols-1 items-center gap-16 px-6 py-16 lg:grid-cols-[1fr_0.85fr] lg:gap-12 lg:px-10">
        {/* LEFT — preview of the selected mood */}
        <div className="flex justify-center lg:justify-start lg:pl-4">
          <ThemePreview theme={getTheme(selected)} />
        </div>

        {/* RIGHT — the moods */}
        <div className="w-full max-w-md justify-self-center lg:justify-self-start">
          <h1 className="font-body text-xs font-semibold uppercase tracking-[0.14em] text-gallery-ink">
            Pick your library mood
          </h1>

          <div role="radiogroup" aria-label="Library mood" className="mt-6 flex flex-col gap-2.5">
            {THEMES.map((theme) => (
              <ThemeCard
                key={theme.id}
                theme={theme}
                selected={theme.id === selected}
                onSelect={() => setSelected(theme.id)}
              />
            ))}
          </div>

          <div className="mt-8 flex justify-end">
            <Button variant="pill-dark" onClick={handleDone} loading={saving}>
              Done
            </Button>
          </div>
        </div>
      </div>
    </main>
  );
}
