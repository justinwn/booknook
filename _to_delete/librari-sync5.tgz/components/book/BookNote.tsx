import clsx from "clsx";
import type { PaperTreatment } from "@/lib/theme/themes";

interface BookNoteProps {
  title: string;
  rating: number;
  outOf?: number;
  note: string;
  dateRange: string;
  /** the note's paper stock — this is what makes a mood feel like an object */
  paper?: PaperTreatment;
  className?: string;
  style?: React.CSSProperties;
}

const DEFAULT_PAPER: PaperTreatment = {
  background: "var(--brand-blush)",
  ink: "var(--brand-blush-ink)",
  pattern: "none",
};

function patternStyle(paper: PaperTreatment): React.CSSProperties {
  const color = paper.patternColor ?? "rgba(0,0,0,0.12)";
  switch (paper.pattern) {
    case "grid":
      return {
        backgroundImage: `linear-gradient(${color} 1px, transparent 1px), linear-gradient(90deg, ${color} 1px, transparent 1px)`,
        backgroundSize: "14px 14px",
      };
    case "lines":
      return {
        backgroundImage: `linear-gradient(${color} 1px, transparent 1px)`,
        backgroundSize: "100% 22px",
      };
    case "dots":
      return {
        backgroundImage: `radial-gradient(${color} 1px, transparent 1px)`,
        backgroundSize: "12px 12px",
      };
    default:
      return {};
  }
}

function Stars({ rating, outOf }: { rating: number; outOf: number }) {
  return (
    <div className="flex gap-0.5" aria-hidden>
      {Array.from({ length: outOf }, (_, i) => (
        // empty stars inherit the note's ink at low opacity, so they read as
        // unfilled on any paper stock rather than as a colour of their own
        <svg
          key={i}
          viewBox="0 0 24 24"
          className={i < rating ? "h-4 w-4" : "h-4 w-4 opacity-20"}
          fill={i < rating ? "#e8a13a" : "currentColor"}
        >
          <path d="M12 2.5l2.9 6.1 6.6.9-4.8 4.6 1.2 6.6L12 17.6 6.1 20.7l1.2-6.6L2.5 9.5l6.6-.9z" />
        </svg>
      ))}
    </div>
  );
}

/**
 * The reading note — one component, used on the login hero and inside the
 * theme preview. Its paper stock is driven entirely by the `paper` prop, so
 * a new mood changes the material without touching this file.
 */
export function BookNote({
  title,
  rating,
  outOf = 5,
  note,
  dateRange,
  paper = DEFAULT_PAPER,
  className,
  style,
}: BookNoteProps) {
  return (
    <article
      className={clsx("grain-overlay flex w-[15.5rem] flex-col gap-3 p-4 shadow-token-lg", className)}
      style={{ background: paper.background, color: paper.ink, ...style }}
    >
      <div className="pointer-events-none absolute inset-0" style={patternStyle(paper)} aria-hidden />

      {(paper.stampLeft || paper.stampRight) && (
        <header className="relative z-10 flex items-baseline justify-between text-[10px] uppercase tracking-[0.14em] opacity-55">
          <span>{paper.stampLeft}</span>
          <span>{paper.stampRight}</span>
        </header>
      )}

      <div className="relative z-10 flex items-baseline justify-between gap-3">
        <h3 className="font-display text-base font-semibold leading-tight">{title}</h3>
        <span className="font-body text-sm tabular-nums opacity-80">
          {rating}/{outOf}
        </span>
      </div>

      <div className="relative z-10">
        <Stars rating={rating} outOf={outOf} />
        <span className="sr-only">
          Rated {rating} out of {outOf}
        </span>
      </div>

      <p className="relative z-10 font-body text-xs leading-relaxed opacity-85">{note}</p>

      <p className="relative z-10 mt-2 font-body text-[11px] opacity-60">{dateRange}</p>
    </article>
  );
}
