"use client";

import { useEffect, useRef, useState } from "react";
import Image from "next/image";
import { QrCode, Loader2, BookOpen } from "lucide-react";
import type { Book, BookStatus } from "@/lib/types";
import type { PaperTreatment } from "@/lib/theme/themes";
import type { BookLookupResult } from "@/lib/books/providers";
import { BookNote } from "@/components/book/BookNote";
import { BookCoverPlate } from "@/components/book/BookCoverPlate";
import { deweyClassFor } from "@/lib/library/dewey";

export type BookDraft = Omit<Book, "id" | "order" | "slotId">;

interface BookEditorScreenProps {
  /** "add" collects a new book; "edit" revises one already on a shelf */
  mode: "add" | "edit";
  /** the book being revised — required in edit mode */
  book?: Book;
  paper?: PaperTreatment;
  onCancel: () => void;
  /** the finished book, plus where its cover sat so it can fly to the shelf */
  onSubmit: (draft: BookDraft, coverRect: DOMRect | null) => void;
  onRemove?: () => void;
}

const STARS = [1, 2, 3, 4, 5];
const STATUSES: BookStatus[] = ["New", "Ongoing", "Done", "Dropped"];

/**
 * ONE editor for both adding and revising a book, so the two can't drift
 * apart on which fields they offer. Mode only changes the verbs (Add book vs
 * Save), whether Remove is present, and whether the fields start empty.
 *
 * Every field is editable in both modes — an ISBN search fills them in, but a
 * book with no barcode, or a bad catalogue record, can still be typed by hand.
 */
export function BookEditorScreen({ mode, book, paper, onCancel, onSubmit, onRemove }: BookEditorScreenProps) {
  const [isbn, setIsbn] = useState(book?.isbn ?? "");
  const [title, setTitle] = useState(book?.title ?? "");
  const [author, setAuthor] = useState(book?.author ?? "");
  const [dewey, setDewey] = useState(book ? String(book.dewey) : "");
  const [owned, setOwned] = useState(book?.owned ?? true);
  const [status, setStatus] = useState<BookStatus>(book?.status ?? "New");
  const [rating, setRating] = useState(book?.rating ?? 0);
  const [note, setNote] = useState(book?.note ?? "");
  const [coverUrl, setCoverUrl] = useState(book?.coverUrl ?? "");
  const [pageCount, setPageCount] = useState<number | null>(null);
  const [publishedYear, setPublishedYear] = useState<number | null>(null);

  const [searching, setSearching] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [confirmRemove, setConfirmRemove] = useState(false);
  const coverRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onCancel();
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onCancel]);

  const deweyNumber = Number(dewey);
  const deweyValid = dewey.trim() !== "" && !Number.isNaN(deweyNumber) && deweyNumber >= 0 && deweyNumber < 1000;
  const canSubmit = title.trim().length > 0 && author.trim().length > 0 && deweyValid;

  async function search() {
    if (!isbn.trim() || searching) return;
    setSearching(true);
    setError(null);
    try {
      const res = await fetch(`/api/books/lookup?isbn=${encodeURIComponent(isbn)}`);
      const data = await res.json();
      if (!res.ok) {
        setError(data.error ?? "Couldn't find that book.");
        return;
      }
      const result = data as BookLookupResult;
      setTitle(result.title);
      setAuthor(result.author);
      setCoverUrl(result.coverUrl ?? "");
      setPageCount(result.pageCount);
      setPublishedYear(result.publishedYear);
      // an unclassified book goes to 800s Literature, the likeliest home in a
      // personal collection — the field stays editable either way
      setDewey(String(result.dewey ?? 800));
    } catch {
      setError("Couldn't reach the book service. Check your connection.");
    } finally {
      setSearching(false);
    }
  }

  function submit() {
    if (!canSubmit) return;
    const finished = owned && status === "Done";
    const thickness = pageCount
      ? Math.min(40, Math.max(12, Math.round(pageCount / 12)))
      : book?.dimensions.thicknessMm ?? 20;

    onSubmit(
      {
        ...(book ?? {}),
        isbn: isbn.trim() || undefined,
        title: title.trim(),
        author: author.trim(),
        coverUrl,
        dewey: deweyNumber,
        dimensions: book?.dimensions ?? { heightMm: 198, widthMm: 129, thicknessMm: thickness },
        rating: rating || undefined,
        note: note.trim() || undefined,
        tags: book?.tags ?? [],
        owned,
        // status only means something for a book you own
        status: owned ? status : undefined,
        finishedAt: finished ? book?.finishedAt ?? new Date().toISOString().slice(0, 10) : undefined,
        addedAt: book?.addedAt ?? new Date().toISOString(),
      },
      coverRef.current?.getBoundingClientRect() ?? null
    );
  }

  const label = "font-body text-[11px] font-semibold uppercase tracking-[0.16em] text-ink-muted";
  const textField =
    "w-full rounded-full border border-border bg-surface-raised/70 px-5 py-2.5 font-body text-sm text-ink placeholder:text-ink-soft focus:border-accent focus:outline-none";
  const pill = (active: boolean) =>
    `rounded-full border px-4 py-2 font-body text-xs transition-colors ${
      active ? "border-accent bg-accent/20 text-ink" : "border-border text-ink-muted hover:text-ink"
    }`;

  return (
    <div className="animate-shelf-in absolute inset-0 z-[60] overflow-y-auto bg-bg/70 backdrop-blur-xl">
      <div className="mx-auto grid min-h-full w-full max-w-5xl grid-cols-1 items-center gap-12 px-6 py-14 lg:grid-cols-[0.9fr_1fr] lg:gap-16 lg:px-10">
        {/* LEFT — the book as it will look on the shelf, filling in as you go */}
        <div className="relative mx-auto w-full max-w-sm lg:mx-0">
          <div
            className="pointer-events-none absolute -inset-16 -z-10"
            style={{
              background:
                "radial-gradient(60% 55% at 45% 40%, rgb(var(--color-accent-soft-rgb) / 0.20), transparent 70%)",
            }}
            aria-hidden
          />
          <div
            ref={coverRef}
            className="relative aspect-[2/3] w-[74%] overflow-hidden rounded-[3px] shadow-[0_34px_64px_-20px_rgba(0,0,0,0.7)]"
            style={{ transform: "rotate(-3deg)" }}
          >
            {coverUrl ? (
              <Image
                key={coverUrl}
                src={coverUrl}
                alt={`Cover of ${title || "this book"}`}
                fill
                sizes="260px"
                className="animate-book-settle object-cover"
                unoptimized
              />
            ) : title ? (
              // typed by hand with no cover art — show the spine treatment instead
              <BookCoverPlate book={{ title, author } as Book} className="h-full w-full" />
            ) : (
              <div className="flex h-full w-full flex-col items-center justify-center gap-3 border border-dashed border-border bg-surface/60">
                <BookOpen className="h-8 w-8 text-ink-soft" strokeWidth={1.25} />
                <p className="px-6 text-center font-body text-[11px] leading-relaxed text-ink-soft">
                  Search an ISBN and the cover appears here
                </p>
              </div>
            )}
          </div>

          <div className="absolute -bottom-10 -right-2 w-[56%] min-w-[13rem]" style={{ transform: "rotate(2deg)" }}>
            {title || rating || note ? (
              <BookNote
                title={title || "Untitled"}
                rating={rating}
                note={note || "Add a note and it shows up here."}
                dateRange={publishedYear ? `Published ${publishedYear}` : owned ? status : "Not owned"}
                paper={paper}
                className="w-full rounded-[2px]"
              />
            ) : (
              <div
                className="grain-overlay w-full rounded-[2px] p-4 shadow-token-lg"
                style={{ background: paper?.background ?? "var(--brand-blush)" }}
              >
                <div className="relative z-10 flex flex-col gap-2.5 opacity-30">
                  <div className="h-3 w-2/3 rounded-full bg-current" />
                  <div className="flex gap-1">
                    {STARS.map((s) => (
                      <div key={s} className="h-3 w-3 rounded-sm bg-current" />
                    ))}
                  </div>
                  <div className="mt-1 h-2 w-full rounded-full bg-current" />
                  <div className="h-2 w-5/6 rounded-full bg-current" />
                  <div className="h-2 w-1/2 rounded-full bg-current" />
                </div>
              </div>
            )}
          </div>
        </div>

        {/* RIGHT — the form. Identical field set in both modes. */}
        <div className="glass-strong w-full rounded-token-lg p-6 sm:p-8">
          <h2 className={label}>{mode === "add" ? "Add new book" : "Edit book"}</h2>

          <div className="mt-6 flex flex-col gap-2">
            <label className={label} htmlFor="book-isbn">ISBN</label>
            <div className="flex items-center gap-2.5">
              <div className="relative flex-1">
                <input
                  id="book-isbn"
                  value={isbn}
                  onChange={(e) => {
                    setIsbn(e.target.value);
                    setError(null);
                  }}
                  onKeyDown={(e) => e.key === "Enter" && (e.preventDefault(), search())}
                  inputMode="numeric"
                  placeholder="978…"
                  aria-invalid={error ? true : undefined}
                  aria-describedby={error ? "book-isbn-error" : undefined}
                  className={`${textField} pr-11`}
                />
                <QrCode
                  className="pointer-events-none absolute right-4 top-1/2 h-4 w-4 -translate-y-1/2 text-ink-soft"
                  strokeWidth={1.5}
                  aria-hidden
                />
              </div>
              <button
                type="button"
                onClick={search}
                disabled={searching || !isbn.trim()}
                className="flex shrink-0 items-center gap-2 rounded-full bg-paper px-5 py-2.5 font-body text-sm font-medium text-[#2b2419] transition-all hover:brightness-105 disabled:opacity-40"
              >
                {searching && <Loader2 className="h-3.5 w-3.5 animate-spin" />}
                {searching ? "Searching" : "Search"}
              </button>
            </div>
            {error && (
              <p id="book-isbn-error" role="alert" className="font-body text-xs text-[#e9a49d]">
                {error}
              </p>
            )}
          </div>

          <div className="mt-6 flex flex-col gap-2">
            <label className={label} htmlFor="book-title">Title</label>
            <input id="book-title" value={title} onChange={(e) => setTitle(e.target.value)} className={textField} required />
          </div>

          <div className="mt-6 flex flex-col gap-2">
            <label className={label} htmlFor="book-author">Author</label>
            <input id="book-author" value={author} onChange={(e) => setAuthor(e.target.value)} className={textField} required />
          </div>

          <div className="mt-6 flex flex-col gap-2">
            <label className={label} htmlFor="book-dewey">Dewey number</label>
            <input
              id="book-dewey"
              value={dewey}
              onChange={(e) => setDewey(e.target.value)}
              inputMode="decimal"
              placeholder="823.91"
              aria-invalid={dewey.trim() !== "" && !deweyValid}
              aria-describedby={dewey.trim() !== "" && !deweyValid ? "book-dewey-error" : "book-dewey-hint"}
              className={`${textField} max-w-[10rem] tabular-nums`}
            />
            {dewey.trim() !== "" && !deweyValid ? (
              <p id="book-dewey-error" role="alert" className="font-body text-[11px] text-[#e9a49d]">
                Use a number between 0 and 999.99.
              </p>
            ) : (
              deweyValid && (
                <p id="book-dewey-hint" className="font-body text-[11px] text-ink-soft">
                  Shelves under {deweyClassFor(deweyNumber).code.toString().padStart(3, "0")}{" "}
                  {deweyClassFor(deweyNumber).label}
                </p>
              )
            )}
          </div>

          <div className="mt-7 flex flex-col gap-2">
            <span className={label}>Do you own it?</span>
            <div className="flex gap-2">
              {[
                { value: true, text: "Owned" },
                { value: false, text: "Not owned" },
              ].map((option) => (
                <button
                  key={option.text}
                  type="button"
                  onClick={() => setOwned(option.value)}
                  aria-pressed={owned === option.value}
                  className={pill(owned === option.value)}
                >
                  {option.text}
                </button>
              ))}
            </div>
          </div>

          {/* status is only meaningful for a book you actually have */}
          {owned && (
            <div className="mt-6 flex flex-col gap-2">
              <span className={label}>Status</span>
              <div className="flex flex-wrap gap-2">
                {STATUSES.map((s) => (
                  <button key={s} type="button" onClick={() => setStatus(s)} aria-pressed={status === s} className={pill(status === s)}>
                    {s}
                  </button>
                ))}
              </div>
            </div>
          )}

          <fieldset className="mt-7 flex flex-col gap-2">
            <legend className={label}>Rating</legend>
            <div className="flex gap-1.5">
              {STARS.map((n) => (
                <button
                  key={n}
                  type="button"
                  onClick={() => setRating(rating === n ? 0 : n)}
                  aria-label={`${n} star${n > 1 ? "s" : ""}`}
                  aria-pressed={rating === n}
                  className={`text-2xl leading-none transition-all duration-150 hover:scale-110 ${
                    n <= rating ? "text-[#e8a13a]" : "text-ink-soft opacity-35 hover:opacity-60"
                  }`}
                >
                  ★
                </button>
              ))}
            </div>
          </fieldset>

          <div className="mt-7 flex flex-col gap-2">
            <label className={label} htmlFor="book-note">Note</label>
            <textarea
              id="book-note"
              value={note}
              onChange={(e) => setNote(e.target.value)}
              rows={5}
              placeholder="What did you think of it?"
              className="w-full resize-y rounded-token-lg border border-border bg-surface-raised/70 p-4 font-body text-sm leading-relaxed text-ink placeholder:text-ink-soft focus:border-accent focus:outline-none"
            />
          </div>

          <div className="mt-8 flex items-center justify-between gap-4">
            {mode === "edit" && onRemove ? (
              confirmRemove ? (
                <span className="flex items-center gap-2">
                  <button type="button" onClick={onRemove} className="rounded-full bg-[#8d3a32] px-4 py-2 font-body text-xs text-white">
                    Remove for good
                  </button>
                  <button type="button" onClick={() => setConfirmRemove(false)} className="font-body text-xs text-ink-muted hover:text-ink">
                    Keep
                  </button>
                </span>
              ) : (
                <button type="button" onClick={() => setConfirmRemove(true)} className="font-body text-sm text-[#c8776e] hover:underline">
                  Remove
                </button>
              )
            ) : (
              <span />
            )}

            <span className="flex items-center gap-4">
              <button type="button" onClick={onCancel} className="font-body text-sm text-ink-muted transition-colors hover:text-ink">
                Cancel
              </button>
              <button
                type="button"
                onClick={submit}
                disabled={!canSubmit}
                className="rounded-full bg-accent px-7 py-3 font-body text-sm font-medium text-bg shadow-token-lg transition-all hover:brightness-110 disabled:cursor-not-allowed disabled:opacity-40"
              >
                {mode === "add" ? "Add book" : "Save"}
              </button>
            </span>
          </div>

          {!canSubmit && (
            <p className="mt-3 text-right font-body text-[11px] text-ink-soft">
              Search an ISBN, or type a title, author and Dewey number by hand.
            </p>
          )}
        </div>
      </div>
    </div>
  );
}
