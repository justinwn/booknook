"use client";

import clsx from "clsx";
import type { Book } from "@/lib/types";
import type { DeweyClass } from "@/lib/library/dewey";
import { formatClassCode } from "@/lib/library/dewey";
import { BookOnShelf } from "@/components/book/BookOnShelf";

interface ShelfCompartmentProps {
  deweyClass: DeweyClass;
  books: Book[];
  activeBookId: string | null;
  onActivate: (id: string, rect: DOMRect) => void;
  highlighted?: boolean;
  arrivingBookId?: string | null;
}

/**
 * One compartment of the bookcase, signed with its Dewey class the way a
 * library signs a run of stacks. Books stand at heights derived from their
 * real dimensions, so a shelf has the uneven skyline a real one does.
 */
export function ShelfCompartment({
  deweyClass,
  books,
  activeBookId,
  onActivate,
  highlighted,
  arrivingBookId,
}: ShelfCompartmentProps) {
  const tallest = Math.max(210, ...books.map((b) => b.dimensions.heightMm));

  return (
    <section
      className={clsx(
        "relative rounded-[2px] border-[10px] border-b-[14px] transition-shadow duration-500",
        "border-[#4a2c17] bg-[#efece6]",
        highlighted && "shadow-[0_0_0_3px_rgba(200,154,59,0.65)]"
      )}
      aria-label={`${formatClassCode(deweyClass.code)} ${deweyClass.label}`}
    >
      {/* the shelf sign, straddling the top rail */}
      <span className="absolute -top-[22px] left-5 z-30 flex items-center gap-1.5 rounded-full bg-[#14120f] px-3 py-1.5 shadow-[0_6px_14px_-6px_rgba(0,0,0,0.8)]">
        <span className="font-body text-[10px] font-semibold tabular-nums tracking-wider text-white/60">
          {formatClassCode(deweyClass.code)}
        </span>
        <span className="font-body text-[11px] font-medium text-white">{deweyClass.label}</span>
      </span>

      <div className="flex h-44 items-end gap-[4px] overflow-x-auto overflow-y-visible px-4 pb-0 pt-8 sm:h-52">
        {/* a class with no books is never rendered as a shelf at all — see the
            filter in ShelfDetail — so there is no empty-shelf state here */}
        {books.map((book) => (
            <BookOnShelf
              key={book.id}
              book={book}
              active={activeBookId === book.id}
              onActivate={(rect) => onActivate(book.id, rect)}
              heightPct={Math.round((book.dimensions.heightMm / tallest) * 88)}
              awaitingArrival={book.id === arrivingBookId}
            />
        ))}
      </div>
    </section>
  );
}
