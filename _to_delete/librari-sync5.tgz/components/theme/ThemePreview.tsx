import Image from "next/image";
import type { ThemeDefinition } from "@/lib/theme/themes";
import { BookNote } from "@/components/book/BookNote";
import { SAMPLE_BOOKS } from "@/lib/mock/sample-books";

/**
 * Left-hand preview: the room, plus a reading note printed on that mood's
 * paper stock. The note is what shows the material treatment changing —
 * the photo alone would only be a color swatch.
 */
export function ThemePreview({ theme }: { theme: ThemeDefinition }) {
  const sample = SAMPLE_BOOKS[0];

  return (
    <div className="relative w-full max-w-xl">
      <div
        key={`${theme.id}-photo`}
        className="animate-book-settle relative aspect-[4/5] w-[72%] overflow-hidden rounded-[10px] shadow-[0_30px_60px_-30px_rgba(40,30,20,0.55)]"
      >
        <Image
          src={theme.previewImage}
          alt={`${theme.name} library preview`}
          fill
          sizes="(max-width: 1024px) 70vw, 420px"
          className="object-cover"
          priority
        />
      </div>

      <BookNote
        key={`${theme.id}-note`}
        title={sample.title}
        rating={sample.rating}
        note={sample.note}
        dateRange={sample.dateRange}
        paper={theme.paper}
        className="animate-book-settle !absolute -bottom-8 right-0 rounded-[2px]"
      />
    </div>
  );
}
