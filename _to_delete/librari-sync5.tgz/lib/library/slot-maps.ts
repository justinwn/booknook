import type { Slot, ThemeId } from "@/lib/types";

/**
 * ROOM SLOT MAPS
 *
 * Each theme's room photograph gets a map describing where its real shelf
 * surfaces are. Coordinates are percentages of the PHOTO's own box (not the
 * viewport), so books stay glued to the right ledges at any window size —
 * `RoomScene` reproduces object-cover geometry on a real element so those
 * percentages resolve against the image, not the screen.
 *
 * This is the whole point of the separation: swap the photo, retune one map,
 * and every book/decor position follows. No component reads pixels off an image.
 */

export interface ShelfRow {
  id: string;
  /** the surface books stand on, % of room height */
  ledgeY: number;
  /** horizontal extent of usable shelf, % of room width */
  xStart: number;
  xEnd: number;
  /** how tall a book on this row is, % of room height */
  bookHeight: number;
  /** number of book slots along the row */
  slots: number;
  /** depth cue — rows further back render slightly smaller */
  scale?: number;
}

export interface DecorSlotDef {
  id: string;
  x: number;
  y: number;
  width: number;
  height: number;
}

export interface RoomSlotMap {
  /** intrinsic aspect (width / height) of the room photograph */
  aspectRatio: number;
  /**
   * How the room lights the things standing in it. Rendered spines are flat
   * artwork; without this a dim room gets books that look pasted on. Applied
   * as a filter over the whole placement layer.
   */
  lighting?: { brightness: number; saturate: number };
  rows: ShelfRow[];
  decor: DecorSlotDef[];
}

// Cabin — the primary reference room. Tuned against the source photo.
const CABIN: RoomSlotMap = {
  aspectRatio: 736 / 977,
  lighting: { brightness: 0.95, saturate: 0.95 },
  rows: [
    { id: "cabin-r1", ledgeY: 42.9, xStart: 15, xEnd: 70, bookHeight: 6, slots: 11, scale: 0.95 },
    { id: "cabin-r2", ledgeY: 49.7, xStart: 15, xEnd: 70, bookHeight: 6, slots: 11, scale: 0.97 },
    { id: "cabin-r3", ledgeY: 56.8, xStart: 15, xEnd: 68, bookHeight: 6.2, slots: 10, scale: 1 },
  ],
  decor: [
    { id: "cabin-d1", x: 62, y: 30, width: 9, height: 9.5 },
    { id: "cabin-d2", x: 15, y: 40, width: 8, height: 9 },
  ],
};

// Japanese — the default mood, also tuned against its source photo.
const JAPANESE: RoomSlotMap = {
  aspectRatio: 736 / 1104,
  lighting: { brightness: 0.82, saturate: 0.9 },
  rows: [
    // this bookcase has a central post, so each level is two segments —
    // rows are data, so a divider is just two entries instead of one
    { id: "jp-r1a", ledgeY: 46.9, xStart: 13, xEnd: 45, bookHeight: 5.2, slots: 6, scale: 0.95 },
    { id: "jp-r1b", ledgeY: 46.9, xStart: 51, xEnd: 82, bookHeight: 5.2, slots: 6, scale: 0.95 },
    { id: "jp-r2a", ledgeY: 53.4, xStart: 13, xEnd: 45, bookHeight: 5.2, slots: 6, scale: 0.97 },
    { id: "jp-r2b", ledgeY: 53.4, xStart: 51, xEnd: 82, bookHeight: 5.2, slots: 6, scale: 0.97 },
    { id: "jp-r3a", ledgeY: 60.1, xStart: 13, xEnd: 45, bookHeight: 5.4, slots: 6, scale: 0.99 },
    { id: "jp-r3b", ledgeY: 60.1, xStart: 51, xEnd: 82, bookHeight: 5.4, slots: 6, scale: 0.99 },
    { id: "jp-r4a", ledgeY: 66.3, xStart: 13, xEnd: 45, bookHeight: 5.4, slots: 6, scale: 1 },
    { id: "jp-r4b", ledgeY: 66.3, xStart: 51, xEnd: 82, bookHeight: 5.4, slots: 6, scale: 1 },
  ],
  decor: [
    { id: "jp-d1", x: 73, y: 39, width: 8, height: 8.5 },
    { id: "jp-d2", x: 14, y: 49, width: 7.5, height: 8 },
  ],
};

/**
 * TEMPORARY: the remaining rooms use an approximate map derived from where
 * shelving typically sits in their photo. Retune these the same way Cabin and
 * Japanese were (overlay a percentage grid on the photo, read off the ledges)
 * once their final artwork is locked.
 */
function approximateMap(
  id: string,
  aspectRatio: number,
  lighting: { brightness: number; saturate: number } = { brightness: 1, saturate: 1 }
): RoomSlotMap {
  return {
    aspectRatio,
    lighting,
    rows: [
      { id: `${id}-r1`, ledgeY: 45, xStart: 16, xEnd: 78, bookHeight: 6, slots: 10, scale: 0.95 },
      { id: `${id}-r2`, ledgeY: 53.4, xStart: 16, xEnd: 78, bookHeight: 6, slots: 10, scale: 0.98 },
      { id: `${id}-r3`, ledgeY: 61, xStart: 16, xEnd: 78, bookHeight: 6.2, slots: 9, scale: 1 },
    ],
    decor: [{ id: `${id}-d1`, x: 70, y: 35, width: 8, height: 8.5 }],
  };
}

export const ROOM_SLOT_MAPS: Record<ThemeId, RoomSlotMap> = {
  cabin: CABIN,
  japanese: JAPANESE,
  retro: approximateMap("retro", 832 / 1248, { brightness: 0.88, saturate: 0.95 }),
  "dark-academia": approximateMap("da", 736 / 919, { brightness: 0.75, saturate: 0.9 }),
  cozy: approximateMap("cozy", 736 / 1104),
  "plant-lover": approximateMap("plant", 1080 / 1349),
};

/** Expands a room map into concrete, addressable slots. */
export function buildSlots(map: RoomSlotMap): Slot[] {
  const bookSlots: Slot[] = map.rows.flatMap((row) => {
    const span = (row.xEnd - row.xStart) / row.slots;
    return Array.from({ length: row.slots }, (_, i) => ({
      id: `${row.id}-s${i}`,
      rowId: row.id,
      x: row.xStart + i * span,
      y: row.ledgeY - row.bookHeight,
      width: span,
      height: row.bookHeight,
      kind: "book" as const,
      scale: row.scale ?? 1,
    }));
  });

  const decorSlots: Slot[] = map.decor.map((d) => ({
    id: d.id,
    rowId: "decor",
    x: d.x,
    y: d.y,
    width: d.width,
    height: d.height,
    kind: "decor" as const,
    scale: 1,
  }));

  return [...bookSlots, ...decorSlots];
}

export function getRoomSlots(themeId: ThemeId): Slot[] {
  return buildSlots(ROOM_SLOT_MAPS[themeId]);
}
