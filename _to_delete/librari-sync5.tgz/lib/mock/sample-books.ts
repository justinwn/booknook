/**
 * Sample book + note pairs the login hero shuffles through. Placeholder
 * covers are original SVG stand-ins; swap `coverUrl` for real artwork when
 * cover fetching (Google Books / Open Library) is wired up.
 */
export interface SampleBook {
  id: string;
  title: string;
  coverUrl: string;
  coverAlt: string;
  rating: number; // out of 5
  note: string;
  dateRange: string;
  /** rotation applied to the cover, so each shuffle sits slightly differently */
  tilt: number;
}

export const SAMPLE_BOOKS: SampleBook[] = [
  {
    id: "odyssey",
    title: "The Odyssey",
    coverUrl: "/assets/book-placeholder.webp",
    coverAlt: "Book cover with a small ship on stylised blue waves",
    rating: 4,
    note: "Enjoyed reading this a lot, reminds me of my childhood memories. Chapter 7 was particularly exhilarating!",
    dateRange: "July – June 2025",
    tilt: -4,
  },
  {
    id: "quiet-orchard",
    title: "The Quiet Orchard",
    coverUrl: "/assets/covers/placeholder-green.svg",
    coverAlt: "Placeholder cover with concentric circles over rolling lines",
    rating: 5,
    note: "Read most of it in one sitting on a rainy Sunday. The last forty pages completely undid me.",
    dateRange: "March – April 2025",
    tilt: -2,
  },
  {
    id: "salt-and-compass",
    title: "Salt & Compass",
    coverUrl: "/assets/covers/placeholder-amber.svg",
    coverAlt: "Placeholder cover with a framed compass motif",
    rating: 3,
    note: "Beautiful writing, slightly lost the thread in the middle. Still thinking about the ending though.",
    dateRange: "January – February 2025",
    tilt: -6,
  },
];
