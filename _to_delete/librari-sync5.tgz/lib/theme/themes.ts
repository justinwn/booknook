import type { ThemeId } from "@/lib/types";

/**
 * How a theme's paper/note material is rendered. This is the "material
 * treatment" axis of a theme — deliberately separate from color tokens,
 * because it's what makes a mood feel like an object rather than a palette.
 */
export interface PaperTreatment {
  /** small header text printed on the note stock, e.g. a stationery brand line */
  stampLeft?: string;
  stampRight?: string;
  /** background + ink of the note itself (independent of the app chrome) */
  background: string;
  ink: string;
  /** optional ruling/grid printed on the stock */
  pattern: "none" | "grid" | "lines" | "dots";
  patternColor?: string;
}

export interface ThemeDefinition {
  id: ThemeId;
  name: string;
  /** short + evocative — the mood in one line */
  tagline: string;
  /** longer copy shown inside the expanded/selected card */
  description: string;
  previewImage: string;
  /** true for bright/daylight moods rather than moody/lamplit ones */
  isLight: boolean;
  paper: PaperTreatment;
}

// Theme list and order follow the theme-selection design. Six moods:
// Japanese, Retro, Dark academia, Cozy, Plant lover, Cabin.
export const THEMES: ThemeDefinition[] = [
  {
    id: "japanese",
    name: "Japanese",
    tagline: "Quiet, low light, tatami calm",
    description:
      "Shoji paper, warm wood, and a low table. A room that asks you to sit on the floor and stay a while.",
    previewImage: "/assets/moods/japanese.jpg",
    isLight: false,
    paper: {
      stampLeft: "Japanese Writing Paper",
      stampRight: "Genkō Yōshi",
      background: "#e4e8dd",
      ink: "#2b2f26",
      pattern: "grid",
      patternColor: "rgba(90, 110, 80, 0.28)",
    },
  },
  {
    id: "retro",
    name: "Retro",
    tagline: "Warm print, faded ink, old paperbacks",
    description:
      "Sun-bleached spines and second-hand shop finds. Everything a little worn in the best way.",
    // TEMPORARY: no Retro reference photo exists in the assets folder yet —
    // borrowing the Classic library shot until real artwork lands.
    previewImage: "/assets/moods/retro.jpg",
    isLight: false,
    paper: {
      stampLeft: "Reading Log",
      stampRight: "No. 07",
      background: "#f0e2c8",
      ink: "#3b2a1c",
      pattern: "lines",
      patternColor: "rgba(150, 110, 70, 0.25)",
    },
  },
  {
    id: "dark-academia",
    name: "Dark academia",
    tagline: "Leather, brass lamplight, old paper",
    description:
      "Floor-to-ceiling shelves, one warm lamp, and the particular quiet of reading late.",
    previewImage: "/assets/moods/dark-academia.jpg",
    isLight: false,
    paper: {
      stampLeft: "Marginalia",
      stampRight: "MMXXVI",
      background: "#e8dcc2",
      ink: "#33261a",
      pattern: "lines",
      patternColor: "rgba(120, 90, 55, 0.22)",
    },
  },
  {
    id: "cozy",
    name: "Cozy",
    tagline: "Cream, sage, and soft linen",
    description:
      "A bright attic nook — window seat, wool throws, and books tucked into painted shelves.",
    previewImage: "/assets/moods/barn.jpg",
    isLight: true,
    paper: {
      stampLeft: "Notes",
      background: "#fbf7ee",
      ink: "#3a3628",
      pattern: "dots",
      patternColor: "rgba(120, 130, 100, 0.2)",
    },
  },
  {
    id: "plant-lover",
    name: "Plant lover",
    tagline: "Sunlit, eclectic, growing wild",
    description:
      "Mid-century curves, a colorful rug, and shelves spilling over with things that need watering.",
    previewImage: "/assets/moods/plant-lover.jpg",
    isLight: true,
    paper: {
      stampLeft: "Field Notes",
      background: "#fdf3e3",
      ink: "#2f2a1a",
      pattern: "grid",
      patternColor: "rgba(160, 120, 70, 0.2)",
    },
  },
  {
    id: "cabin",
    name: "Cabin",
    tagline: "Hand-hewn pine, morning light",
    description:
      "Rustic wood wrapping the whole room, a window with a view, and nothing fussy in sight.",
    previewImage: "/assets/moods/cabin.jpg",
    isLight: false,
    paper: {
      stampLeft: "Logbook",
      background: "#ece0c9",
      ink: "#33291b",
      pattern: "grid",
      patternColor: "rgba(120, 95, 60, 0.2)",
    },
  },
];

export const DEFAULT_THEME_ID: ThemeId = "japanese";

export function getTheme(id: ThemeId): ThemeDefinition {
  return THEMES.find((t) => t.id === id) ?? THEMES[0];
}
