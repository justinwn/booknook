import type { ThemeDefinition } from "@/lib/theme/themes";
import Image from "next/image";
import { BookNote } from "@/components/book/BookNote";
import { SAMPLE_BOOKS } from "@/lib/mock/sample-books";

/**
 * What a book looks like in this mood: a sample cover with its reading note
 * tucked against it. The wallpaper is already behind the whole page, so the
 * preview shows the thing that actually changes between themes — the note's
 * paper stock and its typography.
 */
export function ThemePreview({ theme }: { theme: ThemeDefinition }) {
  const sample = SAMPLE_BOOKS[0];

  return (
    <div className="relative w-full max-w-sm">
      <div
        className="pointer-events-none absolute -inset-20 -z-10"
        style={{
          background:
            "radial-gradient(58% 52% at 46% 42%, rgb(var(--color-accent-soft-rgb) / 0.22), transparent 72%)",
        }}
        aria-hidden
      />

      <div
        key={`${theme.id}-cover`}
        className="animate-book-settle relative aspect-[2/3] w-[68%] overflow-hidden rounded-[3px] shadow-[0_34px_66px_-20px_rgba(0,0,0,0.75)]"
        style={{ transform: "rotate(-3deg)" }}
      >
        <Image src={sample.coverUrl} alt={sample.coverAlt} fill sizes="260px" className="object-cover" priority />
      </div>

      <BookNote
        key={`${theme.id}-note`}
        title={sample.title}
        rating={sample.rating}
        note={sample.note}
        dateRange={sample.dateRange}
        paper={theme.paper}
        className="animate-book-settle !absolute -bottom-10 -right-2 w-[58%] min-w-[13rem] rounded-[2px]"
      />
    </div>
  );
}
