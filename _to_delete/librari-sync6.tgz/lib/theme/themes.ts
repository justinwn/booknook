import type { ThemeId } from "@/lib/types";

/**
 * How a theme's paper/note material is rendered. This is the "material
 * treatment" axis of a theme — deliberately separate from color tokens,
 * because it's what makes a mood feel like an object rather than a palette.
 */
export interface PaperTreatment {
  /** small header text printed on the note stock, e.g. a stationery brand line */
  stampLeft?: string;
  stampRight?: string;
  /** background + ink of the note itself (independent of the app chrome) */
  background: string;
  ink: string;
  /** optional ruling/grid printed on the stock */
  pattern: "none" | "grid" | "lines" | "dots";
  patternColor?: string;
  /**
   * Typography for the note, per theme. Font families are loaded once in
   * app/layout.tsx and referenced here only by CSS custom property, so a
   * pairing change never touches a component.
   */
  fontDisplay: string;
  fontBody: string;
  /** pixel fonts need looser leading and no italic to stay legible */
  displayTracking?: string;
}

export interface ThemeDefinition {
  id: ThemeId;
  /** matches the wallpaper file it was cut from */
  name: string;
  /** short + evocative — the mood in one line */
  tagline: string;
  /** longer copy shown inside the expanded/selected card */
  description: string;
  /** looping 4K-sourced wallpaper, transcoded for the web */
  wallpaper: string;
  /** first frame — paints instantly, and stands in when motion is reduced */
  poster: string;
  /** true for bright/daylight moods rather than moody/nocturnal ones */
  isLight: boolean;
  paper: PaperTreatment;
}

export const THEMES: ThemeDefinition[] = [
  {
    id: "cozy-room",
    name: "Cozy room",
    tagline: "Blue hour, one warm lamp",
    description:
      "An apartment after dark — city light through the window, a lamp left on, and nowhere to be.",
    wallpaper: "/assets/wallpapers/cozy-room.mp4",
    poster: "/assets/wallpapers/cozy-room.jpg",
    isLight: false,
    paper: {
      stampLeft: "Night Notes",
      background: "#f2ece0",
      ink: "#2c2a33",
      pattern: "lines",
      patternColor: "rgba(90, 90, 130, 0.18)",
      fontDisplay: "var(--font-fraunces)",
      fontBody: "var(--font-work-sans)",
    },
  },
  {
    id: "magical-garden",
    name: "Magical garden",
    tagline: "A bookshop that only opens at night",
    description:
      "Flowers spilling onto the pavement, warm shelves glowing behind the glass, stars above the roofline.",
    wallpaper: "/assets/wallpapers/magical-garden.mp4",
    poster: "/assets/wallpapers/magical-garden.jpg",
    isLight: false,
    paper: {
      stampLeft: "Nocturne",
      stampRight: "No. 12",
      background: "#f6efe2",
      ink: "#2f2438",
      pattern: "none",
      fontDisplay: "var(--font-playfair)",
      fontBody: "var(--font-dm-sans)",
    },
  },
  {
    id: "seaside-cafe",
    name: "Seaside cafe",
    tagline: "Salt air and a second coffee",
    description:
      "A terrace over the water, potted geraniums, and the kind of afternoon that doesn't need a plan.",
    wallpaper: "/assets/wallpapers/seaside-cafe.mp4",
    poster: "/assets/wallpapers/seaside-cafe.jpg",
    isLight: true,
    paper: {
      stampLeft: "Café Notes",
      background: "#fdfbf4",
      ink: "#1f3a3d",
      pattern: "dots",
      patternColor: "rgba(40, 110, 110, 0.18)",
      fontDisplay: "var(--font-dm-serif)",
      fontBody: "var(--font-nunito)",
    },
  },
  {
    id: "minecraft",
    name: "Minecraft",
    tagline: "Built one block at a time",
    description:
      "A hand-dug library in the hillside — spruce planks, lantern light, and vines through the window.",
    wallpaper: "/assets/wallpapers/minecraft.mp4",
    poster: "/assets/wallpapers/minecraft.jpg",
    isLight: false,
    paper: {
      stampLeft: "INVENTORY",
      background: "#e8e4d8",
      ink: "#2a2320",
      pattern: "grid",
      patternColor: "rgba(70, 60, 45, 0.22)",
      fontDisplay: "var(--font-press-start)",
      fontBody: "var(--font-vt323)",
      displayTracking: "0.02em",
    },
  },
];

export const DEFAULT_THEME_ID: ThemeId = "cozy-room";

export function getTheme(id: ThemeId): ThemeDefinition {
  return THEMES.find((t) => t.id === id) ?? THEMES[0];
}
