"use client";

import { useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import { useLibraryTheme } from "@/lib/theme/theme-context";
import { ROOM_SLOT_MAPS, getRoomSlots } from "@/lib/library/slot-maps";
import { placeInitialBooks } from "@/lib/mock/library";
import { loadBooks, saveBooks, hasStoredLibrary } from "@/lib/profile/library-store";
import type { Book } from "@/lib/types";
import { Wallpaper } from "@/components/library/Wallpaper";
import { ShelfHotspots } from "@/components/library/ShelfHotspots";
import { ControlRail, type ControlId } from "@/components/library/ControlRail";
import { BookEditorScreen, type BookDraft } from "@/components/library/BookEditorScreen";
import { FlyingBook } from "@/components/book/FlyingBook";
import { SharePanel } from "@/components/library/SharePanel";
import { SoundPanel } from "@/components/library/SoundPanel";
import { Wordmark } from "@/components/brand/Wordmark";
import { ShelfDetail } from "@/components/library/ShelfDetail";
import { deweyClassFor } from "@/lib/library/dewey";

export default function LibraryPage() {
  const router = useRouter();
  const { themeId, theme } = useLibraryTheme();

  const slots = useMemo(() => getRoomSlots(themeId), [themeId]);
  const room = ROOM_SLOT_MAPS[themeId];

  /**
   * An account that was just created has an empty library and stays empty
   * until a book is added. A browser that has never had one at all falls back
   * to the sample catalogue, so the app isn't blank on a cold open.
   */
  const [books, setBooks] = useState<Book[]>([]);
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    const stored = loadBooks();
    setBooks(stored ?? (hasStoredLibrary() ? [] : placeInitialBooks(slots)));
    setLoaded(true);
    // slots are stable for a given theme; seeding runs once on mount
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (loaded) saveBooks(books);
  }, [books, loaded]);

  /**
   * The collection belongs to the reader; slot assignment belongs to the
   * room. Rooms have different shelf geometry, so when the mood changes the
   * books are re-seated in `order` sequence onto the new room's slots rather
   * than keeping ids that don't exist there.
   */
  useEffect(() => {
    const bookSlots = slots.filter((s) => s.kind === "book");
    setBooks((prev) =>
      [...prev]
        .sort((a, b) => a.order - b.order)
        .map((book, i) => (bookSlots[i] ? { ...book, slotId: bookSlots[i].id } : book))
        .filter((book, i) => Boolean(bookSlots[i]))
    );
  }, [slots]);

  const [recentlyAddedId, setRecentlyAddedId] = useState<string | null>(null);
  const [openPanel, setOpenPanel] = useState<ControlId | null>(null);
  const [soundPlaying, setSoundPlaying] = useState(false);

  /**
   * Room → shelf transition. `zoom` holds the origin point (in room
   * percentage coordinates) so the room scales *toward the shelf that was
   * clicked* rather than the centre of the screen — that's what makes it
   * read as moving closer to a specific shelf instead of a generic zoom.
   */
  const [zoom, setZoom] = useState<{ x: number; y: number } | null>(null);
  const [shelfOpen, setShelfOpen] = useState(false);
  const [focusClass, setFocusClass] = useState<number | null>(null);
  /** a freshly added book, mid-flight to its place on the shelf */
  const [flight, setFlight] = useState<{ book: Book; from: DOMRect } | null>(null);
  /** the book currently open in the editor; null means the editor is closed */
  const [editingBook, setEditingBook] = useState<Book | null>(null);

  function openShelf(rowId: string, center: { x: number; y: number }) {
    const first = books.find((b) => slots.find((s) => s.id === b.slotId)?.rowId === rowId);
    setFocusClass(first ? deweyClassFor(first.dewey).code : null);
    setZoom(center);
    // let the room travel for a beat before the shelves take over
    window.setTimeout(() => setShelfOpen(true), 520);
  }

  function closeShelf() {
    setShelfOpen(false);
    window.setTimeout(() => setZoom(null), 60);
  }

  function handleControl(id: ControlId) {
    if (id === "theme") {
      router.push("/onboarding/theme");
      return;
    }
    if (id === "profile") {
      router.push("/profile");
      return;
    }
    setOpenPanel((current) => (current === id ? null : id));
  }

  function handleSaveEdit(draft: BookDraft) {
    if (!editingBook) return;
    setBooks((prev) => prev.map((b) => (b.id === editingBook.id ? { ...b, ...draft } : b)));
    setEditingBook(null);
  }

  function handleRemoveBook(id: string) {
    setBooks((prev) => prev.filter((b) => b.id !== id));
    setEditingBook(null);
  }

  function handleAddBook(draft: BookDraft, coverRect: DOMRect | null) {
    const occupied = new Set(books.map((b) => b.slotId));
    const slot = slots.find((s) => s.kind === "book" && !occupied.has(s.id));
    const book: Book = { ...draft, id: `added-${Date.now()}`, order: books.length, slotId: slot?.id ?? "" };

    setBooks((prev) => [...prev, book]);
    setOpenPanel(null);

    // open the shelves at the class this book belongs to, so the flight has
    // somewhere real to land
    setFocusClass(deweyClassFor(book.dewey).code);
    if (!shelfOpen) {
      setZoom({ x: 50, y: 45 });
      setShelfOpen(true);
    }

    if (coverRect) setFlight({ book, from: coverRect });
  }

  return (
    <div data-theme={themeId} className="relative min-h-screen overflow-hidden bg-bg">
      <div
        className="absolute inset-0 transition-transform duration-[900ms] ease-gentle motion-reduce:transition-none"
        style={{
          transform: zoom ? "scale(2.1)" : "scale(1)",
          transformOrigin: zoom ? `${zoom.x}% ${zoom.y}%` : "50% 50%",
        }}
      >
        <Wallpaper src={theme.wallpaper} poster={theme.poster} scrim={theme.isLight ? "light" : "none"} />

        {/*
          The room shows the scene, not the collection: books live on the
          shelves you open, and painting spines over a moving wallpaper only
          fought the artwork. Every bookshelf in the scene is a way in.
        */}
        <ShelfHotspots hotspots={theme.shelfHotspots} onOpen={openShelf} />
      </div>

      {/* a light wash only where the wordmark sits, so the room stays undimmed */}
      <div className="pointer-events-none absolute inset-x-0 top-0 h-28 bg-gradient-to-b from-black/45 to-transparent" />

      <header className="relative z-20 px-6 pt-6 sm:px-10">
        <div className="flex items-baseline gap-2.5 drop-shadow-[0_2px_10px_rgba(0,0,0,0.75)]">
          <Wordmark className="text-xl text-white" />
          <span className="font-body text-[10px] uppercase tracking-[0.22em] text-white/55">
            {theme.name}
          </span>
        </div>
      </header>

      {shelfOpen && (
        <ShelfDetail
          books={books}
          paper={theme.paper}
          shelving={theme.shelving}
          focusClass={focusClass}
          onEditBook={(book) => setEditingBook(book)}
          onClose={closeShelf}
          onAddBook={() => {
            setShelfOpen(false);
            setOpenPanel("add");
          }}
          arrivingBookId={flight?.book.id ?? null}
        />
      )}

      {flight && (
        <FlyingBook
          book={flight.book}
          from={flight.from}
          resolveTarget={() =>
            document.querySelector(`[data-book-id="${flight.book.id}"]`)?.getBoundingClientRect() ?? null
          }
          onLanded={() => setFlight(null)}
        />
      )}

      <ControlRail
        active={openPanel}
        onSelect={handleControl}
        playlistName="Reading"
      />

      {/* one editor, two modes — add and edit can't drift apart on fields */}
      {openPanel === "add" && (
        <BookEditorScreen
          mode="add"
          paper={theme.paper}
          onCancel={() => setOpenPanel(null)}
          onSubmit={handleAddBook}
        />
      )}

      {editingBook && (
        <BookEditorScreen
          mode="edit"
          book={editingBook}
          paper={theme.paper}
          onCancel={() => setEditingBook(null)}
          onSubmit={handleSaveEdit}
          onRemove={() => handleRemoveBook(editingBook.id)}
        />
      )}

      {openPanel && openPanel !== "profile" && openPanel !== "theme" && openPanel !== "add" && (
        <div className="fixed inset-x-0 bottom-[7.5rem] z-40 flex justify-center px-4 lg:inset-x-auto lg:bottom-auto lg:right-[8.5rem] lg:top-1/2 lg:-translate-y-1/2 lg:justify-end lg:px-0">
          {openPanel === "share" && (
            <SharePanel slug="justine" onClose={() => setOpenPanel(null)} />
          )}
          {(openPanel === "playlist" || openPanel === "ambient") && (
            <SoundPanel
              mode={openPanel === "playlist" ? "playlist" : "ambient"}
              playing={soundPlaying}
              onTogglePlay={() => setSoundPlaying((p) => !p)}
              onClose={() => setOpenPanel(null)}
            />
          )}
        </div>
      )}
    </div>
  );
}
