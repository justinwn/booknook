"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { THEMES, DEFAULT_THEME_ID, getTheme } from "@/lib/theme/themes";
import { useLibraryTheme } from "@/lib/theme/theme-context";
import { loadThemePreference } from "@/lib/profile/theme-preference";
import { Wallpaper } from "@/components/library/Wallpaper";
import { ThemePreview } from "@/components/theme/ThemePreview";
import { Wordmark } from "@/components/brand/Wordmark";
import type { ThemeId } from "@/lib/types";

/**
 * Choosing a mood happens *inside* the mood: the selected wallpaper plays as
 * the page background, so the choice is previewed at full size rather than in
 * a thumbnail. Everything above it is glass and text on a scrim, tuned per
 * theme — a bright daylight scene needs a heavier scrim than a night one.
 */
export default function ThemeSelectionPage() {
  const router = useRouter();
  const { setThemeId } = useLibraryTheme();
  const [selected, setSelected] = useState<ThemeId>(DEFAULT_THEME_ID);
  const [saving, setSaving] = useState(false);
  const theme = getTheme(selected);

  useEffect(() => {
    let active = true;
    loadThemePreference().then((themeId) => {
      if (active) setSelected(themeId);
    });
    return () => {
      active = false;
    };
  }, []);

  async function handleDone() {
    setSaving(true);
    await setThemeId(selected);
    router.push("/library");
  }

  return (
    <main data-theme={selected} className="relative min-h-screen overflow-hidden bg-bg">
      <Wallpaper
        src={theme.wallpaper}
        poster={theme.poster}
        scrim={theme.isLight ? "medium" : "light"}
      />
      {/* a gradient from the right, so the list side stays readable while the
          left half of the scene shows through almost untouched */}
      <div className="absolute inset-0 bg-gradient-to-l from-black/75 via-black/35 to-black/10" />
      <div className="absolute inset-x-0 bottom-0 h-40 bg-gradient-to-t from-black/60 to-transparent" />

      <header className="relative z-10 px-6 pt-6 sm:px-10 sm:pt-8">
        <Wordmark className="text-lg text-white drop-shadow-[0_2px_10px_rgba(0,0,0,0.8)]" />
      </header>

      <div className="relative z-10 mx-auto grid min-h-[calc(100vh-5rem)] w-full max-w-6xl grid-cols-1 items-center gap-14 px-6 pb-16 lg:grid-cols-[1fr_0.85fr] lg:gap-12 lg:px-10">
        <div className="flex justify-center lg:justify-start lg:pl-6">
          <ThemePreview theme={theme} />
        </div>

        <div className="w-full max-w-md justify-self-center lg:justify-self-start">
          <h1 className="font-body text-xs font-semibold uppercase tracking-[0.18em] text-white/90 drop-shadow-[0_2px_8px_rgba(0,0,0,0.9)]">
            Pick your library mood
          </h1>
          <p className="mt-2 font-body text-sm text-white/65 drop-shadow-[0_2px_8px_rgba(0,0,0,0.9)]">
            It plays behind your whole library. You can change it any time.
          </p>

          <div role="radiogroup" aria-label="Library mood" className="mt-7 flex flex-col gap-2.5">
            {THEMES.map((t) => {
              const isSelected = t.id === selected;
              return (
                <button
                  key={t.id}
                  type="button"
                  role="radio"
                  aria-checked={isSelected}
                  onClick={() => setSelected(t.id)}
                  className={
                    isSelected
                      ? "glass-dark-strong rounded-token-lg px-5 py-4 text-left ring-1 ring-white/35 transition-all duration-token ease-gentle"
                      : "glass-dark rounded-full px-5 py-3.5 text-left transition-all duration-token ease-gentle hover:ring-1 hover:ring-white/25"
                  }
                >
                  <span className="flex items-baseline justify-between gap-3">
                    <span className="font-body text-sm font-semibold text-white">{t.name}</span>
                    <span className="font-body text-[11px] text-white/55">{t.tagline}</span>
                  </span>

                  <span
                    className={`grid transition-all duration-token ease-gentle ${
                      isSelected ? "mt-2 grid-rows-[1fr] opacity-100" : "grid-rows-[0fr] opacity-0"
                    }`}
                  >
                    <span className="overflow-hidden">
                      <span className="block font-body text-[13px] leading-relaxed text-white/75">
                        {t.description}
                      </span>
                    </span>
                  </span>
                </button>
              );
            })}
          </div>

          <div className="mt-8 flex justify-end">
            <button
              type="button"
              onClick={handleDone}
              disabled={saving}
              className="rounded-full bg-white px-8 py-3.5 font-body text-sm font-semibold text-[#14120f] shadow-token-lg transition-all hover:brightness-95 disabled:opacity-60"
            >
              {saving ? "Just a moment…" : "Done"}
            </button>
          </div>
        </div>
      </div>
    </main>
  );
}
