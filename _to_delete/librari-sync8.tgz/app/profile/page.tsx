"use client";

import Link from "next/link";
import { ArrowLeft } from "lucide-react";
import { useLibraryTheme } from "@/lib/theme/theme-context";
import { Wordmark } from "@/components/brand/Wordmark";

/**
 * SCAFFOLD. The full profile — top featured books, reading stats, public
 * presentation — hasn't been specified yet, so this is the minimum that makes
 * "Profile opens the user's profile" true: identity, current mood, and a
 * marked-out region where featured books will live.
 */
export default function ProfilePage() {
  const { theme } = useLibraryTheme();

  return (
    <main className="min-h-screen bg-gallery px-6 py-12 sm:px-10">
      <div className="mx-auto w-full max-w-3xl">
        <Link
          href="/library"
          className="inline-flex items-center gap-2 font-body text-sm text-gallery-ink/60 transition-colors hover:text-gallery-ink"
        >
          <ArrowLeft className="h-4 w-4" strokeWidth={1.75} />
          Back to your library
        </Link>

        <header className="mt-10 flex items-center gap-5">
          <div className="h-20 w-20 shrink-0 rounded-full bg-gallery-ink/10" aria-hidden />
          <div>
            <h1 className="font-display text-3xl text-gallery-ink">Your profile</h1>
            <p className="mt-1 font-body text-sm text-gallery-ink/60">
              Current mood: {theme.name}
            </p>
          </div>
        </header>

        <section className="mt-12">
          <h2 className="font-body text-xs font-semibold uppercase tracking-[0.14em] text-gallery-ink/70">
            Featured books
          </h2>
          <div className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-4">
            {Array.from({ length: 4 }, (_, i) => (
              <div
                key={i}
                className="flex aspect-[2/3] items-center justify-center rounded-[4px] border border-dashed border-gallery-ink/20 font-body text-xs text-gallery-ink/35"
              >
                Empty
              </div>
            ))}
          </div>
          <p className="mt-4 font-body text-xs text-gallery-ink/45">
            Choosing which books to feature isn&apos;t built yet.
          </p>
        </section>

        <p className="mt-16 font-body text-xs text-gallery-ink/40">
          <Wordmark />
        </p>
      </div>
    </main>
  );
}
