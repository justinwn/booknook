"use client";

import Image from "next/image";
import { Plus, Waves, Palette, User, Share2 } from "lucide-react";
import clsx from "clsx";
import { SceneControl } from "./SceneControl";

export type ControlId = "add" | "playlist" | "ambient" | "theme" | "profile" | "share";

interface ControlRailProps {
  active: ControlId | null;
  onSelect: (id: ControlId) => void;
  /** artwork for the playlist tile */
  playlistArt?: string;
  playlistName: string;
}

/**
 * The room's controls. A playlist tile (album art, square) sits above a
 * column of dark discs — objects in the environment, deliberately not a
 * docked sidebar. On narrow screens the column becomes a scrollable rail
 * along the bottom so the room stays whole rather than being squeezed.
 */
export function ControlRail({ active, onSelect, playlistArt, playlistName }: ControlRailProps) {
  return (
    <div
      className={clsx(
        "pointer-events-none fixed z-30 flex gap-2.5",
        // mobile: scrollable rail along the bottom
        "bottom-0 left-0 right-0 flex-row items-end overflow-x-auto px-4 pb-4",
        // desktop: a column down the right-hand side
        "lg:bottom-auto lg:left-auto lg:right-6 lg:top-1/2 lg:w-auto lg:-translate-y-1/2",
        "lg:flex-col lg:items-end lg:overflow-visible lg:px-0 lg:pb-0"
      )}
    >
      <button
        type="button"
        onClick={() => onSelect("playlist")}
        aria-label={`Playlist: ${playlistName}`}
        className={clsx(
          "pointer-events-auto relative h-[74px] w-[74px] shrink-0 overflow-hidden rounded-[14px]",
          "bg-paper shadow-[0_14px_30px_-12px_rgba(0,0,0,0.8)] transition-all duration-token ease-gentle",
          "hover:-translate-y-0.5 active:translate-y-0 active:scale-95 lg:h-[86px] lg:w-[86px]",
          active === "playlist" && "ring-2 ring-white/70"
        )}
      >
        {playlistArt ? (
          <Image src={playlistArt} alt="" fill sizes="86px" className="object-cover" />
        ) : (
          <span className="flex h-full w-full items-center justify-center bg-gradient-to-br from-white to-[#e6e0d4]" />
        )}
        <span className="absolute inset-x-0 bottom-0 bg-black/45 px-1.5 py-1 text-center font-body text-[9px] font-medium text-white lg:text-[10px]">
          {playlistName}
        </span>
      </button>

      <div className="pointer-events-auto contents">
        <SceneControl
          icon={<Plus className="h-5 w-5" strokeWidth={1.5} />}
          label="Add book"
          active={active === "add"}
          onClick={() => onSelect("add")}
        />
        <SceneControl
          icon={<Waves className="h-5 w-5" strokeWidth={1.5} />}
          label="Ambient"
          active={active === "ambient"}
          onClick={() => onSelect("ambient")}
        />
        <SceneControl
          icon={<Palette className="h-5 w-5" strokeWidth={1.5} />}
          label="Library"
          active={active === "theme"}
          onClick={() => onSelect("theme")}
        />
        <SceneControl
          icon={<User className="h-5 w-5" strokeWidth={1.5} />}
          label="Profile"
          active={active === "profile"}
          onClick={() => onSelect("profile")}
        />
        <SceneControl
          icon={<Share2 className="h-5 w-5" strokeWidth={1.5} />}
          label="Share"
          active={active === "share"}
          onClick={() => onSelect("share")}
        />
      </div>
    </div>
  );
}
